// Headerfiles.h - 通用头文件集合

#ifndef __HEADERFILES_H
#define __HEADERFILES_H


#include "gd32f4xx.h"
#include "gd32f4xx_libopt.h"
#include "systick.h"
#include <stdio.h>
#include <stdint.h>
#include "string.h"
#include "Function.h"
#include "LED.h"
#include "boot_jump.h"
#include "fmc_iap.h"
#include "SPI_FLASH.h"
#include "RTC.h"
#include "KEY.h"
#include "DAC.h"
#include "protocol.h"

#endif

