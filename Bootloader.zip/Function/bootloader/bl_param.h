// Bootloader 参数结构体定义

#ifndef __BL_PARAM_H
#define __BL_PARAM_H

#include <stdint.h>
#include <stddef.h>

// 参数结构体

typedef struct {
    uint32_t magic;             /* BL_PARAM_MAGIC */
    uint32_t version;           /* BL_PARAM_VERSION */
    uint32_t update_flag;       /* BL_UPDATE_FLAG_xxx */
    uint32_t app1_addr;         /* APP 起始地址 */
    uint32_t app2_addr;         /* APP 备份地址 */
    uint32_t update_counter;    /* 升级计数 */
    uint32_t last_error;        /* 最后一次错误码 */
    uint32_t reserved[8];       /* 保留 */
    uint32_t tail_magic;        /* BL_PARAM_TAIL_MAGIC */
    uint32_t param_crc32;       /* CRC32 校验 (不含本字段) */
} bl_param_t;

#endif

