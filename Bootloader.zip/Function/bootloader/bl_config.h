// 2026 CIMC Bootloader Flash 分区配置
// Flash 分区: BL(64K) | Param(4K) | APP(128K) | Backup(128K) | Staging(128K)

#ifndef __BL_CONFIG_H
#define __BL_CONFIG_H

// Flash 基地址

#define BL_FLASH_BASE_ADDR      0x08000000UL
#define BL_FLASH_END_ADDR       0x0807FFFFUL
#define BL_FLASH_PAGE_SIZE      0x1000UL     /* 4KB per page */

// 各分区地址和大小

/* Bootloader */
#define BL_BOOTLOADER_ADDR      0x08000000UL
#define BL_BOOTLOADER_SIZE      0x10000UL    /* 64KB */

/* 参数区 */
#define BL_PARAM_PAGE_ADDR      0x08010000UL
#define BL_PARAM_SIZE           0x1000UL     /* 4KB */

/* APP 主程序 */
#define BL_APP1_START_ADDR      0x08011000UL
#define BL_APP1_SIZE            0x20000UL    /* 128KB */
#define BL_APP1_END_ADDR        (BL_APP1_START_ADDR + BL_APP1_SIZE - 1)

/* APP 备份区 */
#define BL_APP_BACKUP_START_ADDR 0x08031000UL
#define BL_APP_BACKUP_SIZE      0x20000UL   /* 128KB */

/* 固件暂存区 (OTA 下载缓冲区) */
#define BL_FIRMWARE_START_ADDR  0x08051000UL
#define BL_FIRMWARE_SIZE        0x20000UL   /* 128KB */
#define BL_FIRMWARE_END_ADDR    (BL_FIRMWARE_START_ADDR + BL_FIRMWARE_SIZE - 1)

// 参数区内部偏移

#define BL_PARAM_MAIN_ADDR      BL_PARAM_PAGE_ADDR
#define BL_PARAM_BACKUP_ADDR    (BL_PARAM_PAGE_ADDR + 0x800)  /* 主/备各占2KB */

// 升级标记

#define BL_UPDATE_FLAG_IDLE     0x00
#define BL_UPDATE_FLAG_PENDING  0x5A

// 固件魔术字

#define BL_FIRMWARE_MAGIC       0x5AA5C33CUL

// 参数区块魔术字和版本

#define BL_PARAM_MAGIC          0x424C504DUL  /* "BLPM" */
#define BL_PARAM_TAIL_MAGIC     0x504D4C42UL  /* "BMLP" */
#define BL_PARAM_VERSION        0x01

// 错误码

#define BL_ERR_NONE             0x00
#define BL_ERR_PARAM_INVALID    0x01
#define BL_ERR_FLASH_ERASE      0x02
#define BL_ERR_FLASH_PROGRAM    0x03
#define BL_ERR_MAGIC_MISMATCH   0x04
#define BL_ERR_CRC_MISMATCH     0x05
#define BL_ERR_TIMEOUT          0x06

#endif

