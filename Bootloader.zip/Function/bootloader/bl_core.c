﻿// Bootloader with CIMC protocol for OTA upgrade
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include "gd32f4xx.h"
#include "bl_core.h"
#include "bl_config.h"
#include "bl_param.h"
#include "mcu_cimc_gd32f470vet6.h"
#include "usart_app.h"
#include "systick.h"

typedef void (*app_entry_t)(void);


typedef enum {
    BL_STATE_IDLE = 0,          
    BL_STATE_COUNTDOWN,         
    BL_STATE_RECV_BINARY,       
    BL_STATE_WAIT_CMD,          
    BL_STATE_DONE               
} bl_state_t;

static bl_state_t s_bl_state = BL_STATE_IDLE;
static uint32_t   s_countdown_start_ms = 0;
static uint32_t   s_last_print_ms = 0;
static uint32_t   s_recv_count = 0;
static uint32_t   s_last_recv_ms = 0;
static uint8_t    s_binary_accum[8];
static uint32_t   s_binary_accum_len = 0;
static char       s_cmd_accum[256];
static uint32_t   s_cmd_accum_len = 0;


static uint8_t bl_page_cache[BL_PARAM_PAGE_SIZE];


static uint32_t bl_crc32_calc(const uint8_t *data, uint32_t len)
{
    uint32_t crc = 0xFFFFFFFFUL;
    uint32_t i, j;
    for(i = 0; i < len; i++) {
        crc ^= data[i];
        for(j = 0; j < 8; j++) {
            crc = ((crc & 1) != 0) ? ((crc >> 1) ^ 0xEDB88320UL) : (crc >> 1);
        }
    }
    return crc ^ 0xFFFFFFFFUL;
}

static uint32_t bl_param_calc_crc(const bl_param_t *param)
{
    return bl_crc32_calc((const uint8_t *)param, (uint32_t)offsetof(bl_param_t, param_crc32));
}


static bool bl_wait_fmc_ready(void)
{
    uint32_t timeout = 0x3FFFFFUL;
    while((RESET != fmc_flag_get(FMC_FLAG_BUSY)) && (timeout > 0)) timeout--;
    return (timeout > 0);
}

static void bl_flash_clear_flags(void)
{
    fmc_flag_clear(FMC_FLAG_END);
    fmc_flag_clear(FMC_FLAG_WPERR);
    fmc_flag_clear(FMC_FLAG_PGSERR);
    fmc_flag_clear(FMC_FLAG_PGMERR);
}

static bool bl_flash_erase_pages(uint32_t start_addr, uint32_t size)
{
    uint32_t page_addr, end_addr;
    if((size == 0) || (start_addr < BL_FLASH_BASE_ADDR)) return false;
    end_addr = start_addr + size - 1;
    if(end_addr > BL_FLASH_END_ADDR) return false;
    page_addr = start_addr - (start_addr % BL_FLASH_PAGE_SIZE);
    end_addr = end_addr - (end_addr % BL_FLASH_PAGE_SIZE);
    fmc_unlock();
    bl_flash_clear_flags();
    while(page_addr <= end_addr) {
        fmc_page_erase(page_addr);
        if(!bl_wait_fmc_ready()) { fmc_lock(); return false; }
        bl_flash_clear_flags();
        page_addr += BL_FLASH_PAGE_SIZE;
    }
    fmc_lock();
    return true;
}

static bool bl_flash_program_bytes(uint32_t addr, const uint8_t *data, uint32_t size)
{
    uint32_t word_value;
    if((data == NULL) || (size == 0)) return false;
    if((addr < BL_FLASH_BASE_ADDR) || ((addr + size - 1) > BL_FLASH_END_ADDR)) return false;
    fmc_unlock();
    bl_flash_clear_flags();
    while(((addr & 3) == 0) && (size >= 4)) {
        memcpy(&word_value, data, 4);
        fmc_word_program(addr, word_value);
        if(!bl_wait_fmc_ready()) { fmc_lock(); return false; }
        addr += 4; data += 4; size -= 4;
    }
    while(size > 0) {
        fmc_byte_program(addr, *data);
        if(!bl_wait_fmc_ready()) { fmc_lock(); return false; }
        addr++; data++; size--;
    }
    bl_flash_clear_flags();
    fmc_lock();
    return true;
}


static uint16_t bl_crc16_modbus(const uint8_t *data, uint32_t len)
{
    uint16_t crc = 0xFFFF;
    uint32_t i;
    uint8_t j;
    for(i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i];
        for(j = 0; j < 8; j++) {
            crc = (crc & 1) ? ((crc >> 1) ^ 0xA001) : (crc >> 1);
        }
    }
    return crc;
}


static const char bl_hex_table[] = "0123456789ABCDEF";

static int bl_hex_encode(const uint8_t *data, uint32_t len, char *out)
{
    uint32_t i;
    for(i = 0; i < len; i++) {
        out[i*2]     = bl_hex_table[(data[i] >> 4) & 0x0F];
        out[i*2 + 1] = bl_hex_table[data[i] & 0x0F];
    }
    out[len*2] = '\0';
    return (int)(len * 2);
}

static uint8_t bl_hex_char_val(char c)
{
    if(c >= '0' && c <= '9') return (uint8_t)(c - '0');
    if(c >= 'A' && c <= 'F') return (uint8_t)(c - 'A' + 10);
    if(c >= 'a' && c <= 'f') return (uint8_t)(c - 'a' + 10);
    return 0xFF;
}

static int bl_hex_decode(const char *ascii, uint32_t len, uint8_t *out, uint32_t out_max)
{
    uint32_t i, idx = 0;
    uint8_t hi, lo;
    if(len & 1) return -1;
    for(i = 0; i < len; i += 2) {
        hi = bl_hex_char_val(ascii[i]);
        lo = bl_hex_char_val(ascii[i+1]);
        if(hi == 0xFF || lo == 0xFF || idx >= out_max) return -1;
        out[idx++] = (uint8_t)((hi << 4) | lo);
    }
    return (int)idx;
}


#define CIMC_FRAME_HEADER   0xA5B6
#define CIMC_FRAME_TAIL     0xB6A5
#define CIMC_PROTOCOL_VER   0x02

static void bl_send_frame(uint16_t dev_id, uint8_t type, uint16_t cmd,
                           const uint8_t *content, uint8_t content_len)
{
    uint8_t buf[80];
    uint16_t crc;
    uint32_t pos = 0;
    char ascii[164];
    int ascii_len;
    uint32_t i;

    buf[pos++] = (uint8_t)(CIMC_FRAME_HEADER >> 8);
    buf[pos++] = (uint8_t)(CIMC_FRAME_HEADER & 0xFF);
    buf[pos++] = (uint8_t)(dev_id >> 8);
    buf[pos++] = (uint8_t)(dev_id & 0xFF);
    buf[pos++] = type;
    buf[pos++] = (uint8_t)(cmd >> 8);
    buf[pos++] = (uint8_t)(cmd & 0xFF);
    buf[pos++] = content_len;
    buf[pos++] = CIMC_PROTOCOL_VER;
    if(content_len > 0 && content != NULL) {
        memcpy(&buf[pos], content, content_len);
        pos += content_len;
    }
    crc = bl_crc16_modbus(buf, pos);
    buf[pos++] = (uint8_t)(crc >> 8);
    buf[pos++] = (uint8_t)(crc & 0xFF);
    buf[pos++] = (uint8_t)(CIMC_FRAME_TAIL >> 8);
    buf[pos++] = (uint8_t)(CIMC_FRAME_TAIL & 0xFF);

    ascii_len = bl_hex_encode(buf, pos, ascii);

    RS485_CS_SET(1);
    for(i = 0; i < (uint32_t)ascii_len; i++) {
        usart_data_transmit(RS232_RS485_USART, (uint8_t)ascii[i]);
        while(RESET == usart_flag_get(RS232_RS485_USART, USART_FLAG_TBE));
    }
    while(RESET == usart_flag_get(RS232_RS485_USART, USART_FLAG_TC));
    RS485_CS_SET(0);
}

static void bl_send_ok(uint16_t dev_id, uint16_t cmd)
{
    uint8_t ok = 0xFF;
    bl_send_frame(dev_id, 0x02, cmd, &ok, 1);
}

static void bl_send_error(uint16_t dev_id)
{
    bl_send_frame(dev_id, 0xFF, 0xEEEE, NULL, 0);
}

static void bl_send_heartbeat(uint16_t dev_id)
{
    bl_send_frame(dev_id, 0x05, 0x8888, NULL, 0);
}

static void bl_send_string(const char *str)
{
    uint32_t i;
    uint32_t len = (uint32_t)strlen(str);
    RS485_CS_SET(1);
    for(i = 0; i < len; i++) {
        usart_data_transmit(RS232_RS485_USART, (uint8_t)str[i]);
        while(RESET == usart_flag_get(RS232_RS485_USART, USART_FLAG_TBE));
    }
    while(RESET == usart_flag_get(RS232_RS485_USART, USART_FLAG_TC));
    RS485_CS_SET(0);
}


static bool bl_uart_rx_byte(uint8_t *out)
{
    if(usart_flag_get(RS232_RS485_USART, USART_FLAG_RBNE)) {
        *out = (uint8_t)usart_data_receive(RS232_RS485_USART);
        return true;
    }
    return false;
}

static bool bl_uart_has_byte(void)
{
    return usart_flag_get(RS232_RS485_USART, USART_FLAG_RBNE) != RESET;
}


static bool bl_is_app_vector_valid(uint32_t app_base)
{
    uint32_t msp = *(volatile uint32_t *)app_base;
    uint32_t reset = *(volatile uint32_t *)(app_base + 4);
    if((msp & 0x2FFE0000) != 0x20000000) return false;
    if(reset < BL_FLASH_BASE_ADDR || reset > BL_FLASH_END_ADDR) return false;
    return true;
}


static void bl_jump_to_app(uint32_t app_base)
{
    app_entry_t app_entry;
    uint32_t app_reset;
    uint32_t i;

    __disable_irq();
    SysTick->CTRL = 0; SysTick->LOAD = 0; SysTick->VAL = 0;
    for(i = 0; i < 8; i++) { NVIC->ICER[i] = 0xFFFFFFFF; NVIC->ICPR[i] = 0xFFFFFFFF; }
    __DSB(); __ISB();
    SCB->VTOR = app_base;
    __set_MSP(*(volatile uint32_t *)app_base);
    app_reset = *(volatile uint32_t *)(app_base + 4);
    app_entry = (app_entry_t)app_reset;
    __enable_irq();
    app_entry();
}


static bool bl_copy_flash(uint32_t dst, uint32_t dst_size, uint32_t src, uint32_t copy_size)
{
    uint8_t buf[256];
    uint32_t copied = 0;
    uint32_t erase_size, chunk;
    if(copy_size == 0 || copy_size > dst_size) return false;
    erase_size = (copy_size + BL_FLASH_PAGE_SIZE - 1) & ~(BL_FLASH_PAGE_SIZE - 1);
    if(!bl_flash_erase_pages(dst, erase_size)) return false;
    while(copied < copy_size) {
        chunk = copy_size - copied;
        if(chunk > 256) chunk = 256;
        memcpy(buf, (const void *)(src + copied), chunk);
        if(!bl_flash_program_bytes(dst + copied, buf, chunk)) return false;
        copied += chunk;
    }
    return true;
}


static bool bl_is_param_valid(const bl_param_t *p)
{
    if(p->magic != BL_PARAM_MAGIC) return false;
    if(p->tail_magic != BL_PARAM_TAIL_MAGIC) return false;
    if(p->version != BL_PARAM_VERSION) return false;
    return (bl_param_calc_crc(p) == p->param_crc32);
}

static void bl_param_set_default(bl_param_t *p)
{
    memset(p, 0, sizeof(bl_param_t));
    p->magic = BL_PARAM_MAGIC;
    p->version = BL_PARAM_VERSION;
    p->update_flag = BL_UPDATE_FLAG_IDLE;
    p->app1_addr = BL_APP1_START_ADDR;
    p->app2_addr = BL_APP2_START_ADDR;
    p->tail_magic = BL_PARAM_TAIL_MAGIC;
    p->param_crc32 = bl_param_calc_crc(p);
}

bool bl_commit_param(bl_param_t *param)
{
    bl_param_t main_copy, backup_copy;
    memcpy(bl_page_cache, (const void *)BL_PARAM_PAGE_ADDR, BL_PARAM_PAGE_SIZE);
    memcpy(&main_copy, param, sizeof(bl_param_t));
    main_copy.param_crc32 = bl_param_calc_crc(&main_copy);
    backup_copy = main_copy;
    memcpy(&bl_page_cache[BL_PARAM_MAIN_ADDR - BL_PARAM_PAGE_ADDR], &main_copy, sizeof(bl_param_t));
    memcpy(&bl_page_cache[BL_PARAM_BACKUP_ADDR - BL_PARAM_PAGE_ADDR], &backup_copy, sizeof(bl_param_t));
    if(!bl_flash_erase_pages(BL_PARAM_PAGE_ADDR, BL_PARAM_PAGE_SIZE)) return false;
    return bl_flash_program_bytes(BL_PARAM_PAGE_ADDR, bl_page_cache, BL_PARAM_PAGE_SIZE);
}


static bool bl_parse_cimc_cmd(const uint8_t *buf, uint32_t len, uint16_t *out_cmd)
{
    uint16_t header, tail, crc_calc, crc_rx;
    uint8_t content_len;
    uint32_t expected;

    if(len < 13) return false;
    header = ((uint16_t)buf[0] << 8) | buf[1];
    if(header != CIMC_FRAME_HEADER) return false;
    content_len = buf[7];
    expected = (uint32_t)13 + content_len;
    if(len < expected) return false;
    tail = ((uint16_t)buf[expected-2] << 8) | buf[expected-1];
    if(tail != CIMC_FRAME_TAIL) return false;
    crc_calc = bl_crc16_modbus(buf, expected - 4);
    crc_rx = ((uint16_t)buf[expected-4] << 8) | buf[expected-3];
    if(crc_calc != crc_rx) return false;
    *out_cmd = ((uint16_t)buf[5] << 8) | buf[6];
    return true;
}


static bool bl_receive_firmware(void)
{
    uint8_t byte;
    uint32_t timeout_ms;
    uint32_t start_ms = get_system_ms();
    uint32_t last_recv_ms = start_ms;
    uint32_t recv_count = 0;
    uint32_t firmware_size = 0;
    bool size_known = false;

    
    bl_send_string("Erasing staging area...\r\n");
    if(!bl_flash_erase_pages(BL_FIRMWARE_START_ADDR, BL_FIRMWARE_SIZE)) {
        bl_send_string("Erase failed\r\n");
        return false;
    }
    bl_send_string("Ready for firmware\r\n");

    
    while(1) {
        if(bl_uart_rx_byte(&byte)) {
            
            uint32_t addr = BL_FIRMWARE_START_ADDR + recv_count;
            if(addr <= BL_FIRMWARE_END_ADDR) {
                fmc_unlock();
                bl_flash_clear_flags();
                fmc_byte_program(addr, byte);
                bl_wait_fmc_ready();
                bl_flash_clear_flags();
                fmc_lock();
            }
            recv_count++;
            last_recv_ms = get_system_ms();

            
            if(recv_count == 4) {
                uint32_t magic = *(volatile uint32_t *)BL_FIRMWARE_START_ADDR;
                if(magic == BL_FIRMWARE_MAGIC) {
                    bl_send_string("Magic OK\r\n");
                } else {
                    bl_send_string("Magic mismatch\r\n");
                }
            }
        }

        
        timeout_ms = get_system_ms() - last_recv_ms;
        if(recv_count > 4 && timeout_ms > 1000) {
            break;
        }

        
        if((get_system_ms() - start_ms) > 30000) {
            bl_send_string("Transfer timeout\r\n");
            break;
        }
    }

    if(recv_count < 4) {
        bl_send_string("No firmware received\r\n");
        return false;
    }

    firmware_size = recv_count;
    bl_send_string("Transfer complete\r\n");

    
    {
        uint32_t magic = *(volatile uint32_t *)BL_FIRMWARE_START_ADDR;
        if(magic != BL_FIRMWARE_MAGIC) {
            bl_send_string("ERROR: bad magic\r\n");
            bl_send_error(0x0001);
            return false;
        }
    }

    
    if(!bl_is_app_vector_valid(BL_FIRMWARE_START_ADDR)) {
        bl_send_string("ERROR: bad vectors\r\n");
        bl_send_error(0x0001);
        return false;
    }

    bl_send_string("Firmware validated\r\n");

    
    {
        char cmd_accum[128];
        uint32_t cmd_len = 0;
        uint32_t wait_start = get_system_ms();
        uint16_t cmd;
        uint8_t decoded[80];
        int decoded_len;
        uint32_t i;
        bool execute_received = false;

        bl_send_string("Waiting for execute command\r\n");

        while(!execute_received) {
            if(bl_uart_rx_byte(&byte)) {
                if(cmd_len < sizeof(cmd_accum) - 1) {
                    cmd_accum[cmd_len++] = (char)byte;
                    cmd_accum[cmd_len] = '\0';
                }

                
                for(i = 0; i + 3 < cmd_len; i++) {
                    if(cmd_accum[i] == 'A' && cmd_accum[i+1] == '5' &&
                       cmd_accum[i+2] == 'B' && cmd_accum[i+3] == '6') {
                        
                        uint32_t j;
                        for(j = i + 4; j + 3 < cmd_len; j++) {
                            if(cmd_accum[j] == 'B' && cmd_accum[j+1] == '6' &&
                               cmd_accum[j+2] == 'A' && cmd_accum[j+3] == '5') {
                                uint32_t frame_len = j + 4 - i;
                                decoded_len = bl_hex_decode(&cmd_accum[i], frame_len, decoded, sizeof(decoded));
                                if(decoded_len > 0 && bl_parse_cimc_cmd(decoded, (uint32_t)decoded_len, &cmd)) {
                                    if(cmd == 0x0503) {
                                        execute_received = true;
                                        bl_send_ok(0x0001, 0x0503);
                                    }
                                }
                                
                                memmove(cmd_accum, &cmd_accum[j+4], cmd_len - (j+4));
                                cmd_len -= (j+4);
                                break;
                            }
                        }
                        break;
                    }
                }
            }

            
            if((get_system_ms() - wait_start) > 15000) {
                bl_send_string("Execute timeout\r\n");
                break;
            }
        }

        if(!execute_received) return false;
    }

    
    bl_send_string("Installing firmware...\r\n");
    {
        bl_param_t param;
        bool update_ok = true;

        
        if(bl_is_app_vector_valid(BL_APP1_START_ADDR)) {
            update_ok = bl_copy_flash(BL_APP_BACKUP_START_ADDR, BL_APP_BACKUP_SIZE,
                                      BL_APP1_START_ADDR, BL_APP1_SIZE);
        }

        if(update_ok) {
            update_ok = bl_copy_flash(BL_APP1_START_ADDR, BL_APP1_SIZE,
                                      BL_FIRMWARE_START_ADDR, firmware_size);
        }

        if(update_ok && bl_is_app_vector_valid(BL_APP1_START_ADDR)) {
            
            uint32_t app_crc = bl_crc32_calc((const uint8_t *)BL_APP1_START_ADDR, firmware_size);
            (void)app_crc;

            
            memcpy(&param, (const void *)BL_PARAM_MAIN_ADDR, sizeof(bl_param_t));
            if(!bl_is_param_valid(&param)) bl_param_set_default(&param);
            param.update_flag = BL_UPDATE_FLAG_IDLE;
            param.update_counter++;
            param.last_error = BL_ERR_NONE;
            bl_commit_param(&param);

            bl_send_string("Upgrade OK\r\n");
            delay_1ms(100);
            NVIC_SystemReset();
            return true;
        } else {
            
            if(bl_is_app_vector_valid(BL_APP_BACKUP_START_ADDR)) {
                bl_copy_flash(BL_APP1_START_ADDR, BL_APP1_SIZE,
                              BL_APP_BACKUP_START_ADDR, BL_APP1_SIZE);
            }
            bl_send_string("Install failed, restored backup\r\n");
            return false;
        }
    }
}


void bootloader_run(void)
{
    bl_param_t main_param, backup_param, working_param;
    bool main_valid, backup_valid;
    bool is_upgrade = false;

    
    memcpy(&main_param, (const void *)BL_PARAM_MAIN_ADDR, sizeof(bl_param_t));
    memcpy(&backup_param, (const void *)BL_PARAM_BACKUP_ADDR, sizeof(bl_param_t));
    main_valid = bl_is_param_valid(&main_param);
    backup_valid = bl_is_param_valid(&backup_param);

    if(main_valid) {
        working_param = main_param;
    } else if(backup_valid) {
        working_param = backup_param;
    } else {
        bl_param_set_default(&working_param);
        working_param.last_error = BL_ERR_PARAM_INVALID;
        bl_commit_param(&working_param);
    }

    
    is_upgrade = (working_param.update_flag == BL_UPDATE_FLAG_PENDING);

    if(!is_upgrade) {
        
        delay_1ms(5000);
        if(bl_is_app_vector_valid(BL_APP1_START_ADDR)) {
            bl_jump_to_app(BL_APP1_START_ADDR);
        }
        
        while(1) {}
    }

    
    working_param.update_flag = BL_UPDATE_FLAG_IDLE;
    bl_commit_param(&working_param);

    bl_send_string("using command to interrupt start Application\r\n");

    {
        uint32_t countdown_start = get_system_ms();
        uint32_t last_print = 0;
        uint32_t elapsed;
        bool cmd_received = false;
        uint16_t cmd;
        char accum[256];
        uint32_t accum_len = 0;
        uint8_t byte;
        uint32_t i;

        while(!cmd_received) {
            elapsed = get_system_ms() - countdown_start;

            
            if(elapsed < 1000 && last_print == 0) {
                bl_send_string("wait for start Application(10s)...\r\n");
                last_print = 1;
            } else if(elapsed >= 3000 && last_print == 1) {
                bl_send_string("wait for start Application(7s)...\r\n");
                last_print = 2;
            } else if(elapsed >= 6000 && last_print == 2) {
                bl_send_string("wait for start Application(4s)...\r\n");
                last_print = 3;
            } else if(elapsed >= 9000 && last_print == 3) {
                bl_send_string("wait for start Application(1s)...\r\n");
                last_print = 4;
            }

            
            if(bl_uart_rx_byte(&byte)) {
                if(accum_len < sizeof(accum) - 1) {
                    accum[accum_len++] = (char)byte;
                    accum[accum_len] = '\0';
                }

                
                for(i = 0; i + 3 < accum_len; i++) {
                    if(accum[i] == 'A' && accum[i+1] == '5' &&
                       accum[i+2] == 'B' && accum[i+3] == '6') {
                        uint32_t j;
                        for(j = i + 4; j + 3 < accum_len; j++) {
                            if(accum[j] == 'B' && accum[j+1] == '6' &&
                               accum[j+2] == 'A' && accum[j+3] == '5') {
                                uint32_t frame_len = j + 4 - i;
                                uint8_t decoded[80];
                                int dec_len = bl_hex_decode(&accum[i], frame_len, decoded, sizeof(decoded));
                                if(dec_len > 0 && bl_parse_cimc_cmd(decoded, (uint32_t)dec_len, &cmd)) {
                                    if(cmd == 0x0502) {
                                        cmd_received = true;
                                        bl_send_ok(0x0001, 0x0502);
                                    }
                                }
                                memmove(accum, &accum[j+4], accum_len - (j+4));
                                accum_len -= (j+4);
                                break;
                            }
                        }
                        break;
                    }
                }
            }

            
            if(elapsed >= 10000) {
                if(bl_is_app_vector_valid(BL_APP1_START_ADDR)) {
                    bl_jump_to_app(BL_APP1_START_ADDR);
                }
                while(1) {}
            }
        }

        
        bl_receive_firmware();

        
        while(1) {}
    }
}
