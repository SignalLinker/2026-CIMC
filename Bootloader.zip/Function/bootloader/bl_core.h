// Bootloader 核心逻辑函数声明

#ifndef __BL_CORE_H
#define __BL_CORE_H

#include <stdint.h>
#include <stdbool.h>

// 函数声明

void bootloader_run(void);

#endif

