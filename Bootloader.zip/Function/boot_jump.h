// BootLoader 跳转功能: 地址宏定义 + 跳转函数声明

#ifndef __BOOT_JUMP_H
#define __BOOT_JUMP_H

#include "gd32f4xx.h"

// Flash 内存布局
#define BOOTLOADER_ADDR       0x08000000
#define BOOTLOADER_SIZE       0x10000      /* 64KB */
#define PARAM_AREA_ADDR       0x08010000
#define PARAM_AREA_SIZE       0x1000       /* 4KB */
#define APP_ADDR              0x08011000
#define APP_SIZE              0x20000      /* 128KB */
#define APP_BACKUP_ADDR       0x08031000
#define APP_BACKUP_SIZE       0x20000      /* 128KB */
#define DOWNLOAD_BUFFER_ADDR  0x08051000
#define DOWNLOAD_BUFFER_SIZE  0x20000      /* 128KB */

// 函数声明
typedef void (*pFunction)(void);
void boot_jump_to_app(uint32_t app_addr);

#endif
