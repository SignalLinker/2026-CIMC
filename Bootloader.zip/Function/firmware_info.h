// APP固件信息结构, 存储在 PARAM_AREA_ADDR

#ifndef __FIRMWARE_INFO_H
#define __FIRMWARE_INFO_H

#include "boot_jump.h"

#define FIRMWARE_MAGIC  0x43494D43  /* "CIMC" */

#pragma pack(1)
typedef struct {
    uint32_t magic;      /* 魔数 0x43494D43 */
    uint32_t version;    /* 固件版本 (如 0x00010000 = v1.0.0) */
    uint32_t size;       /* APP固件大小（字节） */
    uint32_t crc32;      /* APP区域硬件CRC32 */
} firmware_info_t;
#pragma pack()

#endif

