﻿// BootLoader 跳转 App 核心实现

#include "boot_jump.h"

void boot_jump_to_app(uint32_t app_addr)
{
    uint32_t app_stack;
    pFunction app_entry;

    
    app_stack = *(__IO uint32_t *)app_addr;
    if ((app_stack & 0x2FF00000) != 0x20000000) {
        return;
    }

    
    __disable_irq();

    
    SysTick->CTRL = 0;
    SysTick->LOAD = 0;
    SysTick->VAL = 0;

    
    for (uint8_t i = 0; i < 8; i++) {
        NVIC->ICER[i] = 0xFFFFFFFF;
        NVIC->ICPR[i] = 0xFFFFFFFF;
    }

    __DSB();
    __ISB();

    
    SCB->VTOR = app_addr;

    
    __set_MSP(app_stack);

    
    app_entry = (pFunction)(*(__IO uint32_t *)(app_addr + 4));
    app_entry();
}
