// Function.h - BootLoader 主流程接口

#ifndef __FUNCTION_H
#define __FUNCTION_H

#include "HeaderFiles.h"
#include <stdint.h>

void System_Init(void);
void UsrFunction(void);

#endif

