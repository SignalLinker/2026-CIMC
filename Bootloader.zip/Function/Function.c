﻿#include "Function.h"
#include "firmware_info.h"
#include "gd32f4xx_crc.h"
#include "fmc_iap.h"

// BootLoader 最小初始化 (systick + LED)
void System_Init(void)
{
    systick_config();
    LED_Init();
}

// 检测参数区是否有待升级固件, 有则搬运+校验+复位, 返回 0=无需升级, 1=CRC不匹配
static uint8_t check_and_upgrade(void)
{
    firmware_info_t *info = (firmware_info_t *)PARAM_AREA_ADDR;
    uint32_t words;
    uint32_t i;
    uint32_t calc_crc;
    uint32_t remaining;

    if (info->magic != FIRMWARE_MAGIC) {
        return 0;
    }
    if (info->size == 0 || info->size > APP_SIZE) {
        return 0;
    }

    
    fmc_iap_erase(APP_ADDR, info->size);

    
    words = info->size / 4;
    for (i = 0; i < words; i++) {
        uint32_t word = *(__IO uint32_t *)(DOWNLOAD_BUFFER_ADDR + i * 4);
        fmc_iap_write_word(APP_ADDR + i * 4, word);
    }

    remaining = info->size % 4;
    if (remaining > 0) {
        uint8_t *src_bytes = (uint8_t *)(DOWNLOAD_BUFFER_ADDR + words * 4);
        fmc_iap_write(APP_ADDR + words * 4, src_bytes, remaining);
    }

    
    crc_data_register_reset();
    calc_crc = crc_block_data_calculate((uint32_t *)APP_ADDR, words);
    if (remaining > 0) {
        uint32_t last_word = 0;
        uint8_t *bytes = (uint8_t *)(APP_ADDR + words * 4);
        for (i = 0; i < remaining; i++) {
            ((uint8_t *)&last_word)[i] = bytes[i];
        }
        calc_crc = crc_single_data_calculate(last_word);
    }

    if (calc_crc != info->crc32) {
        return 1;
    }

    //清除参数区
		
    fmc_iap_erase(PARAM_AREA_ADDR, sizeof(firmware_info_t));

    
    fmc_iap_software_reset();

    return 0;
}

// 使用 GD32 硬件 CRC32 校验 APP 固件完整性, 返回 0=通过, 1=无信息, 2=长度异常, 3=CRC不匹配
static uint8_t verify_app_crc(void)
{
    firmware_info_t *info = (firmware_info_t *)PARAM_AREA_ADDR;

    if (info->magic != FIRMWARE_MAGIC) {
        return 1;
    }

    if (info->size == 0 || info->size > APP_SIZE) {
        return 2;
    }

    crc_data_register_reset();

    uint32_t word_count = info->size / 4;
    uint32_t calc_crc = crc_block_data_calculate((uint32_t *)APP_ADDR, word_count);

    uint32_t remaining = info->size % 4;
    if (remaining > 0) {
        uint32_t last_word = 0;
        uint8_t *bytes = (uint8_t *)(APP_ADDR + word_count * 4);
        for (uint32_t i = 0; i < remaining; i++) {
            ((uint8_t *)&last_word)[i] = bytes[i];
        }
        calc_crc = crc_single_data_calculate(last_word);
    }
    if (calc_crc != info->crc32) {
        return 3;
    }

    return 0;
}

// LED1 闪烁 3 次, 检测升级, CRC 校验, 跳转 APP
void UsrFunction(void)
{
    uint8_t result;

    
    for (int i = 0; i < 3; i++) {
        LED1_ON();
        delay_1ms(200);
        LED1_OFF();
        delay_1ms(200);
    }

    delay_1ms(500);

    
    result = check_and_upgrade();

    if (result == 1) {
        
        while (1) {
            LED1_ON();
            LED2_ON();
            delay_1ms(100);
            LED1_OFF();
            LED2_OFF();
            delay_1ms(100);
        }
    }

    
    result = verify_app_crc();

    if (result == 3) {
        
        while (1) {
            LED1_ON();
            LED2_ON();
            delay_1ms(100);
            LED1_OFF();
            LED2_OFF();
            delay_1ms(100);
        }
    }

    
    boot_jump_to_app(APP_ADDR);

    
    while (1) {
        LED1_ON();
        delay_1ms(200);
        LED1_OFF();
        delay_1ms(200);
    }
}

