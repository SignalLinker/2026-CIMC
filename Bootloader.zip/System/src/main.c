// Bootloader: USART1 RS485 + OLED + OTA 升级
// Flash 分区: BL(64K) | Param(4K) | APP(128K) | Backup(128K) | Staging(128K)

#include "gd32f4xx.h"
#include "gd32f4xx_fmc.h"
#include "systick.h"
#include <string.h>
#include <stdio.h>

// Flash 地址定义 (2026 赛题)

#define BL_FLASH_BASE           0x08000000UL
#define BL_PARAM_ADDR           0x08010000UL
#define BL_PARAM_SIZE           0x1000UL
#define BL_APP_ADDR             0x08011000UL
#define BL_APP_SIZE             0x20000UL
#define BL_APP_BACKUP_ADDR      0x08031000UL
#define BL_APP_BACKUP_SIZE      0x20000UL
#define BL_STAGING_ADDR         0x08051000UL
#define BL_STAGING_SIZE         0x20000UL
#define BL_FLASH_PAGE_SIZE      0x1000UL
#define BL_FLASH_END            0x0807FFFFUL

#define BL_FIRMWARE_MAGIC       0x5AA5C33CUL

// RS485 引脚定义

#define RS485_USART             USART1
#define RS485_RCU_USART         RCU_USART1
#define RS485_RCU_GPIO          RCU_GPIOD
#define RS485_TX_PORT           GPIOD
#define RS485_TX_PIN            GPIO_PIN_5
#define RS485_RX_PORT           GPIOD
#define RS485_RX_PIN            GPIO_PIN_6
#define RS485_AF                GPIO_AF_7

#define RS485_DE_PORT           GPIOE
#define RS485_DE_PIN            GPIO_PIN_8
#define RS485_DE_SET(x)         do { if(x) GPIO_BOP(RS485_DE_PORT) = RS485_DE_PIN; else GPIO_BC(RS485_DE_PORT) = RS485_DE_PIN; } while(0)

// OLED I2C0 引脚定义

#define OLED_SCL_PORT           GPIOB
#define OLED_SCL_PIN            GPIO_PIN_8
#define OLED_SDA_PORT           GPIOB
#define OLED_SDA_PIN            GPIO_PIN_9
#define OLED_I2C_AF             GPIO_AF_4

// CIMC 协议常量

#define CIMC_HDR_H              0xA5
#define CIMC_HDR_L              0xB6
#define CIMC_TAIL_H             0xB6
#define CIMC_TAIL_L             0xA5
#define CIMC_TYPE_CMD           0x01
#define CIMC_TYPE_REPLY         0x02
#define CIMC_TYPE_HEART         0x05
#define CIMC_TYPE_ERROR         0xFF
#define CIMC_CMD_UPGRADE_PREPARE 0x0502
#define CIMC_CMD_UPGRADE_EXECUTE 0x0503

// 全局变量

static volatile uint32_t g_bl_tick;

// SysTick

void SysTick_Handler(void)
{
    g_bl_tick++;
}

static void bl_systick_init(void)
{
    SysTick_Config(SystemCoreClock / 1000);
    __enable_irq();
}

static void bl_delay_ms(uint32_t ms)
{
    uint32_t start = g_bl_tick;
    while ((g_bl_tick - start) < ms) { __WFI(); }
}

// RS485 串口

static void bl_usart_putc(uint8_t c)
{
    usart_data_transmit(RS485_USART, c);
    while (RESET == usart_flag_get(RS485_USART, USART_FLAG_TBE));
}

static void bl_usart_send(const uint8_t *data, uint32_t len)
{
    uint32_t i;
    RS485_DE_SET(1);
    for (i = 0; i < len; i++) {
        bl_usart_putc(data[i]);
    }
    while (RESET == usart_flag_get(RS485_USART, USART_FLAG_TC));
    RS485_DE_SET(0);
}

static void bl_usart_send_str(const char *str)
{
    bl_usart_send((const uint8_t *)str, (uint32_t)strlen(str));
}

static uint8_t bl_usart_getc(void)
{
    return (uint8_t)usart_data_receive(RS485_USART);
}

static uint8_t bl_usart_rx_ready(void)
{
    return (usart_flag_get(RS485_USART, USART_FLAG_RBNE) != RESET) ? 1 : 0;
}

static void bl_usart_init(void)
{
    rcu_periph_clock_enable(RS485_RCU_GPIO);
    rcu_periph_clock_enable(RS485_RCU_USART);
    rcu_periph_clock_enable(RCU_GPIOE);

    gpio_af_set(RS485_TX_PORT, RS485_AF, RS485_TX_PIN);
    gpio_mode_set(RS485_TX_PORT, GPIO_MODE_AF, GPIO_PUPD_NONE, RS485_TX_PIN);
    gpio_output_options_set(RS485_TX_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, RS485_TX_PIN);

    gpio_af_set(RS485_RX_PORT, RS485_AF, RS485_RX_PIN);
    gpio_mode_set(RS485_RX_PORT, GPIO_MODE_AF, GPIO_PUPD_NONE, RS485_RX_PIN);
    gpio_output_options_set(RS485_RX_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, RS485_RX_PIN);

    gpio_mode_set(RS485_DE_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, RS485_DE_PIN);
    gpio_output_options_set(RS485_DE_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, RS485_DE_PIN);
    RS485_DE_SET(0);

    usart_deinit(RS485_USART);
    usart_baudrate_set(RS485_USART, 19200U);
    usart_transmit_config(RS485_USART, USART_TRANSMIT_ENABLE);
    usart_receive_config(RS485_USART, USART_RECEIVE_ENABLE);
    usart_enable(RS485_USART);
}

// OLED (I2C0 软件模拟)

static void bl_oled_i2c_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOB);

    gpio_mode_set(OLED_SCL_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, OLED_SCL_PIN);
    gpio_output_options_set(OLED_SCL_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, OLED_SCL_PIN);

    gpio_mode_set(OLED_SDA_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, OLED_SDA_PIN);
    gpio_output_options_set(OLED_SDA_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, OLED_SDA_PIN);

    GPIO_BOP(OLED_SCL_PORT) = OLED_SCL_PIN;
    GPIO_BOP(OLED_SDA_PORT) = OLED_SDA_PIN;
}

static void bl_oled_delay(void) { volatile uint32_t i; for (i = 0; i < 20; i++) {} }

static void bl_oled_i2c_start(void)
{
    GPIO_BOP(OLED_SDA_PORT) = OLED_SDA_PIN; bl_oled_delay();
    GPIO_BOP(OLED_SCL_PORT) = OLED_SCL_PIN; bl_oled_delay();
    GPIO_BC(OLED_SDA_PORT) = OLED_SDA_PIN; bl_oled_delay();
    GPIO_BC(OLED_SCL_PORT) = OLED_SCL_PIN; bl_oled_delay();
}

static void bl_oled_i2c_stop(void)
{
    GPIO_BC(OLED_SDA_PORT) = OLED_SDA_PIN; bl_oled_delay();
    GPIO_BOP(OLED_SCL_PORT) = OLED_SCL_PIN; bl_oled_delay();
    GPIO_BOP(OLED_SDA_PORT) = OLED_SDA_PIN; bl_oled_delay();
}

static void bl_oled_i2c_write(uint8_t data)
{
    uint8_t i;
    for (i = 0; i < 8; i++) {
        if (data & 0x80) GPIO_BOP(OLED_SDA_PORT) = OLED_SDA_PIN;
        else             GPIO_BC(OLED_SDA_PORT) = OLED_SDA_PIN;
        bl_oled_delay();
        GPIO_BOP(OLED_SCL_PORT) = OLED_SCL_PIN;
        bl_oled_delay();
        GPIO_BC(OLED_SCL_PORT) = OLED_SCL_PIN;
        data <<= 1;
    }
    /* ACK */
    GPIO_BOP(OLED_SDA_PORT) = OLED_SDA_PIN;
    bl_oled_delay();
    GPIO_BOP(OLED_SCL_PORT) = OLED_SCL_PIN;
    bl_oled_delay();
    GPIO_BC(OLED_SCL_PORT) = OLED_SCL_PIN;
}

static void bl_oled_write_cmd(uint8_t cmd)
{
    bl_oled_i2c_start();
    bl_oled_i2c_write(0x78);
    bl_oled_i2c_write(0x00);
    bl_oled_i2c_write(cmd);
    bl_oled_i2c_stop();
}

static void bl_oled_write_data(uint8_t data)
{
    bl_oled_i2c_start();
    bl_oled_i2c_write(0x78);
    bl_oled_i2c_write(0x40);
    bl_oled_i2c_write(data);
    bl_oled_i2c_stop();
}

static void bl_oled_init(void)
{
    bl_oled_i2c_init();
    bl_delay_ms(100);

    bl_oled_write_cmd(0xAE); /* display off */
    bl_oled_write_cmd(0x20); bl_oled_write_cmd(0x00); /* horizontal addressing */
    bl_oled_write_cmd(0xB0); /* page 0 */
    bl_oled_write_cmd(0xC8); /* COM scan direction */
    bl_oled_write_cmd(0x00); bl_oled_write_cmd(0x10); /* column low/high */
    bl_oled_write_cmd(0x40); /* start line */
    bl_oled_write_cmd(0x81); bl_oled_write_cmd(0xFF); /* contrast */
    bl_oled_write_cmd(0xA1); /* segment remap */
    bl_oled_write_cmd(0xA6); /* normal display */
    bl_oled_write_cmd(0xA8); bl_oled_write_cmd(0x3F); /* multiplex */
    bl_oled_write_cmd(0xD3); bl_oled_write_cmd(0x00); /* display offset */
    bl_oled_write_cmd(0xD5); bl_oled_write_cmd(0x80); /* clock div */
    bl_oled_write_cmd(0xD9); bl_oled_write_cmd(0xF1); /* precharge */
    bl_oled_write_cmd(0xDA); bl_oled_write_cmd(0x12); /* COM pins */
    bl_oled_write_cmd(0xDB); bl_oled_write_cmd(0x40); /* VCOM */
    bl_oled_write_cmd(0x8D); bl_oled_write_cmd(0x14); /* charge pump */
    bl_oled_write_cmd(0xAF); /* display on */
}

static void bl_oled_clear(void)
{
    uint8_t page, col;
    for (page = 0; page < 8; page++) {
        bl_oled_write_cmd(0xB0 + page);
        bl_oled_write_cmd(0x00);
        bl_oled_write_cmd(0x10);
        for (col = 0; col < 128; col++) {
            bl_oled_write_data(0x00);
        }
    }
}

/* 8x16 字体 (ASCII 32-122) */
static const uint8_t font8x16[][16] = {
    /* Space (32) */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    /* ! (33) */
    {0x00,0x00,0x00,0xF8,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x33,0x00,0x00,0x00,0x00},
    /* " (34) */
    {0x00,0x00,0x70,0x00,0x70,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    /* # (35) */
    {0x00,0x40,0xF0,0x40,0xF0,0x40,0x00,0x00,0x00,0x02,0x0F,0x02,0x0F,0x02,0x00,0x00},
    /* $ (36) */
    {0x00,0xE0,0x10,0xF8,0x10,0xE0,0x00,0x00,0x00,0x07,0x08,0x1F,0x08,0x07,0x00,0x00},
    /* % (37) */
    {0x30,0x48,0x30,0xC0,0x30,0x4C,0x30,0x00,0x00,0x00,0x03,0x0C,0x03,0x00,0x00,0x00},
    /* & (38) */
    {0x00,0xC0,0x30,0xC8,0x30,0xC0,0x00,0x00,0x00,0x07,0x08,0x09,0x06,0x08,0x07,0x00},
    /* ' (39) */
    {0x00,0x00,0x00,0x70,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    /* ( (40) */
    {0x00,0x00,0x80,0x60,0x10,0x00,0x00,0x00,0x00,0x00,0x07,0x18,0x20,0x00,0x00,0x00},
    /* ) (41) */
    {0x00,0x00,0x10,0x60,0x80,0x00,0x00,0x00,0x00,0x00,0x20,0x18,0x07,0x00,0x00,0x00},
    /* * (42) */
    {0x00,0x80,0xA0,0xE0,0xA0,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    /* + (43) */
    {0x00,0x00,0x80,0x80,0xE0,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x03,0x00,0x00,0x00},
    /* , (44) */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x00,0x00,0x00,0x00},
    /* - (45) */
    {0x00,0x00,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    /* . (46) */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x00,0x00,0x00,0x00},
    /* / (47) */
    {0x00,0x00,0x00,0x80,0x60,0x18,0x00,0x00,0x00,0x30,0x0C,0x03,0x00,0x00,0x00,0x00},
    /* 0 (48) */
    {0x00,0xE0,0x10,0x08,0x10,0xE0,0x00,0x00,0x00,0x07,0x08,0x10,0x08,0x07,0x00,0x00},
    /* 1 (49) */
    {0x00,0x00,0x20,0xF8,0x00,0x00,0x00,0x00,0x00,0x00,0x10,0x1F,0x10,0x00,0x00,0x00},
    /* 2 (50) */
    {0x00,0x30,0x08,0x08,0x88,0x70,0x00,0x00,0x00,0x1C,0x12,0x11,0x10,0x10,0x00,0x00},
    /* 3 (51) */
    {0x00,0x10,0x08,0x88,0x88,0x70,0x00,0x00,0x00,0x08,0x10,0x10,0x10,0x0F,0x00,0x00},
    /* 4 (52) */
    {0x00,0x80,0x40,0x20,0xF8,0x00,0x00,0x00,0x00,0x01,0x01,0x11,0x1F,0x11,0x00,0x00},
    /* 5 (53) */
    {0x00,0xF8,0x88,0x88,0x88,0x08,0x00,0x00,0x00,0x08,0x10,0x10,0x08,0x07,0x00,0x00},
    /* 6 (54) */
    {0x00,0xE0,0x90,0x88,0x88,0x00,0x00,0x00,0x00,0x07,0x08,0x10,0x08,0x07,0x00,0x00},
    /* 7 (55) */
    {0x00,0x18,0x08,0x88,0x68,0x18,0x00,0x00,0x00,0x00,0x1E,0x01,0x00,0x00,0x00,0x00},
    /* 8 (56) */
    {0x00,0x70,0x88,0x88,0x88,0x70,0x00,0x00,0x00,0x0F,0x10,0x10,0x10,0x0F,0x00,0x00},
    /* 9 (57) */
    {0x00,0x70,0x88,0x88,0x48,0xB0,0x00,0x00,0x00,0x00,0x10,0x10,0x08,0x07,0x00,0x00},
    /* : (58) */
    {0x00,0x00,0x00,0x60,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x00,0x00,0x00,0x00},
    /* ; (59) */
    {0x00,0x00,0x00,0x60,0x00,0x00,0x00,0x00,0x00,0x00,0x08,0x19,0x00,0x00,0x00,0x00},
    /* < (60) */
    {0x00,0x00,0x80,0x40,0x20,0x10,0x00,0x00,0x00,0x00,0x00,0x01,0x02,0x04,0x00,0x00},
    /* = (61) */
    {0x00,0x40,0x40,0x40,0x40,0x40,0x00,0x00,0x00,0x01,0x01,0x01,0x01,0x01,0x00,0x00},
    /* > (62) */
    {0x00,0x00,0x10,0x20,0x40,0x80,0x00,0x00,0x00,0x00,0x04,0x02,0x01,0x00,0x00,0x00},
    /* ? (63) */
    {0x00,0x30,0x08,0x88,0x48,0x30,0x00,0x00,0x00,0x00,0x00,0x19,0x00,0x00,0x00,0x00},
    /* @ (64) */
    {0x00,0xE0,0x10,0xC8,0x28,0xF0,0x00,0x00,0x00,0x07,0x08,0x13,0x14,0x0B,0x00,0x00},
    /* A (65) */
    {0x00,0x00,0x80,0x70,0x88,0x70,0x80,0x00,0x00,0x1E,0x01,0x01,0x01,0x01,0x1E,0x00},
    /* B (66) */
    {0x00,0xF8,0x88,0x88,0x88,0x70,0x00,0x00,0x00,0x1F,0x10,0x10,0x10,0x0F,0x00,0x00},
    /* C (67) */
    {0x00,0x70,0x88,0x80,0x80,0x88,0x70,0x00,0x00,0x0E,0x11,0x10,0x10,0x11,0x0E,0x00},
    /* D (68) */
    {0x00,0xF8,0x80,0x80,0x80,0xF0,0x00,0x00,0x00,0x1F,0x10,0x10,0x10,0x0F,0x00,0x00},
    /* E (69) */
    {0x00,0xF8,0x88,0x88,0x88,0x80,0x00,0x00,0x00,0x1F,0x10,0x10,0x10,0x10,0x00,0x00},
    /* F (70) */
    {0x00,0xF8,0x88,0x88,0x88,0x80,0x00,0x00,0x00,0x1F,0x00,0x00,0x00,0x00,0x00,0x00},
    /* G (71) */
    {0x00,0x70,0x88,0x80,0x98,0x88,0x70,0x00,0x00,0x0E,0x11,0x10,0x13,0x11,0x0F,0x00},
    /* H (72) */
    {0x00,0xF8,0x08,0x08,0x08,0xF8,0x00,0x00,0x00,0x1F,0x00,0x00,0x00,0x1F,0x00,0x00},
    /* I (73) */
    {0x00,0x00,0x80,0xF8,0x80,0x00,0x00,0x00,0x00,0x00,0x10,0x1F,0x10,0x00,0x00,0x00},
    /* J (74) */
    {0x00,0x00,0x00,0x80,0xF8,0x80,0x00,0x00,0x00,0x0E,0x10,0x10,0x0F,0x00,0x00,0x00},
    /* K (75) */
    {0x00,0xF8,0x08,0x10,0x28,0xC0,0x00,0x00,0x00,0x1F,0x01,0x02,0x04,0x18,0x00,0x00},
    /* L (76) */
    {0x00,0xF8,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x1F,0x10,0x10,0x10,0x10,0x00,0x00},
    /* M (77) */
    {0x00,0xF8,0x30,0xC0,0x30,0xF8,0x00,0x00,0x00,0x1F,0x00,0x01,0x00,0x1F,0x00,0x00},
    /* N (78) */
    {0x00,0xF8,0x60,0x80,0x00,0xF8,0x00,0x00,0x00,0x1F,0x00,0x03,0x0C,0x1F,0x00,0x00},
    /* O (79) */
    {0x00,0x70,0x88,0x80,0x88,0x70,0x00,0x00,0x00,0x0E,0x11,0x10,0x11,0x0E,0x00,0x00},
    /* P (80) */
    {0x00,0xF8,0x88,0x88,0x88,0x70,0x00,0x00,0x00,0x1F,0x00,0x00,0x00,0x00,0x00,0x00},
    /* Q (81) */
    {0x00,0x70,0x88,0x80,0x88,0x70,0x00,0x00,0x00,0x0E,0x11,0x14,0x12,0x1D,0x00,0x00},
    /* R (82) */
    {0x00,0xF8,0x88,0x88,0x88,0x70,0x00,0x00,0x00,0x1F,0x01,0x02,0x04,0x18,0x00,0x00},
    /* S (83) */
    {0x00,0x70,0x88,0x88,0x88,0x08,0x00,0x00,0x00,0x08,0x10,0x10,0x11,0x0E,0x00,0x00},
    /* T (84) */
    {0x00,0x80,0x80,0xF8,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x1F,0x00,0x00,0x00,0x00},
    /* U (85) */
    {0x00,0xF8,0x00,0x00,0x00,0xF8,0x00,0x00,0x00,0x0F,0x10,0x10,0x10,0x0F,0x00,0x00},
    /* V (86) */
    {0x00,0x78,0x80,0x00,0x80,0x78,0x00,0x00,0x00,0x00,0x07,0x18,0x07,0x00,0x00,0x00},
    /* W (87) */
    {0x00,0xF8,0x00,0x80,0x00,0xF8,0x00,0x00,0x00,0x0F,0x10,0x0F,0x10,0x0F,0x00,0x00},
    /* X (88) */
    {0x00,0xC0,0x30,0x08,0x30,0xC0,0x00,0x00,0x00,0x18,0x06,0x01,0x06,0x18,0x00,0x00},
    /* Y (89) */
    {0x00,0xC0,0x00,0x00,0x00,0xC0,0x00,0x00,0x00,0x00,0x01,0x1E,0x01,0x00,0x00,0x00},
    /* Z (90) */
    {0x00,0x80,0x80,0x98,0xA0,0xC0,0x00,0x00,0x00,0x1C,0x12,0x11,0x10,0x10,0x00,0x00},
    /* [ (91) */
    {0x00,0x00,0xF8,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x3F,0x20,0x20,0x00,0x00,0x00},
    /* \ (92) */
    {0x00,0x18,0x60,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x03,0x0C,0x30,0x00,0x00},
    /* ] (93) */
    {0x00,0x00,0x80,0x80,0xF8,0x00,0x00,0x00,0x00,0x00,0x20,0x20,0x3F,0x00,0x00,0x00},
    /* ^ (94) */
    {0x00,0x20,0x40,0x80,0x40,0x20,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    /* _ (95) */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x20,0x20,0x20,0x20,0x20,0x20,0x00},
    /* ` (96) */
    {0x00,0x00,0x10,0x20,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    /* a (97) */
    {0x00,0x00,0x40,0xA0,0xA0,0xC0,0x00,0x00,0x00,0x0E,0x11,0x11,0x11,0x1F,0x00,0x00},
    /* b (98) */
    {0x00,0xF8,0x20,0x10,0x10,0xE0,0x00,0x00,0x00,0x1F,0x08,0x10,0x10,0x0F,0x00,0x00},
    /* c (99) */
    {0x00,0xC0,0x20,0x10,0x10,0x20,0x00,0x00,0x00,0x07,0x08,0x10,0x10,0x08,0x00,0x00},
    /* d (100) */
    {0x00,0xE0,0x10,0x10,0x20,0xF8,0x00,0x00,0x00,0x0F,0x10,0x10,0x09,0x1F,0x00,0x00},
    /* e (101) */
    {0x00,0xC0,0xA0,0xA0,0xA0,0xC0,0x00,0x00,0x00,0x07,0x08,0x11,0x11,0x09,0x00,0x00},
    /* f (102) */
    {0x00,0x10,0xF8,0x90,0x90,0x80,0x00,0x00,0x00,0x00,0x1F,0x00,0x00,0x00,0x00,0x00},
    /* g (103) */
    {0x00,0xC0,0x20,0x10,0x20,0xE0,0x00,0x00,0x00,0x49,0x52,0x52,0x4A,0x3F,0x00,0x00},
    /* h (104) */
    {0x00,0xF8,0x20,0x10,0x10,0xE0,0x00,0x00,0x00,0x1F,0x00,0x00,0x00,0x1F,0x00,0x00},
    /* i (105) */
    {0x00,0x00,0x10,0xF4,0x00,0x00,0x00,0x00,0x00,0x00,0x10,0x1F,0x10,0x00,0x00,0x00},
    /* j (106) */
    {0x00,0x00,0x00,0x10,0xF4,0x00,0x00,0x00,0x00,0x20,0x20,0x20,0x1F,0x00,0x00,0x00},
    /* k (107) */
    {0x00,0xF8,0x80,0x40,0x20,0x00,0x00,0x00,0x00,0x1F,0x01,0x02,0x0C,0x10,0x00,0x00},
    /* l (108) */
    {0x00,0x00,0x80,0xF8,0x00,0x00,0x00,0x00,0x00,0x00,0x10,0x1F,0x10,0x00,0x00,0x00},
    /* m (109) */
    {0x00,0xE0,0x10,0xE0,0x10,0xE0,0x00,0x00,0x00,0x1F,0x00,0x0F,0x00,0x1F,0x00,0x00},
    /* n (110) */
    {0x00,0xF0,0x20,0x10,0x10,0xE0,0x00,0x00,0x00,0x1F,0x00,0x00,0x00,0x1F,0x00,0x00},
    /* o (111) */
    {0x00,0xC0,0x20,0x10,0x20,0xC0,0x00,0x00,0x00,0x07,0x08,0x10,0x08,0x07,0x00,0x00},
    /* p (112) */
    {0x00,0xF0,0x20,0x10,0x10,0xE0,0x00,0x00,0x00,0x7F,0x08,0x10,0x10,0x0F,0x00,0x00},
    /* q (113) */
    {0x00,0xE0,0x10,0x10,0x20,0xF0,0x00,0x00,0x00,0x0F,0x10,0x10,0x08,0x7F,0x00,0x00},
    /* r (114) */
    {0x00,0xE0,0x20,0x10,0x10,0x20,0x00,0x00,0x00,0x1F,0x00,0x00,0x00,0x00,0x00,0x00},
    /* s (115) */
    {0x00,0x40,0xA0,0xA0,0xA0,0x20,0x00,0x00,0x00,0x08,0x11,0x12,0x14,0x08,0x00,0x00},
    /* t (116) */
    {0x00,0x10,0xF8,0x10,0x10,0x00,0x00,0x00,0x00,0x00,0x0F,0x10,0x10,0x08,0x00,0x00},
    /* u (117) */
    {0x00,0xF0,0x00,0x00,0x00,0xF0,0x00,0x00,0x00,0x0F,0x10,0x10,0x09,0x1F,0x00,0x00},
    /* v (118) */
    {0x00,0x70,0x80,0x00,0x80,0x70,0x00,0x00,0x00,0x00,0x07,0x18,0x07,0x00,0x00,0x00},
    /* w (119) */
    {0x00,0xF0,0x00,0xC0,0x00,0xF0,0x00,0x00,0x00,0x07,0x18,0x07,0x18,0x07,0x00,0x00},
    /* x (120) */
    {0x00,0x20,0x40,0x80,0x40,0x20,0x00,0x00,0x00,0x18,0x05,0x02,0x05,0x18,0x00,0x00},
    /* y (121) */
    {0x00,0x70,0x80,0x00,0x80,0x70,0x00,0x00,0x00,0x40,0x23,0x1C,0x03,0x00,0x00,0x00},
    /* z (122) */
    {0x00,0x80,0x80,0x90,0xA0,0xC0,0x00,0x00,0x00,0x18,0x14,0x12,0x11,0x10,0x00,0x00},
};
#define FONT_FIRST 32
#define FONT_COUNT 91  /* 32-122 */

static void bl_oled_show_str(uint8_t x, uint8_t page, const char *str)
{
    while (*str) {
        uint8_t c = (uint8_t)*str;
        uint8_t idx = c - FONT_FIRST;
        uint8_t col;
        if (idx < FONT_COUNT) {
            bl_oled_write_cmd(0xB0 + page);
            bl_oled_write_cmd(0x00 + ((x & 0xF0) >> 4));
            bl_oled_write_cmd(0x10 + (x & 0x0F));
            for (col = 0; col < 8; col++) bl_oled_write_data(font8x16[idx][col]);
            bl_oled_write_cmd(0xB0 + page + 1);
            bl_oled_write_cmd(0x00 + (((x) & 0xF0) >> 4));
            bl_oled_write_cmd(0x10 + ((x) & 0x0F));
            for (col = 8; col < 16; col++) bl_oled_write_data(font8x16[idx][col]);
        }
        x += 8;
        str++;
    }
}

// CRC16-Modbus

static uint16_t bl_crc16(const uint8_t *data, uint32_t len)
{
    uint16_t crc = 0xFFFF;
    uint32_t i;
    uint8_t j;
    for (i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i];
        for (j = 0; j < 8; j++) {
            crc = (crc & 1) ? ((crc >> 1) ^ 0xA001) : (crc >> 1);
        }
    }
    return crc;
}

// ASCII-hex 编解码

static uint8_t bl_hex_char(uint8_t c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return 0xFF;
}

static const char bl_hex_tab[] = "0123456789ABCDEF";

static void bl_hex_encode(const uint8_t *bin, uint32_t len, uint8_t *asc)
{
    uint32_t i;
    for (i = 0; i < len; i++) {
        asc[i*2]     = bl_hex_tab[(bin[i] >> 4) & 0x0F];
        asc[i*2 + 1] = bl_hex_tab[bin[i] & 0x0F];
    }
}

static int32_t bl_hex_decode(const uint8_t *asc, uint32_t len, uint8_t *bin, uint32_t bin_max)
{
    uint32_t i;
    uint8_t hi, lo;
    if (len & 1) return -1;
    if (len / 2 > bin_max) return -1;
    for (i = 0; i < len; i += 2) {
        hi = bl_hex_char(asc[i]);
        lo = bl_hex_char(asc[i+1]);
        if (hi > 0x0F || lo > 0x0F) return -1;
        bin[i/2] = (hi << 4) | lo;
    }
    return (int32_t)(len / 2);
}

// CIMC 帧发送

static void bl_send_frame(uint16_t devid, uint8_t type, uint16_t cmd,
                          const uint8_t *content, uint8_t clen)
{
    uint8_t bin[300];
    uint8_t asc[600];
    uint32_t pos = 0;
    uint16_t crc;
    uint32_t asc_len;

    bin[pos++] = CIMC_HDR_H;
    bin[pos++] = CIMC_HDR_L;
    bin[pos++] = (uint8_t)(devid >> 8);
    bin[pos++] = (uint8_t)(devid & 0xFF);
    bin[pos++] = type;
    bin[pos++] = (uint8_t)(cmd >> 8);
    bin[pos++] = (uint8_t)(cmd & 0xFF);
    bin[pos++] = clen;
    bin[pos++] = 0x02;  /* protocol version */
    if (clen > 0 && content) {
        memcpy(&bin[pos], content, clen);
        pos += clen;
    }
    crc = bl_crc16(&bin[0], pos);  /* CRC from Header through Content */
    bin[pos++] = (uint8_t)(crc >> 8);
    bin[pos++] = (uint8_t)(crc & 0xFF);
    bin[pos++] = CIMC_TAIL_H;
    bin[pos++] = CIMC_TAIL_L;

    bl_hex_encode(bin, pos, asc);
    asc_len = pos * 2;
    bl_usart_send(asc, asc_len);
}

// Flash 操作

static void bl_fmc_unlock(void)
{
    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGSERR | FMC_FLAG_PGMERR);
}

static uint8_t bl_fmc_erase_page(uint32_t addr)
{
    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGSERR | FMC_FLAG_PGMERR);
    if (fmc_page_erase(addr) != FMC_READY) {
        fmc_lock();
        return 0;
    }
    fmc_lock();
    return 1;
}

static uint8_t bl_fmc_erase(uint32_t addr, uint32_t size)
{
    uint32_t start = addr & ~(BL_FLASH_PAGE_SIZE - 1);
    uint32_t end   = (addr + size + BL_FLASH_PAGE_SIZE - 1) & ~(BL_FLASH_PAGE_SIZE - 1);
    uint32_t page;
    for (page = start; page < end; page += BL_FLASH_PAGE_SIZE) {
        if (!bl_fmc_erase_page(page)) return 0;
    }
    return 1;
}

static uint8_t bl_fmc_write_word(uint32_t addr, uint32_t data)
{
    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGSERR | FMC_FLAG_PGMERR);
    if (fmc_word_program(addr, data) != FMC_READY) {
        fmc_lock();
        return 0;
    }
    fmc_lock();
    return 1;
}

static uint8_t bl_fmc_write(uint32_t addr, const uint8_t *data, uint32_t len)
{
    uint32_t word;
    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGSERR | FMC_FLAG_PGMERR);

    /* Word-aligned writes */
    while (len >= 4 && (addr & 3) == 0) {
        word = ((uint32_t)data[0] << 24) | ((uint32_t)data[1] << 16) |
               ((uint32_t)data[2] << 8)  | (uint32_t)data[3];
        fmc_word_program(addr, word);
        addr += 4; data += 4; len -= 4;
    }
    /* Remaining bytes */
    while (len > 0) {
        fmc_byte_program(addr, *data);
        addr++; data++; len--;
    }
    fmc_lock();
    return 1;
}

// APP 跳转

static uint8_t bl_app_valid(uint32_t app_addr)
{
    uint32_t sp  = *(volatile uint32_t *)app_addr;
    uint32_t pc  = *(volatile uint32_t *)(app_addr + 4);
    if ((sp & 0x2FFE0000) != 0x20000000) return 0;
    if (pc < BL_FLASH_BASE || pc > BL_FLASH_END) return 0;
    return 1;
}

static void bl_jump_to_app(uint32_t app_addr)
{
    uint32_t sp, pc;
    uint32_t i;

    __disable_irq();
    SysTick->CTRL = 0; SysTick->LOAD = 0; SysTick->VAL = 0;
    for (i = 0; i < 8; i++) { NVIC->ICER[i] = 0xFFFFFFFF; NVIC->ICPR[i] = 0xFFFFFFFF; }
    __DSB(); __ISB();

    SCB->VTOR = app_addr;
    sp = *(volatile uint32_t *)app_addr;
    pc = *(volatile uint32_t *)(app_addr + 4);
    __set_MSP(sp);
    ((void (*)(void))pc)();
}

// 固件接收与升级

static uint8_t bl_receive_firmware(void)
{
    uint8_t byte;
    uint32_t recv_count = 0;
    uint32_t start_ms   = g_bl_tick;
    uint32_t last_ms    = g_bl_tick;
    uint32_t timeout_ms;
    uint32_t magic;

    /* 擦除暂存区 */
    bl_usart_send_str("Erasing staging area...\r\n");
    if (!bl_fmc_erase(BL_STAGING_ADDR, BL_STAGING_SIZE)) {
        bl_usart_send_str("ERROR: erase failed\r\n");
        return 0;
    }
    bl_usart_send_str("Ready for firmware\r\n");

    /* 接收二进制数据 */
    while (1) {
        while (bl_usart_rx_ready()) {
            byte = bl_usart_getc();
            if (recv_count < BL_STAGING_SIZE) {
                bl_fmc_write(BL_STAGING_ADDR + recv_count, &byte, 1);
            }
            recv_count++;
            last_ms = g_bl_tick;
        }

        timeout_ms = g_bl_tick - last_ms;
        if (recv_count > 4 && timeout_ms > 2000) break;

        if ((g_bl_tick - start_ms) > 60000) {
            bl_usart_send_str("ERROR: transfer timeout\r\n");
            return 0;
        }
    }

    if (recv_count < 4) {
        bl_usart_send_str("ERROR: no firmware received\r\n");
        return 0;
    }

    /* 校验魔术字 */
    magic = *(volatile uint32_t *)BL_STAGING_ADDR;
    if (magic != BL_FIRMWARE_MAGIC) {
        bl_usart_send_str("ERROR: bad magic\r\n");
        return 0;
    }

    bl_usart_send_str("Magic OK, validating vectors...\r\n");
    if (!bl_app_valid(BL_STAGING_ADDR)) {
        bl_usart_send_str("ERROR: bad vectors\r\n");
        return 0;
    }

    bl_usart_send_str("Firmware validated. Waiting for execute command...\r\n");

    /* 等待 0x0503 执行命令 */
    {
        uint8_t  acc[512];
        uint32_t acc_len = 0;
        uint32_t wait_start = g_bl_tick;
        uint8_t  exec_ok = 0;
        uint32_t i, j;

        while ((g_bl_tick - wait_start) < 15000) {
            while (bl_usart_rx_ready() && acc_len < sizeof(acc) - 1) {
                acc[acc_len++] = bl_usart_getc();
            }

            /* 搜索 A5B6...B6A5 帧 */
            for (i = 0; i + 21 < acc_len; i++) {  /* 最小帧 11*2=22 */
                if (acc[i] == 'A' && acc[i+1] == '5' &&
                    acc[i+2] == 'B' && acc[i+3] == '6') {
                    for (j = i + 22; j + 3 < acc_len && j < i + 600; j++) {
                        if (acc[j] == 'B' && acc[j+1] == '6' &&
                            acc[j+2] == 'A' && acc[j+3] == '5') {
                            uint32_t flen = j + 4 - i;
                            uint8_t dbuf[300];
                            int32_t dlen = bl_hex_decode(&acc[i], flen, dbuf, sizeof(dbuf));
                            if (dlen >= 13) {
                                uint8_t clen = dbuf[7];
                                if ((uint32_t)dlen == 13 + clen) {
                                    uint16_t cmd = ((uint16_t)dbuf[5] << 8) | dbuf[6];
                                    uint16_t calc = bl_crc16(&dbuf[0], 9 + clen);
                                    uint16_t recv = ((uint16_t)dbuf[9+clen] << 8) | dbuf[10+clen];
                                    if (calc == recv && cmd == CIMC_CMD_UPGRADE_EXECUTE) {
                                        exec_ok = 1;
                                        /* 回复 OK */
                                        {
                                            uint8_t ok = 0xFF;
                                            bl_send_frame(0x0001, CIMC_TYPE_REPLY, CIMC_CMD_UPGRADE_EXECUTE, &ok, 1);
                                        }
                                        break;
                                    }
                                }
                            }
                            /* 移除已处理数据 */
                            memmove(acc, &acc[j+4], acc_len - (j+4));
                            acc_len -= (j+4);
                            break;
                        }
                    }
                    if (exec_ok) break;
                }
            }
            if (exec_ok) break;
        }

        if (!exec_ok) {
            bl_usart_send_str("ERROR: execute timeout\r\n");
            return 0;
        }
    }

    /* 执行升级: 备份APP → 写入新固件 → 升级完成 */
    bl_usart_send_str("Installing firmware...\r\n");

    if (bl_app_valid(BL_APP_ADDR)) {
        /* 备份当前 APP */
        uint8_t buf[256];
        uint32_t copied = 0;
        bl_usart_send_str("Backing up APP...\r\n");
        bl_fmc_erase(BL_APP_BACKUP_ADDR, BL_APP_BACKUP_SIZE);
        while (copied < BL_APP_SIZE) {
            uint32_t chunk = BL_APP_SIZE - copied;
            if (chunk > 256) chunk = 256;
            memcpy(buf, (const void *)(BL_APP_ADDR + copied), chunk);
            bl_fmc_write(BL_APP_BACKUP_ADDR + copied, buf, chunk);
            copied += chunk;
        }
    }

    /* 写入新固件 */
    {
        uint8_t buf[256];
        uint32_t copied = 0;
        uint32_t fw_size = recv_count;
        bl_usart_send_str("Writing new firmware...\r\n");
        bl_fmc_erase(BL_APP_ADDR, BL_APP_SIZE);
        while (copied < fw_size) {
            uint32_t chunk = fw_size - copied;
            if (chunk > 256) chunk = 256;
            memcpy(buf, (const void *)(BL_STAGING_ADDR + copied), chunk);
            bl_fmc_write(BL_APP_ADDR + copied, buf, chunk);
            copied += chunk;
        }
    }

    /* 清除升级标记 */
    bl_fmc_erase(BL_PARAM_ADDR, BL_PARAM_SIZE);

    bl_usart_send_str("Upgrade OK\r\n");
    bl_delay_ms(100);
    NVIC_SystemReset();
    return 1;
}

// 主入口

int main(void)
{
    uint32_t countdown_start;
    uint8_t  cmd_received = 0;
    uint8_t  acc[512];
    uint32_t acc_len = 0;
    uint32_t elapsed;
    uint32_t i, j;

    bl_systick_init();
    bl_usart_init();
    bl_oled_init();

    /* OLED: 第1行 Team ID, 第2行 "Bootloader" */
    bl_oled_clear();
    bl_oled_show_str(0, 0, "2026296117");
    bl_oled_show_str(0, 2, "Bootloader");

    /* 检查升级标记 (参数区第一个字 = 0x5AA5C33C 表示有升级请求) */
    {
        uint32_t upgrade_flag = *(volatile uint32_t *)BL_PARAM_ADDR;
        if (upgrade_flag == BL_FIRMWARE_MAGIC) {
            cmd_received = 2;  /* 有升级请求 */
        }
    }

    if (cmd_received == 0) {
        /* 正常启动: 不做串口输出, 延时5s直接跳转 APP */
        bl_delay_ms(5000);
        if (bl_app_valid(BL_APP_ADDR)) {
            bl_jump_to_app(BL_APP_ADDR);
        }
        while (1) {}
    }

    /* 升级模式: 按协议 4.5.7(3) 规约输出, 延时 10s 等待 0x0502 */
    /* 清除升级标记 */
    bl_fmc_erase(BL_PARAM_ADDR, BL_PARAM_SIZE);

    /* 按通讯协议输出: Type=REPLY, Cmd=0x0501, 表示已进入升级就绪 */
    {
        uint8_t ready = 0xFF;
        bl_send_frame(0x0001, CIMC_TYPE_REPLY, 0x0501, &ready, 1);
    }

    countdown_start = g_bl_tick;
    cmd_received = 0;

    while (!cmd_received) {
        elapsed = g_bl_tick - countdown_start;

        /* 延时10s等待升级指令, 不做额外输出 */

        /* 接收并解析帧 */
        while (bl_usart_rx_ready() && acc_len < sizeof(acc) - 1) {
            acc[acc_len++] = bl_usart_getc();
        }

        for (i = 0; i + 21 < acc_len; i++) {
            if (acc[i] == 'A' && acc[i+1] == '5' &&
                acc[i+2] == 'B' && acc[i+3] == '6') {
                for (j = i + 22; j + 3 < acc_len && j < i + 600; j++) {
                    if (acc[j] == 'B' && acc[j+1] == '6' &&
                        acc[j+2] == 'A' && acc[j+3] == '5') {
                        uint32_t flen = j + 4 - i;
                        uint8_t dbuf[300];
                        int32_t dlen = bl_hex_decode(&acc[i], flen, dbuf, sizeof(dbuf));
                        if (dlen >= 13) {
                            uint8_t clen = dbuf[7];
                            if ((uint32_t)dlen == 13 + clen) {
                                uint16_t cmd = ((uint16_t)dbuf[5] << 8) | dbuf[6];
                                uint16_t calc_crc = bl_crc16(&dbuf[0], 9 + clen);
                                uint16_t recv_crc = ((uint16_t)dbuf[9+clen] << 8) | dbuf[10+clen];
                                if (calc_crc == recv_crc && cmd == CIMC_CMD_UPGRADE_PREPARE) {
                                    cmd_received = 1;
                                    /* 回复 OK */
                                    {
                                        uint8_t ok = 0xFF;
                                        bl_send_frame(0x0001, CIMC_TYPE_REPLY, CIMC_CMD_UPGRADE_PREPARE, &ok, 1);
                                    }
                                }
                            }
                        }
                        memmove(acc, &acc[j+4], acc_len - (j+4));
                        acc_len -= (j+4);
                        break;
                    }
                }
                break;
            }
        }

        if (elapsed >= 10000 && !cmd_received) {
            if (bl_app_valid(BL_APP_ADDR)) {
                bl_jump_to_app(BL_APP_ADDR);
            }
            while (1) {}
        }
    }

    /* 收到 0x0502: 开始接收固件 */
    bl_receive_firmware();

    while (1) {}
}
