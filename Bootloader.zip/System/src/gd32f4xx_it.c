// interrupt service routines

#include <stdint.h>
volatile uint32_t system_ms_counter = 0;

#include "gd32f4xx_it.h"
#include "main.h"
#include "systick.h"

void NMI_Handler(void)
{
    while(1) {
    }
}

void HardFault_Handler(void)
{
    while(1) {
    }
}

void MemManage_Handler(void)
{
    while(1) {
    }
}

void BusFault_Handler(void)
{
    while(1) {
    }
}

void UsageFault_Handler(void)
{
    while(1) {
    }
}

void SVC_Handler(void)
{
    while(1) {
    }
}

void DebugMon_Handler(void)
{
    while(1) {
    }
}

void PendSV_Handler(void)
{
    while(1) {
    }
}
extern volatile uint32_t system_ms_counter;

void SysTick_Handler(void)
{
    delay_decrement();
    system_ms_counter++;
}
