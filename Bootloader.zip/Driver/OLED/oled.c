// OLED 驱动 (SSD1306, 128x32)

#include "stdlib.h"
#include "oled.h"
#include "oledfont.h"
#include "iic.h"

// OLED 显存：8页模式，宽128，高32，实际用4页(32/8=4)
static uint8_t g_oled_gram[128][4];

// 刷新显存到屏幕
void oled_refresh_gram(void)
{
    uint8_t i, n;

    for (i = 0; i < 4; i++)
    {
        oled_wr_byte(0xb0 + i, OLED_CMD);  /* 设置当前页地址(0~3) */
        oled_wr_byte(0x00, OLED_CMD);      /* 设置列地址低4位 */
        oled_wr_byte(0x10, OLED_CMD);      /* 设置列地址高4位 */

        iic_start();
        iic_send_byte(0X78);              /* OLED从机地址 */
        iic_wait_ack();
        iic_send_byte(0x40);              /* 写数据标志 */
        iic_wait_ack();

        for (n = 0; n < 128; n++)
        {
            iic_send_byte(g_oled_gram[n][i]);
            iic_wait_ack();
        }
        iic_stop();
    }
}

// 向OLED写一个字节(命令/数据)
static void oled_wr_byte(uint8_t data, uint8_t cmd)
{
    iic_start();                          /* IIC起始信号 */
    iic_send_byte(0X78);                  /* OLED地址 */
    iic_wait_ack();                       /* 等待ACK */

    if(cmd == OLED_CMD)
    {
        iic_send_byte(0x00);              /* 写命令 */
    }
    else
    {
        iic_send_byte(0x40);              /* 写数据 */
    }

    iic_wait_ack();
    iic_send_byte(data);                  /* 发送数据 */
    iic_wait_ack();
    iic_stop();                           /* IIC停止信号 */
}

// 开启OLED显示
void oled_display_on(void)
{
    oled_wr_byte(0X8D, OLED_CMD);   /* 设置电荷泵 */
    oled_wr_byte(0X14, OLED_CMD);   /* 开启电荷泵 */
    oled_wr_byte(0XAF, OLED_CMD);   /* 开启显示 */
}

// 关闭OLED显示
void oled_display_off(void)
{
    oled_wr_byte(0X8D, OLED_CMD);   /* 设置电荷泵 */
    oled_wr_byte(0X10, OLED_CMD);   /* 关闭电荷泵 */
    oled_wr_byte(0XAE, OLED_CMD);   /* 关闭显示 */
}

// 清屏(全黑)
void oled_clear(void)
{
    uint8_t i, n;

    for (i = 0; i < 4; i++)
    {
        for (n = 0; n < 128; n++)
        {
            g_oled_gram[n][i] = 0X00;
        }
    }

    oled_refresh_gram();    /* 更新到屏幕 */
}

// 画点函数
void oled_draw_point(uint8_t x, uint8_t y, uint8_t dot)
{
    uint8_t pos, bx, temp = 0;

    if (x > 127 || y > 31)
    {
        return;                     /* 超出范围直接返回 */
    }

    pos = y / 8;                    /* 计算所在页 */
    bx  = y % 8;                    /* 计算字节中的位 */
    temp = 1 << bx;

    if (dot)
    {
        g_oled_gram[x][pos] |= temp;
    }
    else
    {
        g_oled_gram[x][pos] &= ~temp;
    }
}

// 区域填充
void oled_fill(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t dot)
{
    uint8_t x, y;

    for (x = x1; x <= x2; x++)
    {
        for (y = y1; y <= y2; y++)
        {
            oled_draw_point(x, y, dot);
        }
    }

    oled_refresh_gram();
}

// 显示一个ASCII字符
void oled_show_char(uint8_t x, uint8_t y, uint8_t chr, uint8_t size, uint8_t mode)
{
    uint8_t temp, t, t1;
    uint8_t y0 = y;
    uint8_t *pfont = 0;
    uint8_t csize = (size / 8 + ((size % 8) ? 1 : 0)) * (size / 2);
    chr = chr - ' ';

    if (y + size > 32)    return;

    if (size == 12)
    {
        pfont = (uint8_t *)oled_asc2_1206[chr];
    }
    else if (size == 16)
    {
        pfont = (uint8_t *)oled_asc2_1608[chr];
    }
    else if (size == 24)
    {
        pfont = (uint8_t *)oled_asc2_2412[chr];
    }
    else
    {
        return;
    }

    for (t = 0; t < csize; t++)
    {
        temp = pfont[t];

        for (t1 = 0; t1 < 8; t1++)
        {
            if (temp & 0x80)
            {
                oled_draw_point(x, y, mode);
            }
            else
            {
                oled_draw_point(x, y, !mode);
            }

            temp <<= 1;
            y++;

            if ((y - y0) == size)
            {
                y = y0;
                x++;
                break;
            }
        }
    }
}

// 显示8x8 ASCII字符
static void oled_show_char_8x8(uint8_t x, uint8_t y, uint8_t chr)
{
    uint8_t i, b;
    uint8_t offset = chr - ' ';
    const uint8_t* font = oled_asc2_8x8[offset];

    for (i = 0; i < 8; i++)
    {
        uint8_t line = font[i];
        for (b = 0; b < 8; b++)
        {
            if (line & (1 << (7 - b)))
            {
                oled_draw_point(x + b, y + i, 1);
            }
        }
    }
}

// m^n
static uint32_t oled_pow(uint8_t m, uint8_t n)
{
    uint32_t result = 1;

    while (n--)
    {
        result *= m;
    }

    return result;
}

// 显示数字
void oled_show_num(uint8_t x, uint8_t y, uint32_t num, uint8_t len, uint8_t size)
{
    uint8_t t, temp;
    uint8_t enshow = 0;

    for (t = 0; t < len; t++)
    {
        temp = (num / oled_pow(10, len - t - 1)) % 10;

        if (enshow == 0 && t < (len - 1))
        {
            if (temp == 0)
            {
                oled_show_char(x + (size / 2) * t, y, ' ', size, 1);
                continue;
            }
            else
            {
                enshow = 1;
            }
        }

        oled_show_char(x + (size / 2) * t, y, temp + '0', size, 1);
    }
}

// 显示字符串
void oled_show_string(uint8_t x, uint8_t y, const char *p, uint8_t size)
{
    while ((*p <= '~') && (*p >= ' '))
    {
        if (size == 8)
        {
            if (x > (128 - 8))
            {
                x = 0;
                y += 8;
            }
        }
        else
        {
            if (x > (128 - (size / 2)))
            {
                x = 0;
                y += size;
            }
        }

        if (y > (31 - (size == 8 ? 8 : size)))
        {
            y = x = 0;
            oled_clear();
        }

        if (size == 8)
        {
            oled_show_char_8x8(x, y, *p);
        }
        else
        {
            oled_show_char(x, y, *p, size, 1);
        }

        x += (size == 8) ? 8 : (size / 2);
        p++;
    }
}

// 画圆
void oled_draw_circle(uint8_t cx, uint8_t cy, uint8_t r)
{
    int8_t x = 0, y = r;
    int16_t d = 1 - r;

    oled_draw_point(cx, cy, 1);

    while (x <= y)
    {
        oled_draw_point(cx + x, cy + y, 1);
        oled_draw_point(cx + y, cy + x, 1);
        oled_draw_point(cx + y, cy - x, 1);
        oled_draw_point(cx + x, cy - y, 1);
        oled_draw_point(cx - x, cy - y, 1);
        oled_draw_point(cx - y, cy - x, 1);
        oled_draw_point(cx - y, cy + x, 1);
        oled_draw_point(cx - x, cy + y, 1);

        if (d < 0)
        {
            d += 2 * x + 3;
        }
        else
        {
            d += 2 * (x - y) + 5;
            y--;
        }
        x++;
    }

    oled_refresh_gram();
}

// OLED初始化 (SSD1306 128x32)
void oled_init(void)
{
    iic_init();     /* IIC初始化 */

    oled_wr_byte(0xAE, OLED_CMD);   /* 关闭显示 */
    oled_wr_byte(0xD5, OLED_CMD);   /* 设置时钟分频 */
    oled_wr_byte(80, OLED_CMD);
    oled_wr_byte(0xA8, OLED_CMD);   /* 设置复用率 */
    oled_wr_byte(0X1F, OLED_CMD);   /* 32行 */
    oled_wr_byte(0xD3, OLED_CMD);   /* 设置显示偏移 */
    oled_wr_byte(0X00, OLED_CMD);

    oled_wr_byte(0x40, OLED_CMD);   /* 设置起始行 */

    oled_wr_byte(0x8D, OLED_CMD);   /* 电荷泵使能 */
    oled_wr_byte(0x14, OLED_CMD);
    oled_wr_byte(0x20, OLED_CMD);   /* 内存地址模式 */
    oled_wr_byte(0x02, OLED_CMD);   /* 页地址模式 */
    oled_wr_byte(0xA1, OLED_CMD);   /* 左右镜像 */
    oled_wr_byte(0xC8, OLED_CMD);   /* 上下镜像 */
    oled_wr_byte(0xDA, OLED_CMD);   /* COM引脚配置 */
    oled_wr_byte(0x02, OLED_CMD);

    oled_wr_byte(0x81, OLED_CMD);   /* 对比度设置 */
    oled_wr_byte(0xEF, OLED_CMD);
    oled_wr_byte(0xD9, OLED_CMD);   /* 预充电周期 */
    oled_wr_byte(0xf1, OLED_CMD);
    oled_wr_byte(0xDB, OLED_CMD);   /* VCOMH电压 */
    oled_wr_byte(0x30, OLED_CMD);

    oled_wr_byte(0xA4, OLED_CMD);   /* 全屏显示开关 */
    oled_wr_byte(0xA6, OLED_CMD);   /* 正常显示 */
    oled_wr_byte(0xAF, OLED_CMD);   /* 开启显示 */
    oled_clear();
}
