// OLED 驱动头文件（SSD1306, I2C 接口）

#ifndef __OLED_H
#define __OLED_H

#include "stdlib.h"
#include "HeaderFiles.h"

#define OLED_CMD        0       /* 写命令 */
#define OLED_DATA       1       /* 写数据 */

// SSD1306 7位 I2C 地址（写地址为 0x78）
#define OLED_SLAVE_ADDR 0x3C

static void oled_wr_byte(uint8_t data, uint8_t cmd);
static uint32_t oled_pow(uint8_t m, uint8_t n);

void oled_init(void);
void oled_clear(void);
void oled_display_on(void);
void oled_display_off(void);
void oled_refresh_gram(void);
void oled_draw_point(uint8_t x, uint8_t y, uint8_t dot);
void oled_fill(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t dot);
void oled_show_char(uint8_t x, uint8_t y, uint8_t chr, uint8_t size, uint8_t mode);
void oled_show_num(uint8_t x, uint8_t y, uint32_t num, uint8_t len, uint8_t size);
void oled_show_string(uint8_t x, uint8_t y, const char *p, uint8_t size);
void OLED_Show_Font(uint16_t x,uint16_t y,uint8_t fnum);
void OLED_Show_Font_Test(uint16_t x,uint16_t y,uint8_t fnum1);
void oled_draw_line(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
void oled_draw_circle(uint8_t cx, uint8_t cy, uint8_t r);
void oled_clear_line(uint8_t line);

#endif
