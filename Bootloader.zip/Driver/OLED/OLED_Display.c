// OLED 显示应用层 — 初始化页面、清除、更新

#include "OLED_Display.h"
#include <stdio.h>

static void OLED_Display_ShowInitPage(void);

// 初始化OLED显示模块
void OLED_Display_Init(void)
{
    /* 底层OLED硬件初始化（包含I2C初始化） */
    oled_init();
		oled_display_on();
    /* 立即显示初始化页面 */
    OLED_Display_ShowInitPage();
}

// 显示初始化页面
void OLED_Display_Init_Page(void)
{

    OLED_Display_ShowInitPage();
}

// 清除显示
void OLED_Display_Clear(void)
{
    oled_clear();
}

// 更新显示（刷新GRAM）
void OLED_Display_Update(void)
{
    /* 根据当前页面执行相应显示刷新，目前只有初始化页面，只需刷新GRAM */
    oled_refresh_gram();
}

// 显示 “System Idle” 初始化页面
static void OLED_Display_ShowInitPage(void)
{
    /* 清屏后居中显示 */
    oled_clear();

    /* 屏幕宽度128，字符宽度16（FONT_16X8），字符串长度11+1空格 */
    /* 计算起始X坐标使其大致居中：(128 - 16 * 字符数) / 2 */
    /* “System Idle”共11个字符，若用16点宽字体，像素宽度=11*8=88，居中X=(128-88)/2=20 */
    /* 纵坐标Y=2*8=16，大约垂直居中 */
    oled_show_string(20, 12, "System Idle", FONT_16X8);
		OLED_Display_Update();
}
