#ifndef OLED_DISPLAY_H
#define OLED_DISPLAY_H

#include "stdint.h"
#include "oled.h"
#include "HeaderFiles.h"
/* 字体大小定义（与底层OLED驱动兼容） */
#define FONT_8X8    8
#define FONT_12X6   12
#define FONT_16X8   16
#define FONT_24X12  24

/* 通用字体别名 */
#define OLED_FONT_SIZE   FONT_16X8      /* 默认16像素高字体 */
#define OLED_FONT_SMALL  FONT_8X8       /* 小字体8像素高 */

/* 显示页面枚举 */
typedef enum {
    OLED_PAGE_INIT = 0,      /* 初始化页面 */
} OLED_Page_t;

/* 函数声明 */
void OLED_Display_Init(void);
void OLED_Display_Init_Page(void);
void OLED_Display_Clear(void);
void OLED_Display_Update(void);

#endif /* OLED_DISPLAY_H */
