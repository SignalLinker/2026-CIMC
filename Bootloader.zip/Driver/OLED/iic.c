// OLED 硬件I2C驱动 — 超时自动发送STOP，防止总线死锁


#include "iic.h"

// 初始化硬件I2C外设及GPIO

void iic_init(void)
{
    /* 配置GPIO时钟 */
    rcu_periph_clock_enable(OLED_IIC_SCL_GPIO_CLK);
    rcu_periph_clock_enable(OLED_IIC_SDA_GPIO_CLK);
    rcu_periph_clock_enable(OLED_I2C_CLK);

    /* 将PB8/PB9配置为I2C复用功能 */
    gpio_af_set(OLED_IIC_SCL_GPIO_PORT, GPIO_AF_4, OLED_IIC_SCL_GPIO_PIN);
    gpio_af_set(OLED_IIC_SDA_GPIO_PORT, GPIO_AF_4, OLED_IIC_SDA_GPIO_PIN);

    /* 配置SCL/SDA引脚为复用开漏输出 */
    gpio_mode_set(OLED_IIC_SCL_GPIO_PORT, GPIO_MODE_AF, GPIO_PUPD_PULLUP, OLED_IIC_SCL_GPIO_PIN);
    gpio_output_options_set(OLED_IIC_SCL_GPIO_PORT, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, OLED_IIC_SCL_GPIO_PIN);

    gpio_mode_set(OLED_IIC_SDA_GPIO_PORT, GPIO_MODE_AF, GPIO_PUPD_PULLUP, OLED_IIC_SDA_GPIO_PIN);
    gpio_output_options_set(OLED_IIC_SDA_GPIO_PORT, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, OLED_IIC_SDA_GPIO_PIN);

    /* 复位并配置I2C0外设 */
    i2c_deinit(OLED_I2C);
    i2c_clock_config(OLED_I2C, OLED_I2C_SPEED, I2C_DTCY_2);  /* 快速模式, 占空比2 */
    i2c_mode_addr_config(OLED_I2C, I2C_I2CMODE_ENABLE, I2C_ADDFORMAT_7BITS, OLED_I2C_SLAVE_ADDRESS);
    i2c_enable(OLED_I2C);

    /* 使能应答（主机发送ACK，接收时默认ACK使能） */
    i2c_ack_config(OLED_I2C, I2C_ACK_ENABLE);
}

// 发送I2C起始条件

void iic_start(void)
{
    uint32_t timeout = I2C_TIMEOUT_COUNT;
    /* 等待总线空闲 */
    while(i2c_flag_get(OLED_I2C, I2C_FLAG_I2CBSY) && timeout--);

    /* 发送起始条件 */
    i2c_start_on_bus(OLED_I2C);

    /* 等待SBSEND标志 (起始条件已发送) */
    timeout = I2C_TIMEOUT_COUNT;
    while(!i2c_flag_get(OLED_I2C, I2C_FLAG_SBSEND) && timeout--);
}

// 发送I2C停止条件

void iic_stop(void)
{
    uint32_t timeout;   /* 变量声明必须在函数开头 */

    i2c_stop_on_bus(OLED_I2C);

    /* 等待停止条件发送完成（STOP位硬件自动清除） */
    timeout = I2C_TIMEOUT_COUNT;
    while((I2C_CTL0(OLED_I2C) & I2C_CTL0_STOP) && timeout--);
}

// 等待从机应答，返回0成功，1超时

uint8_t iic_wait_ack(void)
{
    uint32_t timeout = I2C_TIMEOUT_COUNT;

    /* 等待ADDSEND标志 (地址已发送) */
    while(!i2c_flag_get(OLED_I2C, I2C_FLAG_ADDSEND) && timeout--);

    if(timeout == 0) {
        iic_stop();   /* 超时则发送停止条件 */
        return 1;
    }

    /* 使用标准库函数清除ADDSEND */
    i2c_flag_clear(OLED_I2C, I2C_FLAG_ADDSEND);
    return 0;
}

// ACK/NACK 由硬件自动控制，保留空函数兼容旧接口
void iic_ack(void)
{
}

void iic_nack(void)
{
}

// 通过硬件I2C发送一个字节

void iic_send_byte(uint8_t data)
{
    uint32_t timeout;

    /* 等待发送缓冲区为空 */
    timeout = I2C_TIMEOUT_COUNT;
    while(!i2c_flag_get(OLED_I2C, I2C_FLAG_TBE) && timeout--);
    if(timeout == 0) {
        iic_stop();   /* 超时发送停止条件，释放总线 */
        return;
    }

    /* 发送数据 */
    i2c_data_transmit(OLED_I2C, data);

    /* 等待字节传输完成（BTC标志） */
    timeout = I2C_TIMEOUT_COUNT;
    while(!i2c_flag_get(OLED_I2C, I2C_FLAG_BTC) && timeout--);
}

// 通过硬件I2C读取一个字节，ack=1发送ACK，0发送NACK

uint8_t iic_read_byte(uint8_t ack)
{
    uint32_t timeout;   /* 声明必须在执行语句前 */

    /* 先根据 ack 参数配置 ACKEN，硬件会在下一个字节接收完成时使用该值 */
    if(ack) {
        i2c_ack_config(OLED_I2C, I2C_ACK_ENABLE);
    } else {
        i2c_ack_config(OLED_I2C, I2C_ACK_DISABLE);
    }

    /* 如果 ADDSEND 标志还在（说明从机地址刚发送完），清除它并启动接收 */
    if(i2c_flag_get(OLED_I2C, I2C_FLAG_ADDSEND) == SET) {
        i2c_flag_clear(OLED_I2C, I2C_FLAG_ADDSEND);
    }

    /* 等待接收缓冲区非空（RBNE） */
    timeout = I2C_TIMEOUT_COUNT;
    while(!i2c_flag_get(OLED_I2C, I2C_FLAG_RBNE) && timeout--);

    if(timeout == 0) {
        iic_stop();   /* 超时发送停止条件 */
        return 0xFF;  /* 返回一个无效值供调用者识别 */
    }

    /* 读取并返回数据 */
    return i2c_data_receive(OLED_I2C);
}
