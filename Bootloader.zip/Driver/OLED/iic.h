// OLED 硬件I2C驱动头文件

#ifndef __MYIIC_H
#define __MYIIC_H

#include "HeaderFiles.h"
#define OLED_I2C                        I2C0
#define OLED_I2C_CLK                    RCU_I2C0

#define OLED_I2C_SPEED                  400000      /* 400KHz, 快速模式 */
#define OLED_I2C_SLAVE_ADDRESS          0x3C        /* SSD1306 7位地址 0x3C（默认） */
#define I2C_TIMEOUT_COUNT               1000        /* 标志位等待超时计数值 */

// 引脚定义 PB8(SCL) / PB9(SDA)
#define OLED_IIC_SCL_GPIO_PORT          GPIOB
#define OLED_IIC_SCL_GPIO_PIN           GPIO_PIN_8
#define OLED_IIC_SCL_GPIO_CLK           RCU_GPIOB

#define OLED_IIC_SDA_GPIO_PORT          GPIOB
#define OLED_IIC_SDA_GPIO_PIN           GPIO_PIN_9
#define OLED_IIC_SDA_GPIO_CLK           RCU_GPIOB

void iic_init(void);                    /* 初始化I2C外设 */
//void iic_set_slave_addr(uint8_t addr);  /* 动态设置从机地址（新增） */
void iic_start(void);                   /* 发送起始条件 */
void iic_stop(void);                    /* 发送停止条件 */
uint8_t iic_wait_ack(void);             /* 等待从机应答（硬件自动处理） */
void iic_send_byte(uint8_t data);       /* 发送一个字节 */
uint8_t iic_read_byte(uint8_t ack);     /* 读取一个字节，ack=1时发送ACK,=0时发送NACK */
void iic_ack(void);                     /* 保留，硬件I2C模式下为空 */
void iic_nack(void);                    /* 保留，硬件I2C模式下为空 */

#endif
