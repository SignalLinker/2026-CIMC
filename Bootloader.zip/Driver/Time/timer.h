// 定时器接口 — TIMER2 20ms 中断

#ifndef __TIMER_H__
#define __TIMER_H__

#include "HeaderFiles.h"

void my_timer_init(void);

#endif
