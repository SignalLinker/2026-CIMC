// LED 驱动 — GPIO 初始化

#include "LED.h"

// LED GPIO 端口初始化
void LED_Init(void)
{
	
	rcu_periph_clock_enable(RCU_GPIOE);    // 使能 GPIOE 时钟
	rcu_periph_clock_enable(RCU_GPIOC);    // 使能 GPIOC 时钟

	// LED4 端口配置 (PC13)
	gpio_mode_set(LED_PORT_4, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, LED_PORT_PIN4);   			// 输出模式
  gpio_output_options_set(LED_PORT_4, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, LED_PORT_PIN4);   // 推挽输出
	gpio_bit_reset(LED_PORT_4, LED_PORT_PIN4);  											// 初始低电平

	// LED1~LED3 端口配置
	gpio_mode_set(KEY_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, LED_PORT_PIN1|LED_PORT_PIN2|LED_PORT_PIN3);   			// 输出模式
  gpio_output_options_set(KEY_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, LED_PORT_PIN1|LED_PORT_PIN2|LED_PORT_PIN3);     // 推挽输出
	gpio_bit_reset(GPIOA, LED_PORT_PIN1|LED_PORT_PIN2|LED_PORT_PIN3);  										     	// 初始低电平
	
	
}




