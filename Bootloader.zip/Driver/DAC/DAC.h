// DAC 驱动接口 — PA4(DAC_OUT0), 12bit, 0~3.3V

#ifndef __DAC_H
#define __DAC_H

#include "HeaderFiles.h"

#define DAC_VREF         3.3f           /* 参考电压 */
#define DAC_RESOLUTION   4095U          /* 12bit 最大值 */

void DAC_Init(void);                     /* DAC初始化（PA4, 输出缓冲使能） */
void DAC_SetValue(uint16_t value);       /* 设置 DAC 原始值（0~4095） */
void DAC_SetVoltage(float voltage);      /* 设置 DAC 输出电压（0~3.3V） */
void DAC_Follow_ADC(uint16_t adc_raw, float ratio); /* ADC→DAC联动输出 */

#endif
