// ADC 驱动 — GPIO 配置、初始化、读取与测试打印

#include "ADC.h"


uint16_t adc_value;                        /* 最新 ADC 读数 */
uint16_t adc_value_buf[ADC_BUF_SIZE];      /* ADC 历史缓存 */
static uint8_t adc_buf_index = 0;          /* 缓存写入位置 */
static uint8_t uart_flag = 0;

// ADC 端口初始化，使能时钟和 GPIO
void ADC_port_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOC);
    rcu_periph_clock_enable(RCU_ADC0);

    gpio_mode_set(GPIOC, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, GPIO_PIN_0);

    adc_clock_config(ADC_ADCCK_PCLK2_DIV8);

    ADC_Init();

    adc_software_trigger_enable(ADC0, ADC_ROUTINE_CHANNEL);
}

// ADC 初始化：连续模式、通道10、软件触发
void ADC_Init(void)
{
    adc_deinit();

    adc_special_function_config(ADC0, ADC_CONTINUOUS_MODE, ENABLE);
    adc_data_alignment_config(ADC0, ADC_DATAALIGN_RIGHT);
    adc_channel_length_config(ADC0, ADC_ROUTINE_CHANNEL, 1);

    adc_routine_channel_config(ADC0, 0, ADC_CHANNEL_10, ADC_SAMPLETIME_56);

    adc_external_trigger_source_config(ADC0, ADC_ROUTINE_CHANNEL, ADC_EXTTRIG_INSERTED_T0_CH3);
    adc_external_trigger_config(ADC0, ADC_ROUTINE_CHANNEL, ENABLE);

    adc_enable(ADC0);

    delay_1ms(1);

    adc_calibration_enable(ADC0);
}

// 读取 ADC 值并更新环形缓存
void ADC_Value_Update(void)
{
    adc_value = adc_routine_data_read(ADC0);

    adc_value_buf[adc_buf_index] = adc_value;
    adc_buf_index = (adc_buf_index + 1) % ADC_BUF_SIZE;
}

// 返回最新 ADC 读数
uint16_t ADC_Get_Value(void)
{
    return adc_value;
}

// ADC 测试：更新值并串口打印（首次调用时输出）
void ADC_Test_Print(void)
{
    /* 更新ADC值 */
    ADC_Value_Update();
    
		if(uart_flag==0){
    /* 通过串口打印ADC值 */
    printf("adc_value: %d\n", ADC_Get_Value());
		uart_flag = 1;
		}
}

