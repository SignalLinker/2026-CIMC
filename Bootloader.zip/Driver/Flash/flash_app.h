// Flash 应用层接口

#ifndef __FLASH_APP_H
#define __FLASH_APP_H
#include "HeaderFiles.h"

// Flash 存储区规划
#define FLASH_BASE_ADDR          0x00000000

// Flash 存储区域划分
#define FLASH_PARAM_ADDR          0x00010000  /* 参数存储区起始地址（64KB处） */
#define FLASH_DATA_ADDR           0x00020000  /* 数据存储区起始地址（128KB处） */
#define FLASH_LOG_ADDR            0x00030000  /* 日志存储区起始地址（192KB处） */

// 参数区大小
#define FLASH_PARAM_SIZE          4096        /* 参数区大小：4KB（1个扇区） */

// Flash总容量
#define FLASH_MAX_ADDR            0x100000    /* 1MB Flash最大地址 */

// Flash 操作状态枚举
typedef enum
{
    FLASH_OK = 0,                /* 操作成功 */
    FLASH_ERROR = 1,              /* 操作失败 */
    FLASH_BUSY = 2,               /* Flash忙 */
    FLASH_TIMEOUT = 3,           /* 操作超时 */
    FLASH_ADDR_ERROR = 4,        /* 地址错误 */
    FLASH_SIZE_ERROR = 5,        /* 大小错误 */
    FLASH_NULL_ERROR = 6         /* 空指针错误 */
} flash_status_t;

// Flash 参数结构体
typedef struct
{
    uint8_t device_name[16];     /* 设备名称 */
    uint8_t firmware_version[8]; /* 固件版本 */
    uint32_t config_flag;        /* 配置标志 */
    uint32_t param_addr;         /* 参数存储地址 */
    uint32_t data_addr;          /* 数据存储地址 */
    uint32_t log_addr;           /* 日志存储地址 */
    uint16_t param_size;        /* 参数大小 */
    uint16_t data_size;          /* 数据大小 */
} flash_param_t;

// Flash 存储信息结构体
typedef struct
{
    uint32_t total_size;         /* Flash总大小 */
    uint32_t sector_size;        /* 扇区大小 */
    uint32_t page_size;          /* 页大小 */
    uint32_t device_id;          /* 设备ID */
    uint8_t is_initialized;      /* 初始化标志 */
    uint8_t is_busy;             /* 忙标志 */
} flash_info_t;

// 基础操作
flash_status_t flash_app_init(void);
uint32_t flash_app_read_id(void);
flash_status_t flash_app_get_info(flash_info_t *pflash_info);

// 数据读写
flash_status_t flash_app_read(uint32_t read_addr, uint8_t *pbuffer, uint32_t num_byte_to_read);
flash_status_t flash_app_write(uint32_t write_addr, uint8_t *pbuffer, uint32_t num_byte_to_write);
flash_status_t flash_app_read_sector(uint32_t sector_addr, uint8_t *pbuffer);
flash_status_t flash_app_write_sector(uint32_t sector_addr, uint8_t *pbuffer);

// 参数管理
flash_status_t flash_app_param_init(void);
flash_status_t flash_app_param_read(flash_param_t *pparam);
flash_status_t flash_app_param_save(flash_param_t *pparam);
flash_status_t flash_app_param_erase(void);

// 区域管理
flash_status_t flash_app_erase(uint32_t start_addr, uint32_t num_byte_to_erase);
flash_status_t flash_app_erase_data_area(void);
flash_status_t flash_app_erase_all(void);
flash_status_t flash_app_verify_blank(uint32_t start_addr, uint32_t size);

// 状态检测与错误处理
uint8_t flash_app_is_busy(void);
flash_status_t flash_app_wait_idle(uint32_t timeout_ms);
uint8_t flash_app_is_exist(void);
flash_status_t flash_app_get_error(void);
void flash_app_clear_error(void);

// 辅助函数
void flash_app_print_info(void);
flash_status_t flash_app_memcpy_to_flash(uint32_t dest_addr, const uint8_t *psrc, uint32_t size);
flash_status_t flash_app_memcpy_from_flash(uint8_t *pdest, uint32_t src_addr, uint32_t size);

#endif
