// Flash 应用层 — 读写、参数管理、区域擦除

#include "flash_app.h"
static flash_info_t g_flash_info = {0};        /* Flash信息结构体 */
static flash_status_t g_flash_error = FLASH_OK; /* Flash错误状态 */
static uint8_t g_flash_initialized = 0;         /* 初始化标志 */
static flash_status_t flash_app_check_addr(uint32_t addr, uint32_t size);
static void flash_app_set_error(flash_status_t status);

// Flash 应用层初始化

flash_status_t flash_app_init(void)
{
    /* 初始化底层SPI Flash硬件 */
    spi_flash_init();

    /* 读取Flash设备ID */
    g_flash_info.device_id = spi_flash_read_id();

    /* 初始化Flash信息 */
    g_flash_info.total_size = FLASH_MAX_ADDR;
    g_flash_info.sector_size = SPI_FLASH_SEC_SZ;
    g_flash_info.page_size = SPI_FLASH_PAGE_SZ;
    g_flash_info.is_initialized = 1;
    g_flash_info.is_busy = 0;

    g_flash_initialized = 1;
    flash_app_clear_error();

    return FLASH_OK;
}

// 读取Flash设备ID

uint32_t flash_app_read_id(void)
{
    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return 0;
    }
    return spi_flash_read_id();
}

// 获取Flash状态信息

flash_status_t flash_app_get_info(flash_info_t *pflash_info)
{
    if (pflash_info == NULL) {
        flash_app_set_error(FLASH_NULL_ERROR);
        return FLASH_NULL_ERROR;
    }

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    /* 复制Flash信息 */
    pflash_info->total_size = g_flash_info.total_size;
    pflash_info->sector_size = g_flash_info.sector_size;
    pflash_info->page_size = g_flash_info.page_size;
    pflash_info->device_id = g_flash_info.device_id;
    pflash_info->is_initialized = g_flash_info.is_initialized;
    pflash_info->is_busy = g_flash_info.is_busy;

    return FLASH_OK;
}

// 从Flash读取数据

flash_status_t flash_app_read(uint32_t read_addr, uint8_t *pbuffer, uint32_t num_byte_to_read)
{
    /* 参数检查 */
    if (pbuffer == NULL) {
        flash_app_set_error(FLASH_NULL_ERROR);
        return FLASH_NULL_ERROR;
    }

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    /* 地址和大小检查 */
    if (flash_app_check_addr(read_addr, num_byte_to_read) != FLASH_OK) {
        return FLASH_ADDR_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 调用底层读取函数 */
    spi_flash_buffer_read(pbuffer, read_addr, num_byte_to_read);

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 向Flash写入数据（自动处理分页和扇区边界）

flash_status_t flash_app_write(uint32_t write_addr, uint8_t *pbuffer, uint32_t num_byte_to_write)
{
    /* 参数检查 */
    if (pbuffer == NULL) {
        flash_app_set_error(FLASH_NULL_ERROR);
        return FLASH_NULL_ERROR;
    }

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    /* 地址和大小检查 */
    if (flash_app_check_addr(write_addr, num_byte_to_write) != FLASH_OK) {
        return FLASH_ADDR_ERROR;
    }

    if (num_byte_to_write == 0) {
        flash_app_set_error(FLASH_SIZE_ERROR);
        return FLASH_SIZE_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 调用底层写入函数（自动处理分页） */
    spi_flash_buffer_write(pbuffer, write_addr, num_byte_to_write);

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 读取Flash一个扇区

flash_status_t flash_app_read_sector(uint32_t sector_addr, uint8_t *pbuffer)
{
    /* 参数检查 */
    if (pbuffer == NULL) {
        flash_app_set_error(FLASH_NULL_ERROR);
        return FLASH_NULL_ERROR;
    }

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    /* 扇区地址必须对齐 */
    if ((sector_addr % SPI_FLASH_SEC_SZ) != 0) {
        flash_app_set_error(FLASH_ADDR_ERROR);
        return FLASH_ADDR_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 读取整个扇区数据 */
    spi_flash_buffer_read(pbuffer, sector_addr, SPI_FLASH_SEC_SZ);

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 写入Flash一个扇区（先擦后写）

flash_status_t flash_app_write_sector(uint32_t sector_addr, uint8_t *pbuffer)
{
    /* 参数检查 */
    if (pbuffer == NULL) {
        flash_app_set_error(FLASH_NULL_ERROR);
        return FLASH_NULL_ERROR;
    }

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    /* 扇区地址必须对齐 */
    if ((sector_addr % SPI_FLASH_SEC_SZ) != 0) {
        flash_app_set_error(FLASH_ADDR_ERROR);
        return FLASH_ADDR_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 先擦除扇区 */
    spi_flash_sector_erase(sector_addr);

    /* 等待擦除完成 */
    spi_flash_wait_for_write_end();

    /* 写入数据 */
    spi_flash_buffer_write(pbuffer, sector_addr, SPI_FLASH_SEC_SZ);

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 初始化Flash参数区（首次运行时写入默认值）

flash_status_t flash_app_param_init(void)
{
    flash_param_t default_param;
    uint32_t temp[2] = {0};

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    /* 设置默认参数 */
    memset(&default_param, 0, sizeof(flash_param_t));
    strcpy((char *)default_param.device_name, "CIMC-IHD-V04");
    strcpy((char *)default_param.firmware_version, "V0.01");
    default_param.config_flag = 0x5A5A5A5A;
    default_param.param_addr = FLASH_PARAM_ADDR;
    default_param.data_addr = FLASH_DATA_ADDR;
    default_param.log_addr = FLASH_LOG_ADDR;
    default_param.param_size = FLASH_PARAM_SIZE;
    default_param.data_size = SPI_FLASH_SEC_SZ;

    /* 先读取看是否已有参数 */
    spi_flash_buffer_read((uint8_t *)temp, FLASH_PARAM_ADDR, sizeof(temp));

    /* 检查配置标志是否正确 */
    if (temp[0] != 0x5A5A5A5A) {
        /* 参数区未初始化，执行初始化 */
        flash_app_param_save(&default_param);
    }

    return FLASH_OK;
}

// 读取Flash参数

flash_status_t flash_app_param_read(flash_param_t *pparam)
{
    /* 参数检查 */
    if (pparam == NULL) {
        flash_app_set_error(FLASH_NULL_ERROR);
        return FLASH_NULL_ERROR;
    }

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 从参数区读取参数 */
    spi_flash_buffer_read((uint8_t *)pparam, FLASH_PARAM_ADDR, sizeof(flash_param_t));

    g_flash_info.is_busy = 0;

    /* 验证参数有效性 */
    if (pparam->config_flag != 0x5A5A5A5A) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    return FLASH_OK;
}

// 保存Flash参数（先擦后写）

flash_status_t flash_app_param_save(flash_param_t *pparam)
{
    /* 参数检查 */
    if (pparam == NULL) {
        flash_app_set_error(FLASH_NULL_ERROR);
        return FLASH_NULL_ERROR;
    }

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 设置配置标志 */
    pparam->config_flag = 0x5A5A5A5A;

    /* 先擦除参数区 */
    spi_flash_sector_erase(FLASH_PARAM_ADDR);
    spi_flash_wait_for_write_end();

    /* 保存参数 */
    spi_flash_buffer_write((uint8_t *)pparam, FLASH_PARAM_ADDR, sizeof(flash_param_t));
    spi_flash_wait_for_write_end();

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 擦除Flash参数区

flash_status_t flash_app_param_erase(void)
{
    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 擦除参数扇区 */
    spi_flash_sector_erase(FLASH_PARAM_ADDR);
    spi_flash_wait_for_write_end();

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 擦除Flash指定区域

flash_status_t flash_app_erase(uint32_t start_addr, uint32_t num_byte_to_erase)
{
    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    /* 地址检查 */
    if (flash_app_check_addr(start_addr, num_byte_to_erase) != FLASH_OK) {
        return FLASH_ADDR_ERROR;
    }

    if (num_byte_to_erase == 0) {
        flash_app_set_error(FLASH_SIZE_ERROR);
        return FLASH_SIZE_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 调用底层缓冲区擦除函数 */
    spi_flash_buffer_erase(start_addr, num_byte_to_erase);

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 擦除Flash数据区

flash_status_t flash_app_erase_data_area(void)
{
    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 擦除数据区起始扇区 */
    spi_flash_sector_erase(FLASH_DATA_ADDR);
    spi_flash_wait_for_write_end();

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 整片擦除

flash_status_t flash_app_erase_all(void)
{
    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 调用底层整片擦除函数 */
    spi_flash_bulk_erase();

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 验证Flash区域是否为空（全部0xFF）

flash_status_t flash_app_verify_blank(uint32_t start_addr, uint32_t size)
{
    uint32_t i;
    uint8_t buffer[256];
    uint32_t remaining = size;

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    /* 地址检查 */
    if (flash_app_check_addr(start_addr, size) != FLASH_OK) {
        return FLASH_ADDR_ERROR;
    }

    g_flash_info.is_busy = 1;

    /* 分批读取验证 */
    while (remaining > 0) {
        uint32_t read_size = (remaining > 256) ? 256 : remaining;
        spi_flash_buffer_read(buffer, start_addr + (size - remaining), read_size);

        /* 检查是否全为0xFF */
        for (i = 0; i < read_size; i++) {
            if (buffer[i] != 0xFF) {
                g_flash_info.is_busy = 0;
                flash_app_set_error(FLASH_ERROR);
                return FLASH_ERROR;
            }
        }
        remaining -= read_size;
    }

    g_flash_info.is_busy = 0;

    return FLASH_OK;
}

// 检测Flash是否忙碌

uint8_t flash_app_is_busy(void)
{
    return g_flash_info.is_busy;
}

// 等待Flash空闲（带超时）

flash_status_t flash_app_wait_idle(uint32_t timeout_ms)
{
    uint32_t count = timeout_ms * 100;

    if (!g_flash_initialized) {
        flash_app_set_error(FLASH_ERROR);
        return FLASH_ERROR;
    }

    /* 简单延时等待 */
    while (count--) {
        if (!g_flash_info.is_busy) {
            return FLASH_OK;
        }
    }

    flash_app_set_error(FLASH_TIMEOUT);
    return FLASH_TIMEOUT;
}

// 检测Flash是否存在

uint8_t flash_app_is_exist(void)
{
    uint32_t flash_id;

    if (!g_flash_initialized) {
        return 0;
    }

    /* 读取Flash ID */
    flash_id = spi_flash_read_id();

    /* 检查是否为有效ID（非0且非0xFFFFFF） */
    if ((flash_id != 0) && (flash_id != 0xFFFFFF)) {
        return 1;
    }

    return 0;
}

// 获取最后一次错误状态

flash_status_t flash_app_get_error(void)
{
    return g_flash_error;
}

// 清除错误状态

void flash_app_clear_error(void)
{
    g_flash_error = FLASH_OK;
}

// 打印Flash信息

void flash_app_print_info(void)
{
    printf("\n========== Flash Information ==========\r\n");
    printf("Device ID: 0x%06X\r\n", g_flash_info.device_id);
    printf("Total Size: %d KB (%d bytes)\r\n",
           g_flash_info.total_size / 1024, g_flash_info.total_size);
    printf("Sector Size: %d bytes\r\n", g_flash_info.sector_size);
    printf("Page Size: %d bytes\r\n", g_flash_info.page_size);
    printf("Initialized: %s\r\n", g_flash_info.is_initialized ? "Yes" : "No");
    printf("Busy Status: %s\r\n", g_flash_info.is_busy ? "Busy" : "Idle");
    printf("Param Address: 0x%08X\r\n", FLASH_PARAM_ADDR);
    printf("Data Address: 0x%08X\r\n", FLASH_DATA_ADDR);
    printf("Log Address: 0x%08X\r\n", FLASH_LOG_ADDR);
    printf("========================================\r\n");
}

// 内存数据写入Flash

flash_status_t flash_app_memcpy_to_flash(uint32_t dest_addr, const uint8_t *psrc, uint32_t size)
{
    if (psrc == NULL) {
        flash_app_set_error(FLASH_NULL_ERROR);
        return FLASH_NULL_ERROR;
    }

    return flash_app_write(dest_addr, (uint8_t *)psrc, size);
}

// Flash数据复制到内存

flash_status_t flash_app_memcpy_from_flash(uint8_t *pdest, uint32_t src_addr, uint32_t size)
{
    if (pdest == NULL) {
        flash_app_set_error(FLASH_NULL_ERROR);
        return FLASH_NULL_ERROR;
    }

    return flash_app_read(src_addr, pdest, size);
}

// 检查地址和大小是否有效

static flash_status_t flash_app_check_addr(uint32_t addr, uint32_t size)
{
    /* 检查地址是否超出范围 */
    if (addr >= FLASH_MAX_ADDR) {
        flash_app_set_error(FLASH_ADDR_ERROR);
        return FLASH_ADDR_ERROR;
    }

    /* 检查结束地址是否超出范围 */
    if ((addr + size) > FLASH_MAX_ADDR) {
        flash_app_set_error(FLASH_ADDR_ERROR);
        return FLASH_ADDR_ERROR;
    }

    return FLASH_OK;
}

// 设置错误状态

static void flash_app_set_error(flash_status_t status)
{
    if (status != FLASH_OK) {
        g_flash_error = status;
    }
}
