// GD32F470VET6 BSP 引脚定义 — USART1 RS485 + OLED I2C0

#ifndef MCU_CIMC_GD32F470VET6_H
#define MCU_CIMC_GD32F470VET6_H

#include "gd32f4xx.h"
#include "gd32f4xx_dma.h"
#include "gd32f4xx_i2c.h"
#include "systick.h"
#include "usart_app.h"
#include "oled.h"

#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

// USART1 引脚 PD5(TX) / PD6(RX)
#define USART1_RX_PORT            GPIOD
#define USART1_RX_PIN             GPIO_PIN_6
#define USART1_TX_PORT            GPIOD
#define USART1_TX_PIN             GPIO_PIN_5

// RS485 on USART1
#define BOARD_RS485_USART         USART1
#define BOARD_RS485_BAUDRATE      19200U
#define BOARD_RS485_RCU           RCU_USART1
#define BOARD_RS485_AF            GPIO_AF_7
#define BOARD_RS485_GPIO_RCU      RCU_GPIOD
#define BOARD_RS485_TX_PORT       USART1_TX_PORT
#define BOARD_RS485_TX_PIN        USART1_TX_PIN
#define BOARD_RS485_RX_PORT       USART1_RX_PORT
#define BOARD_RS485_RX_PIN        USART1_RX_PIN

#define RS232_RS485_USART         BOARD_RS485_USART

/* RS485 DE 控制 (PE8) */
#define RS485_CS_PORT             GPIOE
#define RS485_CS_PORT_RCU         RCU_GPIOE
#define RS485_CS_PIN              GPIO_PIN_8
#define RS485_CS_SET(x)           do { if(x) GPIO_BOP(RS485_CS_PORT) = RS485_CS_PIN; else GPIO_BC(RS485_CS_PORT) = RS485_CS_PIN; } while(0)

// OLED I2C0: PB8=SCL, PB9=SDA
#define OLED_DAT_PORT             GPIOB
#define OLED_DAT_PIN              GPIO_PIN_9
#define OLED_CLK_PORT             GPIOB
#define OLED_CLK_PIN              GPIO_PIN_8
#define OLED_CLK_PORT_RCU         RCU_GPIOB
#define AF_OLED_I2C0              GPIO_AF_4

void bsp_usart_init(void);
void bsp_oled_init(void);
void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowStr(uint8_t x, uint8_t y, const char *str, uint8_t size);

#endif /* MCU_CIMC_GD32F470VET6_H */
