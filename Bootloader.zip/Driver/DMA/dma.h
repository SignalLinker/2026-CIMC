// DMA 驱动接口 — USART0 收发通道

#ifndef __DMA_H__
#define __DMA_H__

#include "HeaderFiles.h"

#define RCU_DMAX RCU_DMA1

#define DMA_USARTX_ADDR (uint32_t)&USART_DATA(USART0)

#define DMA_TRANSFER_X DMA1
#define DMA_TRANSFER_CHANNEL DMA_CH7

#define DMA_RECEIVE_X DMA1
#define DMA_RECEIVE_CHANNEL DMA_CH5

void my_dma_init(void);

#endif
