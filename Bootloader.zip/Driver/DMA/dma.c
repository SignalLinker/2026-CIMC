// DMA 驱动 — USART0 收发通道配置

#include "dma.h"

uint8_t g_transfer_buf[128];
extern uint8_t recv_real_buf[512];

static void dma_transfer_config(void);
static void dma_receive_config(void);

// DMA 初始化：配置发送和接收通道
void my_dma_init(void)
{
	rcu_periph_clock_enable(RCU_DMAX);	// 使能DMA1时钟
	dma_transfer_config();	// 配置DMA发送通道
	dma_receive_config();	// 配置DMA接收通道
}

// DMA 发送通道配置（内存→外设）
void dma_transfer_config(void)
{
	dma_single_data_parameter_struct dma_init_struct;

	dma_deinit(DMA_TRANSFER_X , DMA_TRANSFER_CHANNEL);
	dma_init_struct.direction = DMA_MEMORY_TO_PERIPH;	// 内存到外设
	dma_init_struct.memory0_addr = (uint32_t)g_transfer_buf;	// 发送缓冲区
	dma_init_struct.memory_inc = DMA_MEMORY_INCREASE_ENABLE;	// 内存地址自增
	dma_init_struct.number = sizeof(g_transfer_buf);	// 传输长度
	dma_init_struct.periph_addr = DMA_USARTX_ADDR;	// USART数据寄存器地址
	dma_init_struct.periph_inc = DMA_PERIPH_INCREASE_DISABLE;	// 外设地址不自增
	dma_init_struct.periph_memory_width = DMA_PERIPH_WIDTH_8BIT;	// 8位宽度
	dma_init_struct.priority = DMA_PRIORITY_ULTRA_HIGH;	// 最高优先级
	dma_single_data_mode_init(DMA_TRANSFER_X , DMA_TRANSFER_CHANNEL , &dma_init_struct);
	dma_channel_subperipheral_select(DMA_TRANSFER_X , DMA_TRANSFER_CHANNEL , DMA_SUBPERI4);	// DMA子通道选择
	// 禁用循环模式
	dma_circulation_disable(DMA_TRANSFER_X , DMA_TRANSFER_CHANNEL);
}
// DMA 接收通道配置（外设→内存）
void dma_receive_config(void)
{
	dma_single_data_parameter_struct dma_parameter;

	dma_deinit(DMA_RECEIVE_X , DMA_RECEIVE_CHANNEL);
	dma_parameter.direction = DMA_PERIPH_TO_MEMORY;	// 外设到内存
	dma_parameter.periph_addr = DMA_USARTX_ADDR;	// USART数据寄存器地址
	dma_parameter.periph_inc = DMA_PERIPH_INCREASE_DISABLE;	// 外设地址不自增
	dma_parameter.periph_memory_width = DMA_PERIPH_WIDTH_8BIT;	// 8位宽度
	dma_parameter.memory0_addr = (uint32_t)recv_real_buf;	// 接收缓冲区
	dma_parameter.memory_inc = DMA_MEMORY_INCREASE_ENABLE;	// 内存地址自增
	dma_parameter.number = sizeof(recv_real_buf);	// 接收缓冲区大小
	dma_parameter.priority = DMA_PRIORITY_ULTRA_HIGH;	// 最高优先级
	dma_parameter.circular_mode = DMA_CIRCULAR_MODE_DISABLE;	// 禁用循环模式
	dma_single_data_mode_init(DMA_RECEIVE_X , DMA_RECEIVE_CHANNEL , &dma_parameter);

	dma_channel_subperipheral_select(DMA_RECEIVE_X , DMA_RECEIVE_CHANNEL , DMA_SUBPERI4);	// DMA子通道选择
	dma_channel_enable(DMA_RECEIVE_X , DMA_RECEIVE_CHANNEL);	// 使能DMA接收通道
}
