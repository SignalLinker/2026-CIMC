// RTC 驱动 — 日历、闹钟、串口时间设置

#include "RTC.h"

#define RTC_CLOCK_SOURCE_LXTAL    /* RTC时钟源：LXTAL（外部32.768KHz晶振） */
#define BKP_VALUE    0x32F0       /* 备份寄存器默认值，用于判断RTC是否已配置 */
rtc_parameter_struct   rtc_initpara;      /* RTC初始化参数结构体 */
rtc_alarm_struct  rtc_alarm;              /* RTC闹钟结构体 */
__IO uint32_t prescaler_a = 0, prescaler_s = 0;  /* RTC异步和同步预分频器 */
uint32_t RTCSRC_FLAG = 0;                  /* RTC时钟源标志位 */

// RTC 初始化
void RTC_Init(void)
{
//    printf("\n\r  ****************** RTC calendar demo ******************\n\r");

    /* 使能PMU时钟 */
    rcu_periph_clock_enable(RCU_PMU);
    /* 使能RTC寄存器访问 */
    pmu_backup_write_enable();

    /* RTC预配置 */
    rtc_pre_config();
    /* 获取RTC时钟源选择 */
    RTCSRC_FLAG = GET_BITS(RCU_BDCTL, 8, 9);

    /* 检查RTC是否已经配置过 */
    if((BKP_VALUE != RTC_BKP0) || (0x00 == RTCSRC_FLAG)){
        /* 备份数据寄存器值不正确或尚未编程，或RTC时钟源未配置
           （首次运行程序或RCU_BDCTL中的数据因Vbat供电丢失时） */
//        rtc_setup();
    }else{
        /* 检测复位源 */
        if (RESET != rcu_flag_get(RCU_FLAG_PORRST)){
//            printf("power on reset occurred....\n\r");
        }else if (RESET != rcu_flag_get(RCU_FLAG_EPRST)){
//            printf("external reset occurred....\n\r");
        }
//        printf("no need to configure RTC....\n\r");

        /* 显示当前时间 */
//        rtc_show_time();
    }
    /* 清除所有复位标志 */
    rcu_all_reset_flag_clear();
}

// RTC 预配置：时钟源选择和分频
void rtc_pre_config(void)
{
    #if defined (RTC_CLOCK_SOURCE_IRC32K)
          /* 选择IRC32K作为RTC时钟源 */
          rcu_osci_on(RCU_IRC32K);
          rcu_osci_stab_wait(RCU_IRC32K);
          rcu_rtc_clock_config(RCU_RTCSRC_IRC32K);

          /* 配置RTC异步和同步预分频器 */
          prescaler_s = 0x13F;  /* 同步预分频：32768-1 */
          prescaler_a = 0x63;   /* 异步预分频：128-1 */
    #elif defined (RTC_CLOCK_SOURCE_LXTAL)
          /* 选择LXTAL（外部32.768KHz晶振）作为RTC时钟源 */
          rcu_osci_on(RCU_LXTAL);
          rcu_osci_stab_wait(RCU_LXTAL);
          rcu_rtc_clock_config(RCU_RTCSRC_LXTAL);

          /* 配置RTC异步和同步预分频器 */
          prescaler_s = 0xFF;   /* 同步预分频：256-1 */
          prescaler_a = 0x7F;   /* 异步预分频：128-1 */
    #else
    #error RTC clock source should be defined.
    #endif /* RTC_CLOCK_SOURCE_IRC32K */

    /* 使能RTC外设时钟 */
    rcu_periph_clock_enable(RCU_RTC);
    /* 等待RTC寄存器同步 */
    rtc_register_sync_wait();
}

// 通过串口交互设置RTC时间
void rtc_setup(void)
{
    /* 定义时间输入变量 */
    uint32_t tmp_year = 0xFF, tmp_month = 0xFF, tmp_day = 0xFF;
    uint32_t tmp_hh = 0xFF, tmp_mm = 0xFF, tmp_ss = 0xFF;

    /* 配置RTC初始化参数 */
    rtc_initpara.factor_asyn = prescaler_a;  /* 异步预分频 */
    rtc_initpara.factor_syn = prescaler_s;   /* 同步预分频 */
    rtc_initpara.year = 0x16;                 /* 默认年份：2016年 */
    rtc_initpara.day_of_week = RTC_SATURDAY;  /* 默认星期：星期六 */
    rtc_initpara.month = RTC_APR;              /* 默认月份：4月 */
    rtc_initpara.date = 0x30;                  /* 默认日期：30日 */
    rtc_initpara.display_format = RTC_24HOUR; /* 24小时制 */
    rtc_initpara.am_pm = RTC_AM;               /* 上午 */

    /* 通过串口输入当前时间 */
//    printf("=======Configure RTC Time========\n\r");
//    printf("  please set the last two digits of current year:\n\r");
    while(tmp_year == 0xFF) {
        /* 输入年份（后两位）*/
        tmp_year = usart_input_threshold(99);
        rtc_initpara.year = tmp_year;
    }
//    printf("  20%0.2x\n\r", tmp_year);

//    printf("  please input month:\n\r");
    while(tmp_month == 0xFF) {
        /* 输入月份 */
        tmp_month = usart_input_threshold(12);
        rtc_initpara.month = tmp_month;
    }
//    printf("  %0.2x\n\r", tmp_month);

//    printf("  please input day:\n\r");
    while(tmp_day == 0xFF) {
        /* 输入日期 */
        tmp_day = usart_input_threshold(31);
        rtc_initpara.date = tmp_day;
    }
//    printf("  %0.2x\n\r", tmp_day);

//    printf("  please input hour:\n\r");
    while (0xFF == tmp_hh){
        /* 输入小时 */
        tmp_hh = usart_input_threshold(23);
        rtc_initpara.hour = tmp_hh;
    }
//    printf("  %0.2x\n\r", tmp_hh);

//    printf("  please input minute:\n\r");
    while (0xFF == tmp_mm){
        /* 输入分钟 */
        tmp_mm = usart_input_threshold(59);
        rtc_initpara.minute = tmp_mm;
    }
//    printf("  %0.2x\n\r", tmp_mm);

//    printf("  please input second:\n\r");
    while (0xFF == tmp_ss){
        /* 输入秒 */
        tmp_ss = usart_input_threshold(59);
        rtc_initpara.second = tmp_ss;
    }
//    printf("  %0.2x\n\r", tmp_ss);

    /* 配置RTC当前时间 */
    if(ERROR == rtc_init(&rtc_initpara)){
//        printf("\n\r** RTC time configuration failed! **\n\r");
    }else{
//        printf("\n\r** RTC time configuration success! **\n\r");
        /* 显示配置后的时间 */
        rtc_show_time();
        /* 写入备份寄存器，标记RTC已配置 */
        RTC_BKP0 = BKP_VALUE;
    }
}

// 设置RTC时间（BCD格式），返回0成功，1失败
uint8_t rtc_set_time(uint8_t yy, uint8_t mm, uint8_t dd,
                     uint8_t hh, uint8_t min, uint8_t ss)
{
    rtc_initpara.factor_asyn = prescaler_a;
    rtc_initpara.factor_syn  = prescaler_s;
    rtc_initpara.year        = yy;
    rtc_initpara.month       = mm;
    rtc_initpara.date        = dd;
    rtc_initpara.hour        = hh;
    rtc_initpara.minute      = min;
    rtc_initpara.second      = ss;
    rtc_initpara.display_format = RTC_24HOUR;
    rtc_initpara.am_pm       = RTC_AM;

    if (ERROR == rtc_init(&rtc_initpara)) {
        return 1;
    }
    RTC_BKP0 = BKP_VALUE;
    return 0;
}

// 显示当前RTC时间
void rtc_show_time(void)
{
    /* 获取当前RTC时间 */
    rtc_current_time_get(&rtc_initpara);

    /* 打印当前时间 */
    printf("\r\nCurrent time: 20%0.2x-%0.2x-%0.2x", \
           rtc_initpara.year, rtc_initpara.month, rtc_initpara.date);

    printf(" : %0.2x:%0.2x:%0.2x \r\n", \
           rtc_initpara.hour, rtc_initpara.minute, rtc_initpara.second);
}

// 显示RTC闹钟时间
void rtc_show_alarm(void)
{
    /* 获取RTC闹钟时间 */
    rtc_alarm_get(RTC_ALARM0, &rtc_alarm);
    /* 打印闹钟时间 */
    printf("The alarm: %0.2x:%0.2x:%0.2x \n\r", rtc_alarm.alarm_hour, rtc_alarm.alarm_minute,\
           rtc_alarm.alarm_second);
}

// 串口输入数值校验，返回BCD格式值，失败返回0xFF
uint8_t usart_input_threshold(uint32_t value)
{
    uint32_t index = 0;
    uint32_t tmp[2] = {0, 0};

    /* 读取两个字符（十位和个位）*/
    while (index < 2){
        /* 等待串口接收数据 */
        while (RESET == usart_flag_get(USART0, USART_FLAG_RBNE));
        /* 接收字符 */
        tmp[index++] = usart_data_receive(USART0);
        /* 检查是否为有效数字（0-9）*/
        if ((tmp[index - 1] < 0x30) || (tmp[index - 1] > 0x39)){
            printf("\n\r please input a valid number between 0 and 9 \n\r");
            index--;
        }
    }

    /* 将两个字符转换为数值 */
    index = (tmp[1] - 0x30) + ((tmp[0] - 0x30) * 10);
    /* 检查是否超过上限 */
    if (index > value){
        printf("\n\r please input a valid number between 0 and %d \n\r", value);
        return 0xFF;
    }

    /* 转换为BCD格式并返回 */
    index = (tmp[1] - 0x30) + ((tmp[0] - 0x30) <<4);
    return index;
}
