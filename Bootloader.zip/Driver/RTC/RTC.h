// RTC 驱动接口

#ifndef __RTC_H
#define __RTC_H

#include "HeaderFiles.h"

void RTC_Init(void);
void rtc_setup(void);
void rtc_show_time(void);
void rtc_show_alarm(void);
uint8_t usart_input_threshold(uint32_t value);
void rtc_pre_config(void);

// 设置RTC时间（BCD格式），返回0成功，1失败
uint8_t rtc_set_time(uint8_t yy, uint8_t mm, uint8_t dd,
                     uint8_t hh, uint8_t min, uint8_t ss);

#endif
