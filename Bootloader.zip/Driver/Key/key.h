// 按键驱动接口 — 定时器消抖 + 事件队列

#ifndef __KEY_H
#define __KEY_H

#include "HeaderFiles.h"

// KEY 引脚定义
#define KEY1_PIN        GPIO_PIN_15
#define KEY2_PIN        GPIO_PIN_6
#define KEY3_PIN        GPIO_PIN_11
#define KEY4_PIN        GPIO_PIN_4

// KEY 端口定义
#define KEY_PORT        GPIOE
#define KEY_CLK         RCU_GPIOE

// KEY ID
#define KEY_ID_1        0
#define KEY_ID_2        1
#define KEY_ID_3        2
#define KEY_ID_4        3
#define KEY_NUM         4

void KEY_Init(void);                              /* 按键初始化 */
uint8_t KEY_Stat(uint32_t port, uint16_t pin);    /* 按键状态扫描（阻塞消抖，兼容保留） */
void KEY_Scan_Tick(void);                         /* 定时器驱动消抖扫描，由 TIMER2 ISR 调用 */
uint8_t KEY_Event_Get(uint8_t *key_id);           /* 获取下一个按键事件（非阻塞） */
void KEY1_Toggle_LED1_Test(void);                 /* 按键1控制LED1测试 */

#endif
