// 按键驱动 — 定时器驱动消抖 + 事件队列

#include "KEY.h"

#define KEY_DEBOUNCE_TICKS   2     /* 2 * 20ms = 40ms 确认 */
#define KEY_EVT_QUEUE_SIZE   8

typedef struct {
    uint8_t counter;     /* 连续按下的 20ms 节拍数 */
    uint8_t confirmed;   /* 已确认触发，防重复 */
} key_channel_t;

static uint8_t led1_state = 0;

/* 4 路按键消抖状态 */
static key_channel_t key_ch[KEY_NUM] = {
    {0, 0}, {0, 0}, {0, 0}, {0, 0}
};

/* 按键硬件映射表 */
static const struct {
    uint32_t port;
    uint16_t pin;
} key_hw[KEY_NUM] = {
    {KEY_PORT, KEY1_PIN},
    {KEY_PORT, KEY2_PIN},
    {KEY_PORT, KEY3_PIN},
    {KEY_PORT, KEY4_PIN},
};

/* 事件队列 */
static uint8_t key_evt_buf[KEY_EVT_QUEUE_SIZE];
static uint8_t key_evt_rd = 0;
static uint8_t key_evt_wr = 0;

// 按键硬件初始化

void KEY_Init(void)
{
    rcu_periph_clock_enable(KEY_CLK);

    gpio_mode_set(KEY_PORT, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP,
                  KEY1_PIN | KEY2_PIN | KEY3_PIN | KEY4_PIN);
}

/*!
    \brief      读取按键状态（带阻塞消抖，保留兼容旧代码）
*/
uint8_t KEY_Stat(uint32_t port, uint16_t pin)
{
    if (gpio_input_bit_get(port, pin) == RESET) {
        delay_1ms(20);
        if (gpio_input_bit_get(port, pin) == RESET) {
            return 1;
        }
    }
    return 0;
}

// 定时器驱动扫描 — 每 20ms 由 TIMER2 ISR 调用，消抖后入队事件
void KEY_Scan_Tick(void)
{
    uint8_t i;

    for (i = 0; i < KEY_NUM; i++) {
        if (gpio_input_bit_get(key_hw[i].port, key_hw[i].pin) == RESET) {
            /* 按下中 */
            if (key_ch[i].counter < 255) {
                key_ch[i].counter++;
            }
            if (key_ch[i].counter >= KEY_DEBOUNCE_TICKS && !key_ch[i].confirmed) {
                key_ch[i].confirmed = 1;
                /* 入队事件 */
                uint8_t next = (key_evt_wr + 1) % KEY_EVT_QUEUE_SIZE;
                if (next != key_evt_rd) {
                    key_evt_buf[key_evt_wr] = i;
                    key_evt_wr = next;
                }
            }
        } else {
            /* 释放 */
            key_ch[i].counter  = 0;
            key_ch[i].confirmed = 0;
        }
    }
}

// 获取下一个按键事件（非阻塞），返回 1 表示有事件
uint8_t KEY_Event_Get(uint8_t *key_id)
{
    if (key_evt_rd == key_evt_wr) {
        return 0;
    }
    if (key_id != NULL) {
        *key_id = key_evt_buf[key_evt_rd];
    }
    key_evt_rd = (key_evt_rd + 1) % KEY_EVT_QUEUE_SIZE;
    return 1;
}

// 按键1 控制 LED1 翻转（非阻塞，主循环调用）
void KEY1_Toggle_LED1_Test(void)
{
    uint8_t key_id;

    while (KEY_Event_Get(&key_id)) {
        if (key_id == KEY_ID_1) {
            led1_state = !led1_state;
            if (led1_state) {
                LED1_ON();
            } else {
                LED1_OFF();
            }
        }
    }
}


