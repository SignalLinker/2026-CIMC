// USART 驱动接口

#ifndef __USART_H__
#define __USART_H__

#include "HeaderFiles.h"
#define USART_PORT GPIOA           /* USART端口 */
#define USART USART0               /* USART外设 */
#define USART_TX_Pin GPIO_PIN_9    /* TX引脚 */
#define USART_RX_Pin GPIO_PIN_10   /* RX引脚 */
#define USART_RCU RCU_USART0       /* USART时钟 */
#define USART_PIN_RCU RCU_GPIOA    /* GPIO时钟 */

void usart_init(void);
void usart_recv_buf(void);

/* 通用时间解析：从字符串中提取6个连续数字（跳过任意分隔符） */
uint8_t parse_datetime(uint8_t *buf, uint16_t *yy, uint8_t *mm, uint8_t *dd,
                       uint8_t *hh, uint8_t *min, uint8_t *ss);

#endif
