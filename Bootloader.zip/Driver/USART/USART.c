// USART 驱动 — DMA 收发、指令分发、printf 重定向

#include "usart.h"
#include "dma.h"
#include "led.h"
uint8_t recv_real_buf[512] = { 0 };  /* DMA接收缓冲区 */
uint16_t recv_real_len = 0;          /* 接收数据长度 */
uint8_t recv_flag = 0;               /* 接收完成标志 */

/* 两步交互状态：等待二次输入 */
static uint8_t rtc_config_pending = 0;

/* 指令处理回调类型 */
typedef void (*cmd_handler_t)(void);

/* 指令描述结构体 */
typedef struct {
    const char *cmd;          /* 指令关键字 */
    uint8_t     cmd_len;      /* 关键字长度 */
    cmd_handler_t handler;    /* 处理函数 */
} serial_cmd_t;

// 指令处理函数声明
static void rtc_config_cmd_handler(void);
static void rtc_now_cmd_handler(void);

// 指令表（扩展新指令只需在此加一行）
static const serial_cmd_t cmd_table[] = {
    { "RTC Config", 10, rtc_config_cmd_handler },
    { "RTC now",     7, rtc_now_cmd_handler    },
    /* 扩展示例：
    { "LED ON",      6, led_on_cmd_handler     },
    { "LED OFF",     7, led_off_cmd_handler    },
    */
};
#define CMD_TABLE_SIZE (sizeof(cmd_table) / sizeof(cmd_table[0]))

// 从字符串中提取6个连续数字段（跳过分隔符），顺序：年月日时分秒
uint8_t parse_datetime(uint8_t *buf, uint16_t *yy, uint8_t *mm, uint8_t *dd,
                       uint8_t *hh, uint8_t *min, uint8_t *ss)
{
    uint32_t nums[6] = {0};
    uint8_t  idx = 0;
    uint8_t  in_num = 0;
    uint8_t  *p = buf;

    while (*p && idx < 6) {
        if (*p >= '0' && *p <= '9') {
            nums[idx] = nums[idx] * 10 + (*p - '0');
            in_num = 1;
        } else {
            if (in_num) {
                idx++;
                in_num = 0;
            }
            /* 非数字字符直接跳过（- / : 年月日 空格 等） */
        }
        p++;
    }
    if (in_num) idx++;  /* 处理最后一个数字段 */

    if (idx < 6) return 1;  /* 数字不足6个 */

    *yy  = nums[0];
    *mm  = (uint8_t)nums[1];
    *dd  = (uint8_t)nums[2];
    *hh  = (uint8_t)nums[3];
    *min = (uint8_t)nums[4];
    *ss  = (uint8_t)nums[5];
    return 0;
}

// RTC Config：提示输入时间，进入等待状态

static void rtc_config_cmd_handler(void)
{
    printf("\r\n Input Datetime \r\n");
    rtc_config_pending = 1;
}

// RTC now：读取并显示当前RTC时间

static void rtc_now_cmd_handler(void)
{
    rtc_parameter_struct rtc_time;
    rtc_current_time_get(&rtc_time);

    printf("\r\nCurrent Time: 20%02x-%02x-%02x %02x:%02x:%02x\r\n",
           rtc_time.year, rtc_time.month, rtc_time.date,
           rtc_time.hour, rtc_time.minute, rtc_time.second);
}

// 十进制 → BCD 转换
#define DEC2BCD(v) ((((v) / 10) << 4) | ((v) % 10))

// 解析时间字符串并写入RTC

static void rtc_do_set_time(uint8_t *buf)
{
    uint16_t yy;
    uint8_t  mm, dd, hh, min, ss;

    if (parse_datetime(buf, &yy, &mm, &dd, &hh, &min, &ss) != 0) {
        printf("RTC Config failed: invalid format\r\n");
        rtc_config_pending = 0;
        return;
    }

    /* 转BCD后写入RTC */
    if (rtc_set_time(DEC2BCD(yy % 100), DEC2BCD(mm), DEC2BCD(dd),
                     DEC2BCD(hh), DEC2BCD(min), DEC2BCD(ss)) != 0) {
        printf("RTC Config failed: RTC init error\r\n");
    } else {
        printf("\r\nRTC Config success \r\nTime:%04d-%02d-%02d %02d:%02d:%02d\r\n",
               yy, mm, dd, hh, min, ss);
    }
    rtc_config_pending = 0;
}

// 串口接收数据分发处理
void usart_recv_buf(void)
{
    if (!recv_flag) return;

    /* ---- 步骤1：检查是否处于等待二次输入状态 ---- */
    if (rtc_config_pending) {
        rtc_do_set_time(recv_real_buf);
        goto cleanup;
    }

    /* ---- 步骤2：遍历指令表匹配 ---- */
    uint8_t i;
    for (i = 0; i < CMD_TABLE_SIZE; i++) {
        if (recv_real_len >= cmd_table[i].cmd_len &&
            memcmp(recv_real_buf, cmd_table[i].cmd, cmd_table[i].cmd_len) == 0) {
            cmd_table[i].handler();
            goto cleanup;
        }
    }

    /* ---- 步骤3：未匹配 → 未知指令 ---- */
    printf("Unknown command\r\n");

cleanup:
    memset(recv_real_buf, 0, recv_real_len);
    recv_real_len = 0;
    recv_flag = 0;
}

// 通过USART DMA发送数据
static void usart_dma_send(uint8_t* buf, uint16_t len)
{
    dma_channel_disable(DMA_TRANSFER_X, DMA_TRANSFER_CHANNEL);
    dma_flag_clear(DMA_TRANSFER_X, DMA_TRANSFER_CHANNEL, DMA_FLAG_FTF);
    dma_memory_address_config(DMA_TRANSFER_X, DMA_TRANSFER_CHANNEL, DMA_MEMORY_0, (uint32_t)buf);
    dma_transfer_number_config(DMA_TRANSFER_X, DMA_TRANSFER_CHANNEL, len);
    dma_channel_enable(DMA_TRANSFER_X, DMA_TRANSFER_CHANNEL);
    while (!dma_flag_get(DMA_TRANSFER_X, DMA_TRANSFER_CHANNEL, DMA_FLAG_FTF));
}

// 重定向 printf 到串口
int fputc(int ch, FILE* f)
{
    usart_dma_send((uint8_t*)&ch, 1);
    return ch;
}

// USART 初始化
void usart_init(void)
{
    /* 配置USART中断优先级 */
    nvic_irq_enable(USART0_IRQn, 3, 2);

    /* 使能USART和GPIO时钟 */
    rcu_periph_clock_enable(USART_RCU);
    rcu_periph_clock_enable(USART_PIN_RCU);

    /* 配置TX/RX引脚为复用功能 */
    gpio_af_set(USART_PORT, GPIO_AF_7, USART_TX_Pin | USART_RX_Pin);

    /* 配置GPIO模式 */
    gpio_mode_set(USART_PORT, GPIO_MODE_AF, GPIO_PUPD_NONE, USART_TX_Pin | USART_RX_Pin);
    /* 配置GPIO输出选项 */
    gpio_output_options_set(USART_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, USART_TX_Pin | USART_RX_Pin);

    /* 配置USART参数 */
    usart_deinit(USART);
    usart_baudrate_set(USART, 115200U);
    usart_transmit_config(USART, USART_TRANSMIT_ENABLE);
    usart_receive_config(USART, USART_RECEIVE_ENABLE);
    usart_enable(USART);

    /* 使能USART中断 */
    usart_interrupt_enable(USART, USART_INT_RBNE);
    usart_interrupt_enable(USART, USART_INT_IDLE);

    /* 配置USART的DMA TX/RX */
    usart_dma_transmit_config(USART, USART_TRANSMIT_DMA_ENABLE);
    usart_dma_receive_config(USART, USART_RECEIVE_DMA_ENABLE);

    /* 初始化DMA */
    my_dma_init();
}

// USART0 中断处理（空闲中断 + DMA接收）
void USART0_IRQHandler(void)
{
    recv_real_len = 0;

    /* 判断是否是空闲中断 */
    if (usart_interrupt_flag_get(USART, USART_INT_FLAG_IDLE) != RESET)
    {
        /* 清除中断标志 */
        usart_data_receive(USART);
        /* 关闭DMA通道 */
        dma_channel_disable(DMA_RECEIVE_X, DMA_RECEIVE_CHANNEL);

        /* 计算DMA中已接收到的字节数 */
        recv_real_len = sizeof(recv_real_buf) - dma_transfer_number_get(DMA_RECEIVE_X, DMA_RECEIVE_CHANNEL);

        if (recv_real_len != 0 && recv_real_len < sizeof(recv_real_buf))
        {
            /* 重新配置DMA接收 */
            dma_memory_address_config(DMA_RECEIVE_X, DMA_RECEIVE_CHANNEL, DMA_MEMORY_0, (uint32_t)recv_real_buf);
            dma_transfer_number_config(DMA_RECEIVE_X, DMA_RECEIVE_CHANNEL, sizeof(recv_real_buf));
            dma_flag_clear(DMA_RECEIVE_X, DMA_RECEIVE_CHANNEL, DMA_FLAG_FTF);
            dma_channel_enable(DMA_RECEIVE_X, DMA_RECEIVE_CHANNEL);
            recv_flag = 1;  /* 设置接收完成标志 */
        }
        else
        {
            /* 数据长度异常，清空缓冲区 */
            memset(recv_real_buf, 0, sizeof(recv_real_buf));
        }
    }
}

