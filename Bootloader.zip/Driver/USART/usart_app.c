// USART 应用层 — RS485 初始化和 printf 支持

#include "mcu_cimc_gd32f470vet6.h"
#include <stdarg.h>

void bsp_usart_init(void)
{
    /* 使能 GPIO 和 USART 时钟 */
    rcu_periph_clock_enable(BOARD_RS485_GPIO_RCU);
    rcu_periph_clock_enable(BOARD_RS485_RCU);
    rcu_periph_clock_enable(RS485_CS_PORT_RCU);

    /* 配置 TX (PD5) */
    gpio_af_set(BOARD_RS485_TX_PORT, BOARD_RS485_AF, BOARD_RS485_TX_PIN);
    gpio_mode_set(BOARD_RS485_TX_PORT, GPIO_MODE_AF, GPIO_PUPD_NONE, BOARD_RS485_TX_PIN);
    gpio_output_options_set(BOARD_RS485_TX_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, BOARD_RS485_TX_PIN);

    /* 配置 RX (PD6) */
    gpio_af_set(BOARD_RS485_RX_PORT, BOARD_RS485_AF, BOARD_RS485_RX_PIN);
    gpio_mode_set(BOARD_RS485_RX_PORT, GPIO_MODE_AF, GPIO_PUPD_NONE, BOARD_RS485_RX_PIN);
    gpio_output_options_set(BOARD_RS485_RX_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, BOARD_RS485_RX_PIN);

    /* 配置 RS485 DE (PE8) */
    gpio_mode_set(RS485_CS_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, RS485_CS_PIN);
    gpio_output_options_set(RS485_CS_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, RS485_CS_PIN);
    RS485_CS_SET(0);  /* 默认接收模式 */

    /* 配置 USART */
    usart_deinit(BOARD_RS485_USART);
    usart_baudrate_set(BOARD_RS485_USART, BOARD_RS485_BAUDRATE);
    usart_transmit_config(BOARD_RS485_USART, USART_TRANSMIT_ENABLE);
    usart_receive_config(BOARD_RS485_USART, USART_RECEIVE_ENABLE);
    usart_enable(BOARD_RS485_USART);
}

void bsp_oled_init(void)
{
    rcu_periph_clock_enable(OLED_CLK_PORT_RCU);
    rcu_periph_clock_enable(RCU_I2C0);
    rcu_periph_clock_enable(RCU_DMA0);  /* I2C0 DMA if needed */

    /* 配置 I2C0 SCL (PB8), SDA (PB9) */
    gpio_af_set(OLED_CLK_PORT, AF_OLED_I2C0, OLED_CLK_PIN | OLED_DAT_PIN);
    gpio_mode_set(OLED_CLK_PORT, GPIO_MODE_AF, GPIO_PUPD_PULLUP, OLED_CLK_PIN | OLED_DAT_PIN);
    gpio_output_options_set(OLED_CLK_PORT, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, OLED_CLK_PIN | OLED_DAT_PIN);
}

// printf 支持

int my_printf(uint32_t usart_periph, const char *format, ...)
{
    char buf[256];
    va_list args;
    int len;
    uint32_t i;

    va_start(args, format);
    len = vsnprintf(buf, sizeof(buf), format, args);
    va_end(args);

    if (len <= 0) return 0;

    RS485_CS_SET(1);
    for (i = 0; i < (uint32_t)len && i < sizeof(buf); i++) {
        usart_data_transmit(usart_periph, (uint8_t)buf[i]);
        while (RESET == usart_flag_get(usart_periph, USART_FLAG_TBE));
    }
    while (RESET == usart_flag_get(usart_periph, USART_FLAG_TC));
    RS485_CS_SET(0);

    return len;
}

void uart_task(void)
{
    /* 预留: 串口任务处理 */
}
