// 低功耗深度睡眠模块接口 — EXTI 唤醒 + 时钟恢复

#ifndef __LOWPOWER_H
#define __LOWPOWER_H

#include "HeaderFiles.h"

// 唤醒源 EXTI 配置 — PA0(WK_UP)
#define LOWPOWER_WAKEUP_GPIO        GPIOA
#define LOWPOWER_WAKEUP_PIN         GPIO_PIN_0
#define LOWPOWER_WAKEUP_EXTI_LINE   EXTI_0
#define LOWPOWER_WAKEUP_EXTI_TRIG   EXTI_TRIG_FALLING
#define LOWPOWER_WAKEUP_IRQn        EXTI0_IRQn
#define LOWPOWER_WAKEUP_IRQ_PRIO    2U
#define LOWPOWER_WAKEUP_IRQ_SUBPRIO 0U

//#define HXTAL_STARTUP_TIMEOUT       0x0000FFFFU

// 低功耗模式选择
typedef enum {
    LOWPOWER_MODE_DEEPSLEEP = 0,   /* 深度睡眠（LDO低功耗 + 低驱动 + WFI） */
    LOWPOWER_MODE_SLEEP,            /* 普通睡眠（仅 WFI，外设继续运行） */
} LowPower_Mode_t;

// 唤醒源类型
typedef enum {
    LOWPOWER_WAKEUP_EXTI = 0,      /* EXTI 外部中断唤醒 */
    LOWPOWER_WAKEUP_RTC,            /* RTC 闹钟/周期唤醒（预留） */
    LOWPOWER_WAKEUP_LVD,            /* 低电压检测唤醒（预留） */
} LowPower_WakeupSource_t;

// 进入低功耗模式
void LOWPOWER_EnterDeepSleep(void);
void LOWPOWER_EnterSleep(void);

// EXTI 唤醒源初始化
void LOWPOWER_EXTIWakeup_Init(uint32_t gpio_periph, uint32_t pin,
                               uint8_t exti_line, uint32_t trigger,
                               uint8_t irq_priority);

// 使用默认宏配置初始化唤醒源
void LOWPOWER_EXTIWakeup_DefaultInit(void);

// 唤醒标志管理
FlagStatus LOWPOWER_WakeupFlag_Get(void);
void LOWPOWER_WakeupFlag_Clear(void);

// 回调函数（weak，用户可重定义）
void LOWPOWER_PreSleep_Callback(void);
void LOWPOWER_PostWakeup_Callback(void);

#endif
