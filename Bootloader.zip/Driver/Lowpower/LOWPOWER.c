// 低功耗深度睡眠模块 — EXTI 唤醒 + 时钟恢复

#include "LOWPOWER.h"

// 逐步降低 AHB 总线频率，避免时钟切换瞬态尖峰
#define RCU_MODIFY_4(__delay)   do{                                     \
                                    volatile uint32_t i, reg;           \
                                    if(0 != __delay){                   \
                                        for(i=0; i<__delay; i++){}       \
                                        reg = RCU_CFG0;                  \
                                        reg &= ~(RCU_CFG0_AHBPSC);       \
                                        reg |= RCU_AHB_CKSYS_DIV2;       \
                                        RCU_CFG0 = reg;                  \
                                        for(i=0; i<__delay; i++){}       \
                                        reg = RCU_CFG0;                  \
                                        reg &= ~(RCU_CFG0_AHBPSC);       \
                                        reg |= RCU_AHB_CKSYS_DIV4;       \
                                        RCU_CFG0 = reg;                  \
                                        for(i=0; i<__delay; i++){}       \
                                        reg = RCU_CFG0;                  \
                                        reg &= ~(RCU_CFG0_AHBPSC);       \
                                        reg |= RCU_AHB_CKSYS_DIV8;       \
                                        RCU_CFG0 = reg;                  \
                                        for(i=0; i<__delay; i++){}       \
                                        reg = RCU_CFG0;                  \
                                        reg &= ~(RCU_CFG0_AHBPSC);      \
                                        reg |= RCU_AHB_CKSYS_DIV16;      \
                                        RCU_CFG0 = reg;                  \
                                    }                                    \
                                }while(0)

/* 软件延时（约20个指令周期） */
#define _soft_delay_(__delay)   do{                                     \
                                    volatile uint32_t delay;            \
                                    for(delay=0; delay<__delay; delay++){} \
                                }while(0)

// EXTI3 中断服务（默认 PE3 唤醒源）
void EXTI3_IRQHandler(void)
{
    if (RESET != exti_interrupt_flag_get(EXTI_3)) {
        exti_interrupt_flag_clear(EXTI_3);
    }
}

// EXTI0~4 各线中断服务
void EXTI0_IRQHandler(void)
{
    if (RESET != exti_interrupt_flag_get(EXTI_0)) {
        exti_interrupt_flag_clear(EXTI_0);
    }
}

void EXTI1_IRQHandler(void)
{
    if (RESET != exti_interrupt_flag_get(EXTI_1)) {
        exti_interrupt_flag_clear(EXTI_1);
    }
}

void EXTI2_IRQHandler(void)
{
    if (RESET != exti_interrupt_flag_get(EXTI_2)) {
        exti_interrupt_flag_clear(EXTI_2);
    }
}

void EXTI4_IRQHandler(void)
{
    if (RESET != exti_interrupt_flag_get(EXTI_4)) {
        exti_interrupt_flag_clear(EXTI_4);
    }
}

// EXTI5~9 共享中断服务
void EXTI5_9_IRQHandler(void)
{
    uint8_t line;
    for (line = 5; line <= 9; line++) {
        if (RESET != exti_interrupt_flag_get((exti_line_enum)line)) {
            exti_interrupt_flag_clear((exti_line_enum)line);
        }
    }
}

// EXTI10~15 共享中断服务
void EXTI10_15_IRQHandler(void)
{
    uint8_t line;
    for (line = 10; line <= 15; line++) {
        if (RESET != exti_interrupt_flag_get((exti_line_enum)line)) {
            exti_interrupt_flag_clear((exti_line_enum)line);
        }
    }
}

static void LOWPOWER_ClockRestore(void);

// 回调函数（weak，用户可重定义）

__weak void LOWPOWER_PreSleep_Callback(void)
{
    /* 用户可重定义：进入低功耗前的准备工作（如关闭外设、保存状态） */
}

__weak void LOWPOWER_PostWakeup_Callback(void)
{
    // 唤醒后恢复时钟，重新配置 Systick
    systick_config();
    printf("====system out LOWPOWER ====\n");
}

// 根据 EXTI 线号使能 NVIC 中断

static void LOWPOWER_EXTI_NVIC_Enable(uint8_t exti_line, uint8_t prio, uint8_t subprio)
{
    switch (exti_line) {
        case 0:  nvic_irq_enable(EXTI0_IRQn, prio, subprio);     break;
        case 1:  nvic_irq_enable(EXTI1_IRQn, prio, subprio);     break;
        case 2:  nvic_irq_enable(EXTI2_IRQn, prio, subprio);     break;
        case 3:  nvic_irq_enable(EXTI3_IRQn, prio, subprio);     break;
        case 4:  nvic_irq_enable(EXTI4_IRQn, prio, subprio);     break;
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:  nvic_irq_enable(EXTI5_9_IRQn, prio, subprio);   break;
        case 10:
        case 11:
        case 12:
        case 13:
        case 14:
        case 15: nvic_irq_enable(EXTI10_15_IRQn, prio, subprio); break;
        default: break;
    }
}

// 进入深度睡眠（LDO 低功耗 + 低驱动 + WFI），唤醒后自动恢复 240MHz
void LOWPOWER_EnterDeepSleep(void)
{
    /* 进入前回调 */
    LOWPOWER_PreSleep_Callback();

    /* 使能 PMU 时钟 */
    rcu_periph_clock_enable(RCU_PMU);

    /* 进入深度睡眠：LDO低功耗 + 低驱动模式 + WFI指令 */
    pmu_to_deepsleepmode(PMU_LDO_LOWPOWER, PMU_LOWDRIVER_ENABLE, WFI_CMD);

    /* ---- 唤醒后执行 ---- */

    /* 恢复系统时钟（IRC16M → HXTAL → PLL 240MHz） */
    LOWPOWER_ClockRestore();

    /* 唤醒后回调 */
    LOWPOWER_PostWakeup_Callback();
}

// 进入普通睡眠（CPU 停止，外设继续运行），任意中断可唤醒
void LOWPOWER_EnterSleep(void)
{
    LOWPOWER_PreSleep_Callback();

    rcu_periph_clock_enable(RCU_PMU);
    pmu_to_sleepmode(WFI_CMD);

    /* 普通睡眠唤醒后无需恢复时钟 */
    LOWPOWER_PostWakeup_Callback();
}

// 通用 EXTI 唤醒源初始化
void LOWPOWER_EXTIWakeup_Init(uint32_t gpio_periph, uint32_t pin,
                               uint8_t exti_line, uint32_t trigger,
                               uint8_t irq_priority)
{
    /* 使能 SYSCFG 和对应 GPIO 时钟 */
    rcu_periph_clock_enable(RCU_SYSCFG);
    rcu_periph_clock_enable(RCU_GPIOA); /* V2.0板子 PA0 唤醒，使能 GPIOA 时钟 */

    /* 配置 GPIO 为输入模式 */
    gpio_mode_set(gpio_periph, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, pin);

    /* 使能 EXTI 中断 */
    LOWPOWER_EXTI_NVIC_Enable(exti_line, irq_priority, 0U);

    /* 连接 GPIO 到 EXTI 线（根据端口和引脚自动映射） */
    switch (gpio_periph) {
        case GPIOA: syscfg_exti_line_config(EXTI_SOURCE_GPIOA, pin); break;
        case GPIOB: syscfg_exti_line_config(EXTI_SOURCE_GPIOB, pin); break;
        case GPIOC: syscfg_exti_line_config(EXTI_SOURCE_GPIOC, pin); break;
        case GPIOD: syscfg_exti_line_config(EXTI_SOURCE_GPIOD, pin); break;
        case GPIOE: syscfg_exti_line_config(EXTI_SOURCE_GPIOE, pin); break;
        case GPIOF: syscfg_exti_line_config(EXTI_SOURCE_GPIOF, pin); break;
        case GPIOG: syscfg_exti_line_config(EXTI_SOURCE_GPIOG, pin); break;
        default: break;
    }

    /* 配置 EXTI 中断 */
    exti_init((exti_line_enum)exti_line, EXTI_INTERRUPT, (exti_trig_type_enum)trigger);
    exti_interrupt_flag_clear((exti_line_enum)exti_line);
}

// 使用默认宏配置初始化 EXTI 唤醒源
void LOWPOWER_EXTIWakeup_DefaultInit(void)
{
    rcu_periph_clock_enable(RCU_SYSCFG);
    rcu_periph_clock_enable(RCU_GPIOA);

    gpio_mode_set(LOWPOWER_WAKEUP_GPIO, GPIO_MODE_INPUT,
                  GPIO_PUPD_PULLUP, LOWPOWER_WAKEUP_PIN);

    nvic_irq_enable(LOWPOWER_WAKEUP_IRQn,
                    LOWPOWER_WAKEUP_IRQ_PRIO,
                    LOWPOWER_WAKEUP_IRQ_SUBPRIO);

    syscfg_exti_line_config(EXTI_SOURCE_GPIOA, EXTI_SOURCE_PIN0);

    exti_init(LOWPOWER_WAKEUP_EXTI_LINE, EXTI_INTERRUPT, LOWPOWER_WAKEUP_EXTI_TRIG);
    exti_interrupt_flag_clear(LOWPOWER_WAKEUP_EXTI_LINE);
}

// 唤醒标志管理

FlagStatus LOWPOWER_WakeupFlag_Get(void)
{
    return pmu_flag_get(PMU_FLAG_WAKEUP);
}

void LOWPOWER_WakeupFlag_Clear(void)
{
    pmu_flag_clear(PMU_FLAG_WAKEUP);
}

// 深度睡眠唤醒后恢复系统时钟：IRC16M → HXTAL → PLL 240MHz
static void LOWPOWER_ClockRestore(void)
{
    uint32_t timeout = 0U;
    uint32_t stab_flag = 0U;

    /* 步骤1：逐步降频并切换到 HXTAL */
    RCU_MODIFY_4(0x50);
    rcu_system_clock_source_config(RCU_CKSYSSRC_HXTAL);
    _soft_delay_(200);
    rcu_deinit();

    /* 步骤2：使能 HXTAL 外部晶振 */
    RCU_CTL |= RCU_CTL_HXTALEN;

    /* 步骤3：等待 HXTAL 稳定 */
    do {
        timeout++;
        stab_flag = (RCU_CTL & RCU_CTL_HXTALSTB);
    } while ((0U == stab_flag) && (HXTAL_STARTUP_TIMEOUT != timeout));

    /* 步骤4：配置总线分频 */
    RCU_CFG0 |= RCU_AHB_CKSYS_DIV1;
    RCU_CFG0 |= RCU_APB2_CKAHB_DIV2;
    RCU_CFG0 |= RCU_APB1_CKAHB_DIV4;

    /* 步骤5：配置 PLL（HXTAL=8MHz, PSC=25, PLL_N=480, PLL_P=2） */
    RCU_PLL = (25U | (480U << 6U) | (((2U >> 1U) - 1U) << 16U) |
               (RCU_PLLSRC_HXTAL) | (10U << 24U));

    /* 步骤6：使能 PLL 并等待稳定 */
    RCU_CTL |= RCU_CTL_PLLEN;
    while (0U == (RCU_CTL & RCU_CTL_PLLSTB));

    /* 步骤7：使能高压驱动（GD32F470 240MHz 需要） */
    PMU_CTL |= PMU_CTL_HDEN;
    while (0U == (PMU_CS & PMU_CS_HDRF));

    PMU_CTL |= PMU_CTL_HDS;
    while (0U == (PMU_CS & PMU_CS_HDSRF));

    /* 步骤8：切换系统时钟到 PLL */
    RCU_CFG0 &= ~RCU_CFG0_SCS;
    RCU_CFG0 |= RCU_CKSYSSRC_PLLP;
    while (0U == (RCU_CFG0 & RCU_SCSS_PLLP));
}


