#include "HeaderFiles.h"

int main(void)
{
	System_Init();
	UsrFunction();
}

