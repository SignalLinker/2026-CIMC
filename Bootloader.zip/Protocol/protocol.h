// 串口二进制协议帧: 帧头 0xA5 + CRC16 校验

#ifndef __PROTOCOL_H
#define __PROTOCOL_H

#include "HeaderFiles.h"

// 宏定义

#define PROTOCOL_SOF         0xA5      /* 帧起始标识 */
#define PROTOCOL_ADDR_BROAD  0x00      /* 广播地址 */
#define PROTOCOL_ADDR_HOST   0x01      /* 上位机地址 */
#define PROTOCOL_ADDR_MCU    0x02      /* MCU 地址 */

/* 帧格式: SOF(1) + Addr(1) + Cmd(1) + Len(1) + Data(N) + CRC16(2) */
#define PROTOCOL_FRAME_MIN   6         /* 最小帧长（无数据） */
#define PROTOCOL_DATA_MAX    128       /* 最大数据长度 */

/* 命令码 */
#define PROTOCOL_CMD_TEST       0x00  /* 系统自检 */
#define PROTOCOL_CMD_START      0x01  /* 启动采样 */
#define PROTOCOL_CMD_STOP       0x02  /* 停止采样 */
#define PROTOCOL_CMD_RATIO_SET  0x03  /* 设置变比 */
#define PROTOCOL_CMD_LIMIT_SET  0x04  /* 设置阈值 */
#define PROTOCOL_CMD_CONFIG_SAVE 0x05 /* 保存配置 */
#define PROTOCOL_CMD_CONFIG_READ 0x06 /* 读取配置 */
#define PROTOCOL_CMD_RTC_SET    0x07  /* 设置时间 */
#define PROTOCOL_CMD_RTC_GET    0x08  /* 获取时间 */
#define PROTOCOL_CMD_DAC_SET    0x09  /* 设置DAC */
#define PROTOCOL_CMD_SAMPLE_DATA 0x0A /* 采样数据上报 */
#define PROTOCOL_CMD_HIDE       0x0B  /* 进入加密模式 */
#define PROTOCOL_CMD_UNHIDE     0x0C  /* 退出加密模式 */
#define PROTOCOL_CMD_DAC_FOLLOW  0x0D  /* DAC联动开关 */
#define PROTOCOL_CMD_CONF        0x0E  /* 一键输出配置 */
#define PROTOCOL_CMD_ACK        0x7F  /* 应答 */

// 类型定义

/* 解析后的帧结构 */
#pragma pack(1)
typedef struct {
    uint8_t  sof;        /* 帧头 0xA5 */
    uint8_t  addr;       /* 地址 */
    uint8_t  cmd;        /* 命令 */
    uint8_t  len;        /* 数据长度 */
    uint8_t  data[PROTOCOL_DATA_MAX]; /* 数据 */
    uint16_t crc;        /* CRC16（帧尾） */
} protocol_frame_t;
#pragma pack()

// 函数声明

/* CRC16 计算（Modbus 多项式 0x8005） */
uint16_t crc16_calc(uint8_t *buf, uint16_t len);

/* 从原始缓冲区解析帧，返回 0=成功, 1=帧头无效, 2=CRC错误, 3=长度异常 */
uint8_t protocol_frame_parse(uint8_t *raw, uint16_t raw_len, protocol_frame_t *frame);

/* 打包帧到缓冲区，返回帧总长度 */
uint16_t protocol_frame_pack(uint8_t *buf, uint8_t addr, uint8_t cmd,
                             uint8_t *data, uint8_t len);

/* 发送应答帧 */
void protocol_send_ack(uint8_t cmd, uint8_t *data, uint8_t len);

#endif

