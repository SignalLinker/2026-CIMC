// APP 主程序入口

#include "HeaderFiles.h"
#include "handler.h"

int main(void)
{
    SCB->VTOR = 0x08011000;   /* APP 起始地址 */
    __enable_irq();            /* 解锁 Bootloader 跳转时设置的 PRIMASK */

    /* 诊断：LED1 快闪3次 = 固件已启动 */
    rcu_periph_clock_enable(RCU_GPIOE);
    gpio_mode_set(GPIOE, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_1);
    gpio_output_options_set(GPIOE, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_1);
    { volatile uint32_t _i; for (_i = 0; _i < 3; _i++) {
        gpio_bit_set(GPIOE, GPIO_PIN_1);   for (volatile uint32_t _d = 0; _d < 2000000; _d++) {}
        gpio_bit_reset(GPIOE, GPIO_PIN_1); for (volatile uint32_t _d = 0; _d < 2000000; _d++) {}
    }}

    System_Init();              /* 硬件初始化 */
    handler_system_init();      /* 协议参数加载 */

    UsrFunction();              /* 主循环 */

}

