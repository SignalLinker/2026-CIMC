// OLED驱动代码（SSD1306，IIC接口）
 
#include "stdlib.h"
#include "oled.h"
#include "oledfont.h"
#include "iic.h"


/* 
 * OLED的显存
 * 每个字节表示8个像素, 128,表示有128列, 4表示有32行, 高位表示高行数. 
 * 比如:g_oled_gram[0][0],包含了第一列,第1~8行的数据. g_oled_gram[0][0].0,即表示坐标(0,0)
 * 类似的: g_oled_gram[1][0].1,表示坐标(1,1), g_oled_gram[10][1].2,表示坐标(10,10), 
 * 
 * 存放格式如下(高位表示高行数).
 * [0]0 1 2 3 ... 127
 * [1]0 1 2 3 ... 127
 * [2]0 1 2 3 ... 127
 * [3]0 1 2 3 ... 127
 */
static uint8_t g_oled_gram[128][4];
 
// 把显存数据刷新到OLED屏幕
void oled_refresh_gram(void)
{
    uint8_t i, n;

    for (i = 0; i < 4; i++)
    {
        oled_wr_byte (0xb0 + i, OLED_CMD); /* 设置页地址（0~3） */
        oled_wr_byte (0x00, OLED_CMD);     /* 设置显示位置—列低地址 */
        oled_wr_byte (0x10, OLED_CMD);     /* 设置显示位置—列高地址 */
 
        iic_start();
			  iic_send_byte(0X78);//oled地址
			  iic_wait_ack();
			  iic_send_byte(0x40);
				iic_wait_ack();
       
			  for (n = 0; n < 128; n++)
			  {         	
						iic_send_byte(g_oled_gram[n][i]);	
						iic_wait_ack();
			  }
			  iic_stop();
    }
}
  
// 清除OLED指定行
void oled_clear_line(uint8_t line) {
    uint8_t y_start = line * 8;
    for (int y = y_start; y < y_start + 8; y++) {
        for (int x = 0; x < 128; x++) {
            g_oled_gram[x][y] = 0x00;
        }
    }
}

// 向OLED写一个字节，cmd=0为命令，cmd=1为数据
static void oled_wr_byte(uint8_t data, uint8_t cmd)
{
	    iic_start();             /* 产生起始信号 */
	    iic_send_byte(0X78);     /* 发送从机地址 */
	    iic_wait_ack();          /* 每次发送完一个字节,都要等待ACK时钟脉冲 */
  
	    if(cmd == OLED_CMD)
      {
          iic_send_byte(0x00); /* 发送写入命令时的控制字节 */
      }
			else
      {
          iic_send_byte(0x40); /* 发送写入数据时的控制字节 */
      }
      
			iic_wait_ack();          /* 每次发送完一个字节,都要等待ACK时钟脉冲 */
			iic_send_byte(data);	   /* 发送数据字节 */
			iic_wait_ack();          /* 等待ACK时钟脉冲 */
			iic_stop();              /* 产生停止信号 */
}
 
// 开启OLED显示
void oled_display_on(void)
{
    oled_wr_byte(0X8D, OLED_CMD);   /* SET DCDC命令 */
    oled_wr_byte(0X14, OLED_CMD);   /* DCDC ON */
    oled_wr_byte(0XAF, OLED_CMD);   /* DISPLAY ON */
}
 
// 关闭OLED显示
void oled_display_off(void)
{
    oled_wr_byte(0X8D, OLED_CMD);   /* SET DCDC命令 */
    oled_wr_byte(0X10, OLED_CMD);   /* DCDC OFF */
    oled_wr_byte(0XAE, OLED_CMD);   /* DISPLAY OFF */
}
 
// 清屏
void oled_clear(void)
{
    uint8_t i, n;

    for (i = 0; i < 4; i++)
    {
        for (n = 0; n < 128; n++)
        {
            g_oled_gram[n][i] = 0X00;
        }
    }

    oled_refresh_gram();    /* 更新显示 */
}

// 画点，dot=1填充，dot=0清空
void oled_draw_point(uint8_t x, uint8_t y, uint8_t dot)
{
    uint8_t pos, bx, temp = 0;

    if (x > 127 || y > 31)
    {
        return;                     /* 超出范围了. */
    }

    pos = y / 8;                    /* 计算GRAM里面的y坐标所在的字节, 每个字节可以存储8个行坐标 */

    bx = y % 8;                     /* 取余数,方便计算y在对应字节里面的位置,及行(y)位置 */
    temp = 1 << bx;                 /* 高位表示高行号, 得到y对应的bit位置,将该bit先置1 */

    if (dot)                        /* 画实心点 */
    {
        g_oled_gram[x][pos] |= temp;
    }
    else                            /* 画空点,即不显示 */
    {
        g_oled_gram[x][pos] &= ~temp;
    }
}

// 区域填充，需要x1<=x2且y1<=y2
void oled_fill(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t dot)
{
    uint8_t x, y;

    for (x = x1; x <= x2; x++)
    {
        for (y = y1; y <= y2; y++)
        {
            oled_draw_point(x, y, dot);
        }
    }

    oled_refresh_gram();    /* 更新显示 */
}

// 在指定位置显示一个字符，size可选12/16/24
void oled_show_char(uint8_t x, uint8_t y, uint8_t chr, uint8_t size, uint8_t mode)
{
    uint8_t temp, t, t1;
    uint8_t y0 = y;
    uint8_t *pfont = 0;
    uint8_t csize = (size / 8 + ((size % 8) ? 1 : 0)) * (size / 2); /* 得到字体一个字符对应点阵集所占的字节数 */
    chr = chr - ' ';                                                /* 得到偏移后的值,因为字库是从空格开始存储的,第一个字符是空格 */

    if (y + size > 32)    return;                                   /* 高度限制 */
	
    if (size == 12)                                                 /* 调用1206字体 */
    {
        pfont = (uint8_t *)oled_asc2_1206[chr];        
    }
    else if (size == 16)                                            /* 调用1608字体 */ 
    {
        pfont = (uint8_t *)oled_asc2_1608[chr];
    }
    else if (size == 24)                                            /* 调用2412字体 */
    { 
        pfont = (uint8_t *)oled_asc2_2412[chr];
    }
	
    else                                                            /* 没有的字库 */
    {
        return;   
    }
    
    for (t = 0; t < csize; t++)
    { 
        temp = pfont[t];
      
        for (t1 = 0; t1 < 8; t1++)
        {
            if (temp & 0x80)
            {
                oled_draw_point(x, y, mode);
            }
            else
            {
                oled_draw_point(x, y, !mode);
            }

            temp <<= 1;
            y++;

            if ((y - y0) == size)
            {
                y = y0;
                x++;
                break;
            }
        }
    }
}

// 8x8字体字符显示
static void oled_show_char_8x8(uint8_t x, uint8_t y, uint8_t chr)
{
    uint8_t i, b;
    uint8_t offset = chr - ' ';  // 字符偏移（假设字库从空格开始）
    const uint8_t* font = oled_asc2_8x8[offset];  // 使用8x8字体字库

    for (i = 0; i < 8; i++)  // 8行
    {
        uint8_t line = font[i];  // 获取当前行点阵数据
        for (b = 0; b < 8; b++)  // 8列
        {
            if (line & (1 << (7 - b)))  // 从左到右绘制像素（高位在前）
            {
                oled_draw_point(x + b, y + i, 1);
            }
        }
    }
}

// m的n次方
static uint32_t oled_pow(uint8_t m, uint8_t n)
{
    uint32_t result = 1;

    while (n--)
    {
        result *= m;
    }

    return result;
}

// 显示len位数字
void oled_show_num(uint8_t x, uint8_t y, uint32_t num, uint8_t len, uint8_t size)
{
    uint8_t t, temp;
    uint8_t enshow = 0;

    for (t = 0; t < len; t++)                                           /* 按总显示位数循环 */
    {
        temp = (num / oled_pow(10, len - t - 1)) % 10;                  /* 获取对应位的数字 */

        if (enshow == 0 && t < (len - 1))                               /* 没有使能显示,且还有位要显示 */
        {
            if (temp == 0)
            {
                oled_show_char(x + (size / 2) * t, y, ' ', size, 1);    /* 显示空格,站位 */
                continue;                                               /* 继续下个一位 */
            }
            else
            {
                enshow = 1;                                             /* 使能显示 */
            }
        }

        oled_show_char(x + (size / 2) * t, y, temp + '0', size, 1);     /* 显示字符 */
    }
} 

// 显示字符串，支持8/12/16/24字体
void oled_show_string(uint8_t x, uint8_t y, const char *p, uint8_t size)
{
    while ((*p <= '~') && (*p >= ' '))      /* 过滤非法字符 */
    {
        // 宽度越界处理（根据字体宽度调整）
        if (size == 8) 
        {
            if (x > (128 - 8))  // 8x8字体宽度为8像素
            {
                x = 0;
                y += 8;         // 8x8字体高度为8像素
            }
        }
        else 
        {
            if (x > (128 - (size / 2)))  // 其他字体沿用原逻辑
            {
                x = 0;
                y += size;
            }
        }

        // 高度越界处理（限制在0~31行，共32行）
        if (y + (size == 8 ? 8 : size) > 32)
        {
            y = x = 0;
            oled_clear();
        }

        // 显示单个字符
        if (size == 8) 
        {
            oled_show_char_8x8(x, y, *p);  // 使用8x8字体显示函数
        }
        else 
        {
            oled_show_char(x, y, *p, size, 1);  // 原字体逻辑
        }

        // 移动到下一个字符位置
        x += (size == 8) ? 8 : (size / 2);  // 8x8字体宽度8，其他字体宽度为size/2
        p++;
    }
}

 

void oled_draw_line(uint8_t x1_orig, uint8_t y1_orig, uint8_t x2_orig, uint8_t y2_orig)
{
    int x1 = x1_orig, y1 = y1_orig;
    int x2 = x2_orig, y2 = y2_orig;
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int sx = (x1 < x2) ? 1 : -1;
    int sy = (y1 < y2) ? 1 : -1;
    int err = dx - dy;

    while (1)
    {
        if (x1 >= 0 && x1 < 128 && y1 >= 0 && y1 < 32)
        {
            oled_draw_point(x1, y1, 1);
        }

        if (x1 == x2 && y1 == y2) break;

        int e2 = 2 * err;
        if (e2 > -dy)
        {
            err -= dy;
            x1 += sx;
        }
        if (e2 < dx)
        {
            err += dx;
            y1 += sy;
        }
    }

    oled_refresh_gram();
}

// 中点画圆算法绘制圆
void oled_draw_circle(uint8_t cx, uint8_t cy, uint8_t r)
{
    int8_t x = 0, y = r;
    int16_t d = 1 - r;  // 决策参数初始值

    // 绘制圆心（可选）
    oled_draw_point(cx, cy, 1);

    // 主循环：计算1/8圆弧的点
    while (x <= y)
    {
        // 利用8对称性绘制8个对称点
        oled_draw_point(cx + x, cy + y, 1);  // 右上
        oled_draw_point(cx + y, cy + x, 1);  // 右下
        oled_draw_point(cx + y, cy - x, 1);  // 右下偏左
        oled_draw_point(cx + x, cy - y, 1);  // 左上偏下
        oled_draw_point(cx - x, cy - y, 1);  // 左上
        oled_draw_point(cx - y, cy - x, 1);  // 左上偏右
        oled_draw_point(cx - y, cy + x, 1);  // 左下偏右
        oled_draw_point(cx - x, cy + y, 1);  // 左下

        // 更新决策参数
        if (d < 0)
        {
            d += 2 * x + 3;  // 向x方向步进
        }
        else
        {
            d += 2 * (x - y) + 5;  // 向x+1, y-1方向步进
            y--;
        }
        x++;
    }

    // 更新显存显示
    oled_refresh_gram();
}

/*
		// 绘制圆心在(63, 16)，半径10的圆（屏幕中心）
        oled_draw_circle(63, 16, 10);
        
        // 绘制圆心在(30, 8)，半径5的小圆
        oled_draw_circle(30, 8, 5);
*/

// 显示24x24汉字
void OLED_Show_Font(uint16_t x,uint16_t y,uint8_t fnum)
{
	if (y + 24 > 32)   return;  /* 限制汉字显示在屏幕范围内 */
        
	uint8_t temp,t,t1;
	uint16_t y0=y;
	uint8_t *dzk;   
	uint8_t csize=72;					/* 一个24*24的汉字72字节 */
	
	dzk=(uint8_t*)OLED_HZK_XMZB[fnum];	/* 得到汉字编号对应的点阵库 */
	
	for(t=0;t<csize;t++)
	{   												   
		temp=dzk[t];				/* 得到点阵数据 */                          
		for(t1=0;t1<8;t1++)
		{
			if(temp&0x80)oled_draw_point(x,y,1);
			else oled_draw_point(x,y,0); 
			temp<<=1;
			y++;
			if((y-y0)==24)
			{
				y=y0;
				x++;
				break;
			}
		}  	 
	}  
}


// 显示16x16汉字
void OLED_Show_Font_Test(uint16_t x,uint16_t y,uint8_t fnum1)
{
	if (y + 16 > 32)   return;  /* 限制汉字显示在屏幕范围内 */
        
	uint8_t temp,t,t1;
	uint16_t y0=y;
	uint8_t *dzk;   
	uint8_t csize=32;					/* 一个16*16的汉字32字节 */
	
	dzk=(uint8_t*)OLED_HZK[fnum1];	/* 得到汉字编号对应的点阵库 */
	
	for(t=0;t<csize;t++)
	{   												   
		temp=dzk[t];				/* 得到点阵数据 */                          
		for(t1=0;t1<8;t1++)
		{
			if(temp&0x80)oled_draw_point(x,y,1);
			else oled_draw_point(x,y,0); 
			temp<<=1;
			y++;
			if((y-y0)==16)
			{
				y=y0;
				x++;
				break;
			}
		}  	 
	}  
}

// 初始化OLED（SSD1306）
void oled_init(void)
{ 
		iic_init();     /* IIC接口初始化 */

    oled_wr_byte(0xAE, OLED_CMD);   /* 关闭显示 */
    oled_wr_byte(0xD5, OLED_CMD);   /* 设置时钟分频因子,震荡频率 */
    oled_wr_byte(80, OLED_CMD);     /* [3:0],分频因子;[7:4],震荡频率 */
    oled_wr_byte(0xA8, OLED_CMD);   /* 设置驱动路数 */
    oled_wr_byte(0X1F, OLED_CMD);   /* 默认0X1F(1/32) */
    oled_wr_byte(0xD3, OLED_CMD);   /* 设置显示偏移 */
    oled_wr_byte(0X00, OLED_CMD);   /* 默认为0 */

    oled_wr_byte(0x40, OLED_CMD);   /* 设置显示开始行 [5:0],行数. */

    oled_wr_byte(0x8D, OLED_CMD);   /* 电荷泵设置 */
    oled_wr_byte(0x14, OLED_CMD);   /* bit2，开启/关闭 */
    oled_wr_byte(0x20, OLED_CMD);   /* 设置内存地址模式 */
    oled_wr_byte(0x02, OLED_CMD);   /* [1:0],00，列地址模式;01，行地址模式;10,页地址模式;默认10; */
    oled_wr_byte(0xA1, OLED_CMD);   /* 段重定义设置,bit0:0,0->0;1,0->127; */
    oled_wr_byte(0xC8, OLED_CMD);   /* 设置COM扫描方向;bit3:0,普通模式;1,重定义模式 COM[N-1]->COM0;N:驱动路数 */
    oled_wr_byte(0xDA, OLED_CMD);   /* 设置COM硬件引脚配置 */
    oled_wr_byte(0x02, OLED_CMD);   /* 32行配置 */

    oled_wr_byte(0x81, OLED_CMD);   /* 对比度设置 */
    oled_wr_byte(0xEF, OLED_CMD);   /* 1~255;默认0X7F (亮度设置,越大越亮) */
    oled_wr_byte(0xD9, OLED_CMD);   /* 设置预充电周期 */
    oled_wr_byte(0xf1, OLED_CMD);   /* [3:0],PHASE 1;[7:4],PHASE 2; */
    oled_wr_byte(0xDB, OLED_CMD);   /* 设置VCOMH 电压倍率 */
    oled_wr_byte(0x30, OLED_CMD);   /* [6:4] 000,0.65*vcc;001,0.77*vcc;011,0.83*vcc; */

    oled_wr_byte(0xA4, OLED_CMD);   /* 全局显示开启;bit0:1,开启;0,关闭;(白屏/黑屏) */
    oled_wr_byte(0xA6, OLED_CMD);   /* 设置显示方式;bit0:1,反相显示;0,正常显示 */
    oled_wr_byte(0xAF, OLED_CMD);   /* 开启显示 */
    oled_clear();
}
