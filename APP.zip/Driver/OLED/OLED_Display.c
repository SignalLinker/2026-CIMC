#include "OLED_Display.h"

void OLED_Display_Init(void)
{
    oled_init();
    oled_display_on();
    oled_clear();
    oled_show_string(0, 0, "2026296117", FONT_16X8);
    oled_show_string(0, 16, "IDLE", FONT_16X8);
    oled_refresh_gram();
}

void OLED_Display_Init_Page(void)
{
    oled_clear();
    oled_show_string(0, 0, "2026296117", FONT_16X8);
    oled_show_string(0, 16, "IDLE", FONT_16X8);
    oled_refresh_gram();
}

void OLED_Display_Clear(void)
{
    oled_clear();
}

void OLED_Display_Update(void)
{
    oled_refresh_gram();
}
