// OLED IIC模式驱动代码
 
#include "iic.h"


//static uint32_t g_fac_us = 0;      /* us延时倍乘数 */

// 初始化IIC的GPIO引脚
void iic_init(void)
{
    rcu_periph_clock_enable(OLED_IIC_SCL_GPIO_CLK);  /* SCL引脚时钟使能 */
    rcu_periph_clock_enable(OLED_IIC_SDA_GPIO_CLK);  /* SDA引脚时钟使能 */

    /* SCL引脚模式设置,推挽输出,上拉 */
    gpio_mode_set(OLED_IIC_SCL_GPIO_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, OLED_IIC_SCL_GPIO_PIN);
    gpio_output_options_set(OLED_IIC_SCL_GPIO_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, OLED_IIC_SCL_GPIO_PIN);

    /* SDA引脚模式设置,开漏输出,上拉, 这样就不用再设置IO方向了, 开漏输出的时候(=1), 也可以读取外部信号的高低电平 */
    gpio_mode_set(OLED_IIC_SDA_GPIO_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, OLED_IIC_SDA_GPIO_PIN);
    gpio_output_options_set(OLED_IIC_SDA_GPIO_PORT, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, OLED_IIC_SDA_GPIO_PIN);

    iic_stop();     /* 停止总线上所有设备 */
}

//void delay_us(uint32_t nus)
//{
//    uint32_t ticks;
//    uint32_t told, tnow, tcnt = 0;
//    uint32_t reload;
//    reload = SysTick->LOAD;             /* LOAD的值 */
//    ticks = nus * g_fac_us;             /* 需要的节拍数 */
//  
//#if SYS_SUPPORT_OS                      /* 如果需要支持OS */
//    delay_osschedlock();                /* 锁定 OS 的任务调度器，防止打断us延时 */
//#endif
//  
//    told = SysTick->VAL;                /* 刚进入时的计数器值 */
//  
//    while (1)
//    {
//        tnow = SysTick->VAL;

//        if (tnow != told)
//        {
//            if (tnow < told)
//            {
//                tcnt += told - tnow;    /* 这里注意一下SYSTICK是一个递减的计数器就可以了. */
//            }
//            else
//            {
//                tcnt += reload - tnow + told;
//            }
//            
//            told = tnow;
//            
//            if (tcnt >= ticks) 
//            {
//                break;                  /* 时间超过/等于要延迟的时间,则退出. */
//            }
//        }
//    }
//}

// IIC延时，控制读写速度在250KHz以内
static void iic_delay(void)
{
    volatile uint32_t i;
    for (i = 0; i < 80; i++) {
        __NOP();
    }
}

// 产生IIC起始信号
void iic_start(void)
{
    IIC_SDA(1);
    IIC_SCL(1);
    iic_delay();
    IIC_SDA(0);     /* START信号: 当SCL为高时, SDA从高变成低, 表示起始信号 */
    iic_delay();
    IIC_SCL(0);     /* 钳住I2C总线，准备发送或接收数据 */
    iic_delay();
}

// 产生IIC停止信号
void iic_stop(void)
{
    IIC_SDA(0);     /* STOP信号: 当SCL为高时, SDA从低变成高, 表示停止信号 */
    iic_delay();
    IIC_SCL(1);
    iic_delay();
    IIC_SDA(1);     /* 发送I2C总线结束信号 */
    iic_delay();
}

// 等待应答，返回0成功，返回1失败
uint8_t iic_wait_ack(void)
{
//    uint8_t waittime = 0;
    uint8_t rack = 0;

    IIC_SDA(1);     /* 主机释放SDA线(此时外部器件可以拉低SDA线) */
    iic_delay();
    IIC_SCL(1);     /* SCL=1, 此时从机可以返回ACK */
    iic_delay();

      /* 不接收应答信号，注释这段代码 */
//    while (IIC_READ_SDA)    /* 等待应答 */
//    {
//        waittime++;

//        if (waittime > 250) /* 没有收到应答信号 */
//        {
//            iic_stop();     
//            rack = 1;
//            break;     
//        }
//    }

    IIC_SCL(0);     /* SCL=0, 结束ACK检查 */
    iic_delay();
    return rack;
}

// 发送ACK应答
void iic_ack(void)
{
    IIC_SDA(0);     /* SCL 0 -> 1  时 SDA = 0,表示应答 */
    iic_delay();
    IIC_SCL(1);     /* 产生一个时钟 */
    iic_delay();
    IIC_SCL(0);
    iic_delay();
    IIC_SDA(1);     /* 主机释放SDA线 */
    iic_delay();
}

// 发送NACK（不应答）
void iic_nack(void)
{
    IIC_SDA(1);     /* SCL 0 -> 1  时 SDA = 1,表示不应答 */
    iic_delay();
    IIC_SCL(1);     /* 产生一个时钟 */
    iic_delay();
    IIC_SCL(0);
    iic_delay();
}

// IIC发送一个字节
void iic_send_byte(uint8_t data)
{
    uint8_t t;
    
    for (t = 0; t < 8; t++)
    {
        IIC_SDA((data & 0x80) >> 7);    /* 高位先发送 */
        iic_delay();
        IIC_SCL(1);
        iic_delay();
        IIC_SCL(0);
        data <<= 1;     /* 左移1位，用于下一次发送 */
    }
    
    IIC_SDA(1);         /* 发送完成，主机释放SDA线 */
}

// IIC读一个字节，ack=1回ACK，ack=0回NACK
uint8_t iic_read_byte(uint8_t ack)
{
    uint8_t i, receive = 0;

    for (i = 0; i < 8; i++ )    /* 接收1个字节数据 */
    {
        receive <<= 1;          /* 高位先输出,所以先收到的数据位要左移 */
        IIC_SCL(1);
        iic_delay();

        if (IIC_READ_SDA)
        {
            receive++;
        }
        
        IIC_SCL(0);
        iic_delay();
    }

    if (!ack)
    {
        iic_nack();             /* 发送nACK */
    }
    else
    {
        iic_ack();              /* 发送ACK */
    }

    return receive;             /* 返回读到的数据 */
}



