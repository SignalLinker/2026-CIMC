// RTC实时时钟模块头文件

#ifndef __RTC_H
#define __RTC_H

#include "HeaderFiles.h"

// 函数声明

// RTC初始化
void RTC_Init(void);

// 通过串口交互设置RTC时间
void rtc_setup(void);

// 打印当前RTC时间
void rtc_show_time(void);

// 打印RTC闹钟时间
void rtc_show_alarm(void);

// 串口输入数值校验，返回BCD格式值，失败返回0xFF
uint8_t usart_input_threshold(uint32_t value);

// RTC时钟源选择和分频配置
void rtc_pre_config(void);

// 设置RTC时间（BCD格式），自动计算星期
uint8_t rtc_set_time(uint8_t yy, uint8_t mm, uint8_t dd,
                     uint8_t hh, uint8_t min, uint8_t ss);

// 设置RTC闹钟在seconds秒后触发
void RTC_SetAlarmRelative(uint32_t seconds);

#endif
