// RTC实时时钟模块，支持闹钟唤醒和时间配置

#include "RTC.h"

// 宏定义
#define RTC_CLOCK_SOURCE_LXTAL    /* 定义RTC时钟源为LXTAL（外部32.768KHz晶振） */
#define BKP_VALUE    0x32F0       /* 备份寄存器默认值，用于判断RTC是否已配置 */

// 变量定义
rtc_parameter_struct   rtc_initpara;      /* RTC初始化参数结构体 */
rtc_alarm_struct  rtc_alarm;              /* RTC闹钟结构体 */
__IO uint32_t prescaler_a = 0, prescaler_s = 0;  /* RTC异步和同步预分频器 */
uint32_t RTCSRC_FLAG = 0;                  /* RTC时钟源标志位 */

// RTC初始化
void RTC_Init(void)
{
//    printf("\n\r  ****************** RTC calendar demo ******************\n\r");

    /* 使能PMU时钟 */
    rcu_periph_clock_enable(RCU_PMU);
    /* 使能RTC寄存器访问 */
    pmu_backup_write_enable();

    /* RTC预配置 */
    rtc_pre_config();
    /* 获取RTC时钟源选择 */
    RTCSRC_FLAG = GET_BITS(RCU_BDCTL, 8, 9);

    /* 检查RTC是否已经配置过 */
    if((BKP_VALUE != RTC_BKP0) || (0x00 == RTCSRC_FLAG)){
        /* 首次上电：用默认时间初始化 RTC，避免阻塞 */
        rtc_initpara.factor_asyn = prescaler_a;
        rtc_initpara.factor_syn  = prescaler_s;
        rtc_initpara.year        = 0x26;                 /* 2026 */
        rtc_initpara.month       = 0x01;                 /* 1月 */
        rtc_initpara.date        = 0x01;                 /* 1日 */
        rtc_initpara.hour        = 0x00;
        rtc_initpara.minute      = 0x00;
        rtc_initpara.second      = 0x00;
        rtc_initpara.display_format = RTC_24HOUR;
        rtc_initpara.am_pm       = RTC_AM;
        rtc_init(&rtc_initpara);
        RTC_BKP0 = BKP_VALUE;
    }else{
        /* 检测复位源 */
        if (RESET != rcu_flag_get(RCU_FLAG_PORRST)){
//            printf("power on reset occurred....\n\r");
        }else if (RESET != rcu_flag_get(RCU_FLAG_EPRST)){
//            printf("external reset occurred....\n\r");
        }
//        printf("no need to configure RTC....\n\r");

        /* 显示当前时间 */
//        rtc_show_time();
    }

    /* 先清理可能残留的 RTC 闹钟，再使能中断（否则热复位后
       闹钟标志未清 → EXTI 使能后立即触发 → 无限 ISR 循环） */
    rtc_flag_clear(RTC_FLAG_ALRM0);
    rtc_alarm_disable(RTC_ALARM0);
    rtc_interrupt_disable(RTC_INT_ALARM0);

    /* 使能 RTC 闹钟 NVIC（深度睡眠唤醒必须） */
    nvic_irq_enable(RTC_Alarm_IRQn, 1, 0);

    /* 初始化 RTC 闹钟 EXTI 线 */
    exti_init(EXTI_17, EXTI_INTERRUPT, EXTI_TRIG_RISING);
    exti_interrupt_enable(EXTI_17);
    exti_interrupt_flag_clear(EXTI_17);

    /* 清除所有复位标志 */
    rcu_all_reset_flag_clear();
}

// RTC时钟源选择和分频配置
void rtc_pre_config(void)
{
    #if defined (RTC_CLOCK_SOURCE_IRC32K)
          /* 选择IRC32K作为RTC时钟源 */
          rcu_osci_on(RCU_IRC32K);
          rcu_osci_stab_wait(RCU_IRC32K);
          rcu_rtc_clock_config(RCU_RTCSRC_IRC32K);

          /* 配置RTC异步和同步预分频器 */
          prescaler_s = 0x13F;  /* 同步预分频：32768-1 */
          prescaler_a = 0x63;   /* 异步预分频：128-1 */
    #elif defined (RTC_CLOCK_SOURCE_LXTAL)
          /* 选择LXTAL（外部32.768KHz晶振）作为RTC时钟源 */
          rcu_osci_on(RCU_LXTAL);
          rcu_osci_stab_wait(RCU_LXTAL);
          rcu_rtc_clock_config(RCU_RTCSRC_LXTAL);

          /* 配置RTC异步和同步预分频器 */
          prescaler_s = 0xFF;   /* 同步预分频：256-1 */
          prescaler_a = 0x7F;   /* 异步预分频：128-1 */
    #else
    #error RTC clock source should be defined.
    #endif /* RTC_CLOCK_SOURCE_IRC32K */

    /* 使能RTC外设时钟 */
    rcu_periph_clock_enable(RCU_RTC);
    /* 等待RTC寄存器同步 */
    rtc_register_sync_wait();
}

// 通过串口交互设置RTC时间
void rtc_setup(void)
{
    /* 定义时间输入变量 */
    uint32_t tmp_year = 0xFF, tmp_month = 0xFF, tmp_day = 0xFF;
    uint32_t tmp_hh = 0xFF, tmp_mm = 0xFF, tmp_ss = 0xFF;

    /* 配置RTC初始化参数 */
    rtc_initpara.factor_asyn = prescaler_a;  /* 异步预分频 */
    rtc_initpara.factor_syn = prescaler_s;   /* 同步预分频 */
    rtc_initpara.year = 0x16;                 /* 默认年份：2016年 */
    rtc_initpara.day_of_week = RTC_SATURDAY;  /* 默认星期：星期六 */
    rtc_initpara.month = RTC_APR;              /* 默认月份：4月 */
    rtc_initpara.date = 0x30;                  /* 默认日期：30日 */
    rtc_initpara.display_format = RTC_24HOUR; /* 24小时制 */
    rtc_initpara.am_pm = RTC_AM;               /* 上午 */

    /* 通过串口输入当前时间 */
//    printf("=======Configure RTC Time========\n\r");
//    printf("  please set the last two digits of current year:\n\r");
    while(tmp_year == 0xFF) {
        /* 输入年份（后两位）*/
        tmp_year = usart_input_threshold(99);
        rtc_initpara.year = tmp_year;
    }
//    printf("  20%0.2x\n\r", tmp_year);

//    printf("  please input month:\n\r");
    while(tmp_month == 0xFF) {
        /* 输入月份 */
        tmp_month = usart_input_threshold(12);
        rtc_initpara.month = tmp_month;
    }
//    printf("  %0.2x\n\r", tmp_month);

//    printf("  please input day:\n\r");
    while(tmp_day == 0xFF) {
        /* 输入日期 */
        tmp_day = usart_input_threshold(31);
        rtc_initpara.date = tmp_day;
    }
//    printf("  %0.2x\n\r", tmp_day);

//    printf("  please input hour:\n\r");
    while (0xFF == tmp_hh){
        /* 输入小时 */
        tmp_hh = usart_input_threshold(23);
        rtc_initpara.hour = tmp_hh;
    }
//    printf("  %0.2x\n\r", tmp_hh);

//    printf("  please input minute:\n\r");
    while (0xFF == tmp_mm){
        /* 输入分钟 */
        tmp_mm = usart_input_threshold(59);
        rtc_initpara.minute = tmp_mm;
    }
//    printf("  %0.2x\n\r", tmp_mm);

//    printf("  please input second:\n\r");
    while (0xFF == tmp_ss){
        /* 输入秒 */
        tmp_ss = usart_input_threshold(59);
        rtc_initpara.second = tmp_ss;
    }
//    printf("  %0.2x\n\r", tmp_ss);

    /* 配置RTC当前时间 */
    if(ERROR == rtc_init(&rtc_initpara)){
//        printf("\n\r** RTC time configuration failed! **\n\r");
    }else{
//        printf("\n\r** RTC time configuration success! **\n\r");
        /* 显示配置后的时间 */
        rtc_show_time();
        /* 写入备份寄存器，标记RTC已配置 */
        RTC_BKP0 = BKP_VALUE;
    }
}

// Sakamoto算法计算星期（1=Mon ~ 7=Sun）
static uint8_t calc_weekday(uint16_t yy, uint8_t mm, uint8_t dd)
{
    /* Sakamoto's algorithm: 返回 GD32 RTC 星期格式 (1=Mon ~ 7=Sun) */
    static int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
    if (mm < 3) yy -= 1;
    uint8_t w = (yy + yy/4 - yy/100 + yy/400 + t[mm-1] + dd) % 7;
    return (w == 0) ? 7 : w;  /* 0=Sun → 7 */
}

uint8_t rtc_set_time(uint8_t yy, uint8_t mm, uint8_t dd,
                     uint8_t hh, uint8_t min, uint8_t ss)
{
    rtc_initpara.factor_asyn = prescaler_a;
    rtc_initpara.factor_syn  = prescaler_s;
    rtc_initpara.year        = yy;
    rtc_initpara.month       = mm;
    rtc_initpara.date        = dd;
    rtc_initpara.hour        = hh;
    rtc_initpara.minute      = min;
    rtc_initpara.second      = ss;
    rtc_initpara.display_format = RTC_24HOUR;
    rtc_initpara.am_pm       = RTC_AM;

    /* 通过传入的年月日自动计算星期 */
    uint16_t full_year = 2000 + (((yy >> 4) * 10) + (yy & 0x0F));
    uint8_t  dec_mm    = ((mm >> 4) * 10) + (mm & 0x0F);
    uint8_t  dec_dd    = ((dd >> 4) * 10) + (dd & 0x0F);
    rtc_initpara.day_of_week = calc_weekday(full_year, dec_mm, dec_dd);

    if (ERROR == rtc_init(&rtc_initpara)) {
        return 1;
    }
    RTC_BKP0 = BKP_VALUE;
    return 0;
}

// 打印当前RTC时间
void rtc_show_time(void)
{
    /* 获取当前RTC时间 */
    rtc_current_time_get(&rtc_initpara);

    /* 打印当前时间 */
    printf("\r\nCurrent time: 20%0.2x-%0.2x-%0.2x", \
           rtc_initpara.year, rtc_initpara.month, rtc_initpara.date);

    printf(" : %0.2x:%0.2x:%0.2x \r\n", \
           rtc_initpara.hour, rtc_initpara.minute, rtc_initpara.second);
}

// 打印RTC闹钟时间
void rtc_show_alarm(void)
{
    /* 获取RTC闹钟时间 */
    rtc_alarm_get(RTC_ALARM0, &rtc_alarm);
    /* 打印闹钟时间 */
    printf("The alarm: %0.2x:%0.2x:%0.2x \n\r", rtc_alarm.alarm_hour, rtc_alarm.alarm_minute,\
           rtc_alarm.alarm_second);
}

// 串口输入数值校验，返回BCD格式值，失败返回0xFF
uint8_t usart_input_threshold(uint32_t value)
{
    uint32_t index = 0;
    uint32_t tmp[2] = {0, 0};

    /* 读取两个字符（十位和个位）*/
    while (index < 2){
        /* 等待串口接收数据 */
        while (RESET == usart_flag_get(USART0, USART_FLAG_RBNE));
        /* 接收字符 */
        tmp[index++] = usart_data_receive(USART0);
        /* 检查是否为有效数字（0-9）*/
        if ((tmp[index - 1] < 0x30) || (tmp[index - 1] > 0x39)){
            printf("\n\r please input a valid number between 0 and 9 \n\r");
            index--;
        }
    }

    /* 将两个字符转换为数值 */
    index = (tmp[1] - 0x30) + ((tmp[0] - 0x30) * 10);
    /* 检查是否超过上限 */
    if (index > value){
        printf("\n\r please input a valid number between 0 and %d \n\r", value);
        return 0xFF;
    }

    /* 转换为BCD格式并返回 */
    index = (tmp[1] - 0x30) + ((tmp[0] - 0x30) <<4);
    return index;
}

// 设置RTC闹钟在seconds秒后触发

#define BCD2DEC(v) ((((v) >> 4) * 10) + ((v) & 0x0F))
#define DEC2BCD_RTC(v) ((((v) / 10) << 4) | ((v) % 10))

void RTC_SetAlarmRelative(uint32_t seconds)
{
    rtc_parameter_struct rtc_time;
    rtc_alarm_struct alarm_cfg;
    uint8_t sec, min, hour;

    /* 读取当前时间（BCD格式） */
    rtc_current_time_get(&rtc_time);

    /* BCD → 十进制计算 */
    sec  = BCD2DEC(rtc_time.second);
    min  = BCD2DEC(rtc_time.minute);
    hour = BCD2DEC(rtc_time.hour);

    /* 加上相对秒数 */
    sec += (uint8_t)(seconds % 60);
    if (sec >= 60) { sec -= 60; min++; }
    min += (uint8_t)((seconds / 60) % 60);
    if (min >= 60) { min -= 60; hour++; }
    hour += (uint8_t)(seconds / 3600);
    if (hour >= 24) { hour -= 24; }

    /* 十进制 → BCD 写入闹钟结构体 */
    alarm_cfg.alarm_day    = 0x01;                      /* 日期占位（被 MASK 忽略） */
    alarm_cfg.alarm_hour   = DEC2BCD_RTC(hour);
    alarm_cfg.alarm_minute = DEC2BCD_RTC(min);
    alarm_cfg.alarm_second = DEC2BCD_RTC(sec);
    alarm_cfg.alarm_mask   = RTC_ALARM_DATE_MASK;       /* 仅比较时分秒 */
    alarm_cfg.weekday_or_date = RTC_ALARM_DATE_SELECTED;
    alarm_cfg.am_pm = RTC_AM;

    /* 硬件要求：写 RTC_ALRMxTD 前必须先停用闹钟，等待 ALRM0WF=1 */
    rtc_alarm_disable(RTC_ALARM0);
    rtc_flag_clear(RTC_FLAG_ALRM0);
    exti_interrupt_flag_clear(EXTI_17);

    /* 配置并使能闹钟 */
    rtc_alarm_config(RTC_ALARM0, &alarm_cfg);
    rtc_alarm_enable(RTC_ALARM0);
    rtc_interrupt_enable(RTC_INT_ALARM0);
    exti_interrupt_flag_clear(EXTI_17);
}
