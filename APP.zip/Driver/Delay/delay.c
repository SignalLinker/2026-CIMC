// SysTick 延时函数，支持 OS

#include "delay.h"

static uint32_t g_fac_us = 0;      // us 延时倍乘数

#if SYS_SUPPORT_OS

#include "os.h"

static uint16_t g_fac_ms = 0;      // ms 延时倍乘数

// OS 相关宏定义
#define delay_osrunning     OSRunning
#define delay_ostickspersec OS_TICKS_PER_SEC
#define delay_osintnesting  OSIntNesting

// us 延时时关闭任务调度（防止被打断）
void delay_osschedlock(void)
{
    OSSchedLock();
}

// us 延时后恢复任务调度
void delay_osschedunlock(void)
{
    OSSchedUnlock();
}

// OS 延时，可以引发任务调度
void delay_ostimedly(uint32_t ticks)
{
    OSTimeDly(ticks);
}

// SysTick 中断服务函数
void SysTick_Handler(void)
{
    if (delay_osrunning == OS_TRUE)
    {
        OS_CPU_SysTickHandler();
    }
}

#endif

// 初始化延时函数
// sysclk: 系统时钟频率（HCLK），单位 MHz
void delay_init(uint16_t sysclk)
{
#if SYS_SUPPORT_OS
    uint32_t reload;
#endif
    SysTick->CTRL |= (1 << 2);          // SysTick 使用内核时钟
    g_fac_us = sysclk;                   // 1us 的基础计数值
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
    SysTick->LOAD = 0XFFFFFF;            // 24 位最大值
#if SYS_SUPPORT_OS
    reload = sysclk;
    reload *= 1000000 / delay_ostickspersec;
    g_fac_ms = 1000 / delay_ostickspersec;
    SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;
    SysTick->LOAD = reload;
#endif
}

// 延时 nus 微秒
void delay_us(uint32_t nus)
{
    uint32_t ticks;
    uint32_t told, tnow, tcnt = 0;
    uint32_t reload;
    reload = SysTick->LOAD;
    ticks = nus * g_fac_us;

#if SYS_SUPPORT_OS
    delay_osschedlock();
#endif

    told = SysTick->VAL;

    while (1)
    {
        tnow = SysTick->VAL;
        if (tnow != told)
        {
            if (tnow < told)
            {
                tcnt += told - tnow;
            }
            else
            {
                tcnt += reload - tnow + told;
            }
            told = tnow;
            if (tcnt >= ticks)
            {
                break;
            }
        }
    }

#if SYS_SUPPORT_OS
    delay_osschedunlock();
#endif
}

// 延时 nms 毫秒
void delay_ms(uint16_t nms)
{
#if SYS_SUPPORT_OS
    if (delay_osrunning && delay_osintnesting == 0)
    {
        if (nms >= g_fac_ms)
        {
            delay_ostimedly(nms / g_fac_ms);
        }
        nms %= g_fac_ms;
    }
#endif
    delay_us((uint32_t)(nms * 1000));
}
