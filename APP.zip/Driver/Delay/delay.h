// SysTick 延时函数（支持 OS）

#ifndef __DELAY_H
#define __DELAY_H

#include "HeaderFiles.h"

void delay_init(uint16_t sysclk);
void delay_ms(uint16_t nms);
void delay_us(uint32_t nus);

#endif
