// DMA 驱动 — 串口收发 DMA 通道配置

#include "dma.h"

uint8_t g_transfer_buf[128];
extern uint8_t recv_real_buf[1024];

void dma_transfer_config(void);
void dma_receive_config(void);

// DMA 初始化
void my_dma_init(void)
{
	rcu_periph_clock_enable(RCU_DMAX);
	dma_transfer_config();
	dma_receive_config();
}
// DMA 发送通道配置
void dma_transfer_config(void)
{
	dma_single_data_parameter_struct dma_init_struct;

	dma_deinit(DMA_TRANSFER_X , DMA_TRANSFER_CHANNEL);
	dma_init_struct.direction = DMA_MEMORY_TO_PERIPH;
	dma_init_struct.memory0_addr = (uint32_t)g_transfer_buf;
	dma_init_struct.memory_inc = DMA_MEMORY_INCREASE_ENABLE;
	dma_init_struct.number = sizeof(g_transfer_buf);
	dma_init_struct.periph_addr = DMA_USARTX_ADDR;
	dma_init_struct.periph_inc = DMA_PERIPH_INCREASE_DISABLE;
	dma_init_struct.periph_memory_width = DMA_PERIPH_WIDTH_8BIT;
	dma_init_struct.priority = DMA_PRIORITY_ULTRA_HIGH;
	dma_single_data_mode_init(DMA_TRANSFER_X , DMA_TRANSFER_CHANNEL , &dma_init_struct);
	dma_channel_subperipheral_select(DMA_TRANSFER_X , DMA_TRANSFER_CHANNEL , DMA_SUBPERI4);
	dma_circulation_disable(DMA_TRANSFER_X , DMA_TRANSFER_CHANNEL);
}

// DMA 接收通道配置
void dma_receive_config(void)
{
	dma_single_data_parameter_struct dma_parameter;

	dma_deinit(DMA_RECEIVE_X , DMA_RECEIVE_CHANNEL);
	dma_parameter.direction = DMA_PERIPH_TO_MEMORY;
	dma_parameter.periph_addr = DMA_USARTX_ADDR;
	dma_parameter.periph_inc = DMA_PERIPH_INCREASE_DISABLE;
	dma_parameter.periph_memory_width = DMA_PERIPH_WIDTH_8BIT;
	dma_parameter.memory0_addr = (uint32_t)recv_real_buf;
	dma_parameter.memory_inc = DMA_MEMORY_INCREASE_ENABLE;
	dma_parameter.number = sizeof(recv_real_buf);
	dma_parameter.priority = DMA_PRIORITY_ULTRA_HIGH;
	dma_parameter.circular_mode = DMA_CIRCULAR_MODE_DISABLE;
	dma_single_data_mode_init(DMA_RECEIVE_X , DMA_RECEIVE_CHANNEL , &dma_parameter);
	dma_channel_subperipheral_select(DMA_RECEIVE_X , DMA_RECEIVE_CHANNEL , DMA_SUBPERI4);
	dma_channel_enable(DMA_RECEIVE_X , DMA_RECEIVE_CHANNEL);
}
