// DMA 驱动头文件

#ifndef __DMA_H__
#define __DMA_H__

#include "HeaderFiles.h"

// USART1 DMA 通道: TX=DMA1_CH1, RX=DMA1_CH3, 子外设选择 SUBPERI4

#define RCU_DMAX RCU_DMA1

#define DMA_USARTX_ADDR (uint32_t)&USART_DATA(USART1)

#define DMA_TRANSFER_X DMA1
#define DMA_TRANSFER_CHANNEL DMA_CH1

#define DMA_RECEIVE_X DMA1
#define DMA_RECEIVE_CHANNEL DMA_CH3

void my_dma_init(void);

#endif
