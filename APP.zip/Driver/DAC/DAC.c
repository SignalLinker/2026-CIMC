// DAC 驱动 — PA4(DAC_OUT0)，12bit，0~3.3V

#include "DAC.h"

// DAC0 初始化，PA4 模拟输出，使能时钟和输出缓冲

void DAC_Init(void)
{
    /* 使能 GPIOA 时钟，PA4 配置为模拟模式 */
    rcu_periph_clock_enable(RCU_GPIOA);
    gpio_mode_set(GPIOA, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, GPIO_PIN_4);

    /* 使能 DAC 时钟 */
    rcu_periph_clock_enable(RCU_DAC);

    /* 复位 DAC0 */
    dac_deinit(DAC0);

    /* 使能 DAC0_OUT0 及输出缓冲 */
    dac_enable(DAC0, DAC_OUT0);
    dac_output_buffer_enable(DAC0, DAC_OUT0);

    /* 初始输出 0V */
    dac_data_set(DAC0, DAC_OUT0, DAC_ALIGN_12B_R, 0);
}

// 设置 DAC 输出原始值（12bit，0~4095）

void DAC_SetValue(uint16_t value)
{
    if (value > DAC_RESOLUTION) {
        value = DAC_RESOLUTION;
    }
    dac_data_set(DAC0, DAC_OUT0, DAC_ALIGN_12B_R, value);
}

// 设置 DAC 输出电压（0 ~ 3.3V）

void DAC_SetVoltage(float voltage)
{
    uint16_t dac_val;

    if (voltage < 0.0f) {
        voltage = 0.0f;
    } else if (voltage > DAC_VREF) {
        voltage = DAC_VREF;
    }

    dac_val = (uint16_t)(voltage / DAC_VREF * DAC_RESOLUTION);
    dac_data_set(DAC0, DAC_OUT0, DAC_ALIGN_12B_R, dac_val);
}

// ADC→DAC 联动：ADC 原始值经变比换算后从 DAC 输出

void DAC_Follow_ADC(uint16_t adc_raw, float ratio)
{
    float fval = (float)adc_raw * ratio;

    if (fval < 0.0f) {
        fval = 0.0f;
    } else if (fval > (float)DAC_RESOLUTION) {
        fval = (float)DAC_RESOLUTION;
    }

    dac_data_set(DAC0, DAC_OUT0, DAC_ALIGN_12B_R, (uint16_t)(fval + 0.5f));
}

