// GD30AD3344 外部 ADC (PT100) 驱动 — 轮询 SPI 版

#ifndef __GD30AD3344_H
#define __GD30AD3344_H

#ifdef __cplusplus
extern "C" {
#endif

#include "HeaderFiles.h"

// SPI3 引脚定义

#define GD30_SPI              SPI3
#define GD30_SPI_RCU          RCU_SPI3
#define GD30_SPI_PORT         GPIOE
#define GD30_SPI_PORT_RCU     RCU_GPIOE
#define GD30_SPI_AF           GPIO_AF_5
#define GD30_SPI_SCK          GPIO_PIN_12
#define GD30_SPI_MISO         GPIO_PIN_13
#define GD30_SPI_MOSI         GPIO_PIN_14

#define GD30_CS_PORT          GPIOE
#define GD30_CS_PIN           GPIO_PIN_10
#define GD30_CS_LOW()         gpio_bit_reset(GD30_CS_PORT, GD30_CS_PIN)
#define GD30_CS_HIGH()        gpio_bit_set(GD30_CS_PORT, GD30_CS_PIN)

/************************* 配置寄存器位域 *************************/

typedef struct _GD30AD3344_Config {
    uint16_t SS         : 1;  /* 启动单次转换 / 转换状态 */
    uint16_t MUX        : 3;  /* 输入通道选择 */
    uint16_t PGA        : 3;  /* 满量程范围选择 */
    uint16_t MODE       : 1;  /* 转换模式 */
    uint16_t DR         : 3;  /* 数据速率选择 */
    uint16_t RESERVED_1 : 1;  /* 保留位 */
    uint16_t PULL_UP_EN : 1;  /* 内部上拉使能 */
    uint16_t NOP        : 2;  /* 操作模式 */
    uint16_t RESERVED   : 1;  /* 保留位 */
} GD30AD3344_Config;

extern GD30AD3344_Config GD30AD3344_InitStruct;

/************************* 枚举定义 *************************/

typedef enum {
    GD30AD3344_OS_DISABLE        = 0,
    GD30AD3344_OS_SINGLE_CONVERT = 1,
} GD30AD3344_OS_TypeDef;

typedef enum {
    GD30AD3344_Channel_0 = 0,  /* AINP=AIN0, AINN=AIN1 */
    GD30AD3344_Channel_1 = 1,  /* AINP=AIN0, AINN=AIN3 */
    GD30AD3344_Channel_2 = 2,  /* AINP=AIN1, AINN=AIN3 */
    GD30AD3344_Channel_3 = 3,  /* AINP=AIN2, AINN=AIN3 */
    GD30AD3344_Channel_4 = 4,  /* AINP=AIN0, AINN=GND  */
    GD30AD3344_Channel_5 = 5,  /* AINP=AIN1, AINN=GND  */
    GD30AD3344_Channel_6 = 6,  /* AINP=AIN2, AINN=GND  */
    GD30AD3344_Channel_7 = 7,  /* AINP=AIN3, AINN=GND  */
} GD30AD3344_Channel_TypeDef;

typedef enum {
    GD30AD3344_PGA_6V144 = 0,
    GD30AD3344_PGA_4V096 = 1,
    GD30AD3344_PGA_2V048 = 2,
    GD30AD3344_PGA_1V024 = 3,
    GD30AD3344_PGA_0V512 = 4,
    GD30AD3344_PGA_0V256 = 5,
    GD30AD3344_PGA_0V064 = 6,
    GD30AD3344_PGA_RESERVED = 7,
} GD30AD3344_PGA_TypeDef;

typedef enum {
    GD30AD3344_MODE_CONTINUOUS  = 0,
    GD30AD3344_MODE_SINGLE_SHOT = 1,
} GD30AD3344_Mode_TypeDef;

typedef enum {
    GD30AD3344_DR_6_25SPS  = 0,
    GD30AD3344_DR_12_5SPS  = 1,
    GD30AD3344_DR_25SPS    = 2,
    GD30AD3344_DR_50SPS    = 3,
    GD30AD3344_DR_100SPS   = 4,
    GD30AD3344_DR_250SPS   = 5,
    GD30AD3344_DR_500SPS   = 6,
    GD30AD3344_DR_1000SPS  = 7,
} GD30AD3344_DR_TypeDef;

typedef enum {
    GD30AD3344_PULL_UP_DISABLE = 0,
    GD30AD3344_PULL_UP_ENABLE  = 1,
} GD30AD3344_PullUp_TypeDef;

typedef enum {
    GD30AD3344_NOP_INVALID_NO_UPDATE = 0,
    GD30AD3344_NOP_VALID_UPDATE      = 1,
    GD30AD3344_NOP_VALID_NO_UPDATE   = 2,
    GD30AD3344_NOP_INVALID_NO_CHANGE = 3,
} GD30AD3344_NOP_TypeDef;

#define GD30AD3344_RESERVED_0  0U
#define GD30AD3344_RESERVED_1  1U

/* 配置结构体 → 16-bit 寄存器值 */
#define GD30AD3344_InitStruct_Value  ((uint16_t)( \
    (GD30AD3344_InitStruct.SS         << 15) |    \
    (GD30AD3344_InitStruct.MUX        << 12) |    \
    (GD30AD3344_InitStruct.PGA        <<  9) |    \
    (GD30AD3344_InitStruct.MODE       <<  8) |    \
    (GD30AD3344_InitStruct.DR         <<  5) |    \
    (GD30AD3344_InitStruct.RESERVED_1 <<  4) |    \
    (GD30AD3344_InitStruct.PULL_UP_EN <<  3) |    \
    (GD30AD3344_InitStruct.NOP        <<  1) |    \
    (GD30AD3344_InitStruct.RESERVED   <<  0)))

/************************* 函数声明 *************************/

void  GD30AD3344_Hardware_Init(void);
float GD30AD3344_AD_Read(GD30AD3344_Channel_TypeDef CH, GD30AD3344_PGA_TypeDef Ref);

#ifdef __cplusplus
}
#endif

#endif /* __GD30AD3344_H */
