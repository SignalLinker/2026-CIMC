// GD30AD3344 外部 ADC (PT100) 驱动 — 轮询 SPI，无 DMA 依赖

#include "gd30ad3344.h"

GD30AD3344_Config GD30AD3344_InitStruct;

// 轮询 SPI3 收发半字

static uint16_t gd30_spi_transfer16(uint16_t tx_data)
{
    uint8_t rx_h, rx_l;

    GD30_CS_LOW();

    /* 发高字节, 收高字节 */
    while (RESET == spi_i2s_flag_get(GD30_SPI, SPI_FLAG_TBE));
    spi_i2s_data_transmit(GD30_SPI, (uint8_t)(tx_data >> 8));
    while (RESET == spi_i2s_flag_get(GD30_SPI, SPI_FLAG_RBNE));
    rx_h = spi_i2s_data_receive(GD30_SPI);

    /* 发低字节, 收低字节 */
    while (RESET == spi_i2s_flag_get(GD30_SPI, SPI_FLAG_TBE));
    spi_i2s_data_transmit(GD30_SPI, (uint8_t)tx_data);
    while (RESET == spi_i2s_flag_get(GD30_SPI, SPI_FLAG_RBNE));
    rx_l = spi_i2s_data_receive(GD30_SPI);

    GD30_CS_HIGH();
    return ((uint16_t)rx_h << 8) | rx_l;
}

/************************* PGA 满量程电压 *************************/

static float gd30_pga_voltage(GD30AD3344_PGA_TypeDef PGA)
{
    switch (PGA) {
    case GD30AD3344_PGA_6V144: return 6.144f;
    case GD30AD3344_PGA_4V096: return 4.096f;
    case GD30AD3344_PGA_2V048: return 2.048f;
    case GD30AD3344_PGA_1V024: return 1.024f;
    case GD30AD3344_PGA_0V512: return 0.512f;
    case GD30AD3344_PGA_0V256: return 0.256f;
    case GD30AD3344_PGA_0V064: return 0.064f;
    default:                   return 2.048f;
    }
}

/************************* 初始化 (SPI3 + 芯片配置) *************************/

void GD30AD3344_Hardware_Init(void)
{
    spi_parameter_struct spi_init_struct;

    /* 时钟使能 */
    rcu_periph_clock_enable(GD30_SPI_PORT_RCU);
    rcu_periph_clock_enable(GD30_SPI_RCU);

    /* SPI3 GPIO: SCK/PE12, MISO/PE13, MOSI/PE14 */
    gpio_af_set(GD30_SPI_PORT, GD30_SPI_AF,
                GD30_SPI_SCK | GD30_SPI_MISO | GD30_SPI_MOSI);
    gpio_mode_set(GD30_SPI_PORT, GPIO_MODE_AF, GPIO_PUPD_NONE,
                  GD30_SPI_SCK | GD30_SPI_MISO | GD30_SPI_MOSI);
    gpio_output_options_set(GD30_SPI_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ,
                            GD30_SPI_SCK | GD30_SPI_MISO | GD30_SPI_MOSI);

    /* CS: PE10 */
    gpio_mode_set(GD30_CS_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GD30_CS_PIN);
    gpio_output_options_set(GD30_CS_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GD30_CS_PIN);
    GD30_CS_HIGH();

    /* SPI3 参数配置: 主模式, 全双工, 8bit, CPOL=1/CPHA=1, PSC=8 */
    spi_init_struct.trans_mode           = SPI_TRANSMODE_FULLDUPLEX;
    spi_init_struct.device_mode          = SPI_MASTER;
    spi_init_struct.frame_size           = SPI_FRAMESIZE_8BIT;
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_HIGH_PH_2EDGE;  /* SPI Mode 1 */
    spi_init_struct.nss                  = SPI_NSS_SOFT;
    spi_init_struct.prescale             = SPI_PSC_8;
    spi_init_struct.endian               = SPI_ENDIAN_MSB;
    spi_init(GD30_SPI, &spi_init_struct);
    spi_enable(GD30_SPI);

    /* 写入 GD30AD3344 默认配置 */
    GD30AD3344_InitStruct.SS         = GD30AD3344_OS_DISABLE;
    GD30AD3344_InitStruct.MUX        = GD30AD3344_Channel_0;
    GD30AD3344_InitStruct.PGA        = GD30AD3344_PGA_4V096;
    GD30AD3344_InitStruct.MODE       = GD30AD3344_MODE_CONTINUOUS;
    GD30AD3344_InitStruct.DR         = GD30AD3344_DR_25SPS;
    GD30AD3344_InitStruct.RESERVED_1 = GD30AD3344_RESERVED_0;
    GD30AD3344_InitStruct.PULL_UP_EN = GD30AD3344_PULL_UP_ENABLE;
    GD30AD3344_InitStruct.NOP        = GD30AD3344_NOP_VALID_UPDATE;
    GD30AD3344_InitStruct.RESERVED   = GD30AD3344_RESERVED_1;

    gd30_spi_transfer16(GD30AD3344_InitStruct_Value);
}

/************************* 读取单通道 (返回电压, 单位 V) *************************/

float GD30AD3344_AD_Read(GD30AD3344_Channel_TypeDef CH, GD30AD3344_PGA_TypeDef Ref)
{
    uint16_t raw;
    int16_t  code;

    GD30AD3344_InitStruct.MUX = CH;
    GD30AD3344_InitStruct.PGA = Ref;

    raw  = gd30_spi_transfer16(GD30AD3344_InitStruct_Value);
    code = (int16_t)raw;

    return (float)code * gd30_pga_voltage(Ref) / 32768.0f;
}
