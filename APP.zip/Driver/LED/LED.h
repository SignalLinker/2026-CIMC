// LED 驱动头文件

#ifndef __LED_H
#define __LED_H

#include "HeaderFiles.h"

#define  LED_PORT_1 GPIOE
#define  LED_PORT_4 GPIOC

#define  LED_PORT_PIN1 GPIO_PIN_1
#define  LED_PORT_PIN2 GPIO_PIN_0
#define  LED_PORT_PIN3 GPIO_PIN_7
#define  LED_PORT_PIN4 GPIO_PIN_13

// LED1 控制
#define    LED1_OFF()      gpio_bit_reset(GPIOE, GPIO_PIN_1)
#define    LED1_ON()       gpio_bit_set(GPIOE, GPIO_PIN_1)
#define    LED1_TOGGLE()   gpio_bit_toggle(GPIOE, GPIO_PIN_1)

// LED2 控制
#define    LED2_OFF()      gpio_bit_reset(GPIOE, GPIO_PIN_0)
#define    LED2_ON()       gpio_bit_set(GPIOE, GPIO_PIN_0)
#define    LED2_TOGGLE()   gpio_bit_toggle(GPIOE, GPIO_PIN_0)

// LED3 控制
#define    LED3_OFF()      gpio_bit_reset(GPIOE, GPIO_PIN_7)
#define    LED3_ON()       gpio_bit_set(GPIOE, GPIO_PIN_7)

// LED4 控制
#define    LED4_OFF()      gpio_bit_reset(GPIOC, GPIO_PIN_13)
#define    LED4_ON()       gpio_bit_set(GPIOC, GPIO_PIN_13)

void LED_Init(void);

#endif
