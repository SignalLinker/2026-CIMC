// LED 驱动 — 4 个 LED 初始化和控制

#include "LED.h"

void LED_Init(void)
{
	rcu_periph_clock_enable(RCU_GPIOE);
	rcu_periph_clock_enable(RCU_GPIOC);

	// LED4 初始化（PC13）
	gpio_mode_set(LED_PORT_4, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, LED_PORT_PIN4);
	gpio_output_options_set(LED_PORT_4, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, LED_PORT_PIN4);
	gpio_bit_reset(LED_PORT_4, LED_PORT_PIN4);

	// LED1/2/3 初始化（PE0/1/7）
	gpio_mode_set(KEY_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, LED_PORT_PIN1|LED_PORT_PIN2|LED_PORT_PIN3);
	gpio_output_options_set(KEY_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, LED_PORT_PIN1|LED_PORT_PIN2|LED_PORT_PIN3);
	gpio_bit_reset(KEY_PORT, LED_PORT_PIN1|LED_PORT_PIN2|LED_PORT_PIN3);
}
