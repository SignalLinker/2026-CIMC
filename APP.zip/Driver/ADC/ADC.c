// ADC 驱动 — 采样、均值滤波、电压换算

#include "ADC.h"

/* 变量定义 */

uint16_t adc_value;                        /* 最新 ADC 读数 */
uint16_t adc_value_buf[ADC_BUF_SIZE];      /* ADC 历史缓存 */
static uint8_t adc_buf_index = 0;          /* 缓存写入位置 */
static uint8_t uart_flag = 0;
/* 函数定义 */

// ADC 端口初始化，使能时钟和 GPIO

void ADC_port_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOC);
    rcu_periph_clock_enable(RCU_ADC0);

    gpio_mode_set(GPIOC, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, GPIO_PIN_0 | GPIO_PIN_1);

    adc_clock_config(ADC_ADCCK_PCLK2_DIV8);

    ADC_Init();

    /* 注入通道: CH11(PC1) 用于 DAC 回读, 独立于常规 CH10 序列 */
    adc_channel_length_config(ADC0, ADC_INSERTED_CHANNEL, 1);
    adc_inserted_channel_config(ADC0, 0, ADC_CHANNEL_11, ADC_SAMPLETIME_56);

    adc_software_trigger_enable(ADC0, ADC_ROUTINE_CHANNEL);
}

// ADC 初始化配置（连续模式、通道、触发）

void ADC_Init(void)
{
    adc_deinit();

    adc_special_function_config(ADC0, ADC_CONTINUOUS_MODE, ENABLE);
    adc_data_alignment_config(ADC0, ADC_DATAALIGN_RIGHT);
    adc_channel_length_config(ADC0, ADC_ROUTINE_CHANNEL, 1);

    adc_routine_channel_config(ADC0, 0, ADC_CHANNEL_10, ADC_SAMPLETIME_56);

    /* 使用软件触发 + 连续模式，不需要外部触发 */

    adc_enable(ADC0);

    delay_1ms(1);

    adc_calibration_enable(ADC0);
}

// 读取 ADC 规则通道数据，更新最新值和缓存

void ADC_Value_Update(void)
{
    adc_value = adc_routine_data_read(ADC0);

    adc_value_buf[adc_buf_index] = adc_value;
    adc_buf_index = (adc_buf_index + 1) % ADC_BUF_SIZE;
}

// 返回最新一次 ADC 读数

uint16_t ADC_Get_Value(void)
{
    return adc_value;
}

// 多次采样取平均值（每次间隔 5ms）
// times: 采样次数
// 返回: 平均值

uint16_t ADC_Get_Average(uint8_t times)
{
    uint32_t sum = 0;
    uint8_t i;

    if (times == 0) return 0;

    for (i = 0; i < times; i++) {
        ADC_Value_Update();
        sum += ADC_Get_Value();
        delay_1ms(5);
    }
    return (uint16_t)(sum / times);
}

// ADC 原始值 → 工程电压值
// voltage = raw * (3.3 / 4096) * ratio
// raw: ADC 原始值（0~4095），ratio: 变比系数
// 返回: 工程电压值（V）

float ADC_To_Voltage(uint16_t raw, float ratio)
{
    return (float)raw * (3.3f / 4096.0f) * ratio;
}

// ADC 测试用，读取并打印当前值，调试时在主循环里调一下看看
void ADC_Test_Print(void)
{
    /* 更新ADC值 */
    ADC_Value_Update();
    
		if(uart_flag==0){
    /* 通过串口打印ADC值 */
    printf("adc_value: %d\n", ADC_Get_Value());
		uart_flag = 1;
		}
}

