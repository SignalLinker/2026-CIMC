// ADC 驱动头文件

#ifndef __ADC_H
#define __ADC_H

#include "HeaderFiles.h"

#define ADC_BUF_SIZE    16

extern uint16_t adc_value;              /* 最新 ADC 读数 */
extern uint16_t adc_value_buf[ADC_BUF_SIZE]; /* ADC 历史缓存 */

// 函数声明
void ADC_port_init(void);               /* ADC 端口初始化 */
void ADC_Init(void);                    /* ADC 初始化 */
void ADC_Value_Update(void);            /* 读取 ADC 值并更新缓存 */
uint16_t ADC_Get_Value(void);           /* 获取最新 ADC 读数 */
uint16_t ADC_Get_Average(uint8_t times); /* 多次采样取平均值 */
float ADC_To_Voltage(uint16_t raw, float ratio); /* ADC原始值转工程电压 */
void ADC_Test_Print(void);              /* ADC测试打印函数（更新值并通过串口打印） */

#endif


