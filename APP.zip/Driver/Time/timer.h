// TIMER2定时器驱动头文件
#ifndef __TIMER_H__
#define __TIMER_H__

#include "HeaderFiles.h"

void my_timer_init(void);

#endif
