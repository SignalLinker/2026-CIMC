// 内部 Flash IAP 驱动 — 页擦除/字写入/软复位

#ifndef __FMC_IAP_H
#define __FMC_IAP_H

#include "gd32f4xx.h"

/* 擦除一页（4KB对齐），成功返回0 */
uint8_t fmc_iap_erase_page(uint32_t addr);

/* 擦除指定大小区域（自动处理多页），成功返回0 */
uint8_t fmc_iap_erase(uint32_t addr, uint32_t size);

/* 写入一个字（4字节对齐），成功返回0 */
uint8_t fmc_iap_write_word(uint32_t addr, uint32_t data);

/* 写入指定长度数据（自动处理对齐和尾部字节），成功返回0 */
uint8_t fmc_iap_write(uint32_t addr, uint8_t *data, uint32_t len);

/* 软件复位 */
void fmc_iap_software_reset(void);

#endif

