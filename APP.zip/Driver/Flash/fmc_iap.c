// 内部 Flash IAP 驱动 — 页擦除、字写入

#include "fmc_iap.h"

// 擦除一个 4KB 页
uint8_t fmc_iap_erase_page(uint32_t addr)
{
    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
    fmc_page_erase(addr);
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
    fmc_lock();
    return 0;
}

// 擦除指定大小区域（自动处理多页）
uint8_t fmc_iap_erase(uint32_t addr, uint32_t size)
{
    uint32_t start_page = addr & ~0xFFF;
    uint32_t end_addr = addr + size;
    uint32_t page;

    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);

    for (page = start_page; page < end_addr; page += 0x1000) {
        fmc_page_erase(page);
        fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
    }

    fmc_lock();
    return 0;
}

/************************************************************
 * Function :       fmc_iap_write_word
 * Comment  :       写入一个32位字（地址需4字节对齐）
 ************************************************************/
uint8_t fmc_iap_write_word(uint32_t addr, uint32_t data)
{
    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
    fmc_word_program(addr, data);
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
    fmc_lock();
    return 0;
}

/************************************************************
 * Function :       fmc_iap_write
 * Comment  :       写入任意长度数据（处理对齐和尾部字节）
 ************************************************************/
uint8_t fmc_iap_write(uint32_t addr, uint8_t *data, uint32_t len)
{
    uint32_t i;
    uint32_t word;
    uint32_t aligned_addr;

    if (len == 0) return 0;

    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);

    i = 0;

    /* 头部非对齐字节：读-改-写第一个字 */
    if (addr & 0x3) {
        aligned_addr = addr & ~0x3;
        word = *(__IO uint32_t *)aligned_addr;
        while ((addr + i) & 0x3 && i < len) {
            ((uint8_t *)&word)[(addr + i) & 0x3] = data[i];
            i++;
        }
        fmc_word_program(aligned_addr, word);
        fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
    }

    /* 整字写入 */
    while (i + 4 <= len) {
        word = *(uint32_t *)&data[i];
        fmc_word_program(addr + i, word);
        fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
        i += 4;
    }

    /* 尾部剩余字节：读-改-写最后一个字 */
    if (i < len) {
        aligned_addr = (addr + i) & ~0x3;
        word = *(__IO uint32_t *)aligned_addr;
        while (i < len) {
            ((uint8_t *)&word)[(addr + i) & 0x3] = data[i];
            i++;
        }
        fmc_word_program(aligned_addr, word);
        fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
    }

    fmc_lock();
    return 0;
}

/************************************************************
 * Function :       fmc_iap_software_reset
 * Comment  :       触发软件复位
 ************************************************************/
void fmc_iap_software_reset(void)
{
    __set_FAULTMASK(1);
    NVIC_SystemReset();
}

/****************************End*****************************/
