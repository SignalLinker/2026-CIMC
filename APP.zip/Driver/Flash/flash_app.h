// Flash 应用层头文件

#ifndef __FLASH_APP_H
#define __FLASH_APP_H

#include "HeaderFiles.h"

// Flash 存储区规划
/* Flash存储区基地址 - 根据实际芯片容量调整 */
#define FLASH_BASE_ADDR          0x00000000

/* Flash存储区域划分 */
#define FLASH_PARAM_ADDR          0x00010000  /* 参数存储区起始地址（64KB处） */
#define FLASH_DATA_ADDR           0x00020000  /* 数据存储区起始地址（128KB处） */
#define FLASH_LOG_ADDR            0x00030000  /* 日志存储区起始地址（192KB处） */

/* 参数存储区大小 */
#define FLASH_PARAM_SIZE          4096        /* 参数区大小：4KB（1个扇区） */

/* Flash总容量标识 */
#define FLASH_MAX_ADDR            0x100000    /* 1MB Flash最大地址 */

// Flash 操作状态枚举
typedef enum
{
    FLASH_OK = 0,                /* 操作成功 */
    FLASH_ERROR = 1,              /* 操作失败 */
    FLASH_BUSY = 2,               /* Flash忙 */
    FLASH_TIMEOUT = 3,           /* 操作超时 */
    FLASH_ADDR_ERROR = 4,        /* 地址错误 */
    FLASH_SIZE_ERROR = 5,        /* 大小错误 */
    FLASH_NULL_ERROR = 6         /* 空指针错误 */
} flash_status_t;

/************************* Flash参数结构体 *************************/
typedef struct
{
    uint8_t device_name[16];     /* 设备名称 */
    uint8_t firmware_version[8]; /* 固件版本 */
    uint32_t config_flag;        /* 配置标志 */
    uint32_t param_addr;         /* 参数存储地址 */
    uint32_t data_addr;          /* 数据存储地址 */
    uint32_t log_addr;           /* 日志存储地址 */
    uint16_t param_size;        /* 参数大小 */
    uint16_t data_size;          /* 数据大小 */
} flash_param_t;

/************************* Flash存储信息结构体 *************************/
typedef struct
{
    uint32_t total_size;         /* Flash总大小 */
    uint32_t sector_size;        /* 扇区大小 */
    uint32_t page_size;          /* 页大小 */
    uint32_t device_id;          /* 设备ID */
    uint8_t is_initialized;      /* 初始化标志 */
    uint8_t is_busy;             /* 忙标志 */
} flash_info_t;

/************************* 函数声明 *************************/

/*========== Flash业务功能1：基础操作 ==========*/
/*!
    \brief      Flash应用层初始化
    \param[in]  无
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_init(void);

/*!
    \brief      读取Flash设备ID
    \param[in]  无
    \param[out] 无
    \retval     uint32_t: Flash设备ID
*/
uint32_t flash_app_read_id(void);

/*!
    \brief      获取Flash状态信息
    \param[in]  无
    \param[out] pflash_info: Flash信息结构体指针
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_get_info(flash_info_t *pflash_info);

/*========== Flash业务功能2：数据读写 ==========*/
/*!
    \brief      从Flash读取数据
    \param[in]  read_addr: 读取地址
    \param[in]  pbuffer: 数据缓冲区指针
    \param[in]  num_byte_to_read: 要读取的字节数
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_read(uint32_t read_addr, uint8_t *pbuffer, uint32_t num_byte_to_read);

/*!
    \brief      向Flash写入数据（自动处理分页和扇区边界）
    \param[in]  write_addr: 写入地址
    \param[in]  pbuffer: 数据缓冲区指针
    \param[in]  num_byte_to_write: 要写入的字节数
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_write(uint32_t write_addr, uint8_t *pbuffer, uint32_t num_byte_to_write);

/*!
    \brief      读取Flash一个扇区的数据
    \param[in]  sector_addr: 扇区地址（需对齐4KB）
    \param[in]  pbuffer: 数据缓冲区指针
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_read_sector(uint32_t sector_addr, uint8_t *pbuffer);

/*!
    \brief      写入Flash一个扇区的数据（自动擦除）
    \param[in]  sector_addr: 扇区地址（需对齐4KB）
    \param[in]  pbuffer: 数据缓冲区指针
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_write_sector(uint32_t sector_addr, uint8_t *pbuffer);

/*========== Flash业务功能3：存储管理 ==========*/
/*!
    \brief      初始化Flash参数区
    \param[in]  无
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_param_init(void);

/*!
    \brief      读取Flash参数
    \param[in]  pparam: 参数结构体指针
    \param[out] pparam: 读取到的参数
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_param_read(flash_param_t *pparam);

/*!
    \brief      保存Flash参数
    \param[in]  pparam: 参数结构体指针
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_param_save(flash_param_t *pparam);

/*!
    \brief      擦除Flash参数区
    \param[in]  无
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_param_erase(void);

/*========== Flash业务功能4：区域管理 ==========*/
/*!
    \brief      擦除Flash指定区域
    \param[in]  start_addr: 起始地址
    \param[in]  num_byte_to_erase: 要擦除的字节数
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_erase(uint32_t start_addr, uint32_t num_byte_to_erase);

/*!
    \brief      擦除Flash整个数据存储区
    \param[in]  无
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_erase_data_area(void);

/*!
    \brief      擦除Flash整个芯片
    \param[in]  无
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_erase_all(void);

/*!
    \brief      验证Flash区域是否为空（全部为0xFF）
    \param[in]  start_addr: 起始地址
    \param[in]  size: 要验证的字节数
    \param[out] 无
    \retval     flash_status_t: 操作状态（FLASH_OK表示为空）
*/
flash_status_t flash_app_verify_blank(uint32_t start_addr, uint32_t size);

/*========== Flash业务功能5：状态检测与错误处理 ==========*/
/*!
    \brief      检测Flash是否忙碌
    \param[in]  无
    \param[out] 无
    \retval     uint8_t: 1-忙碌，0-空闲
*/
uint8_t flash_app_is_busy(void);

/*!
    \brief      等待Flash空闲
    \param[in]  timeout_ms: 超时时间（毫秒）
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_wait_idle(uint32_t timeout_ms);

/*!
    \brief      检测Flash是否存在
    \param[in]  无
    \param[out] 无
    \retval     uint8_t: 1-存在，0-不存在
*/
uint8_t flash_app_is_exist(void);

/*!
    \brief      获取Flash最后一次错误状态
    \param[in]  无
    \param[out] 无
    \retval     flash_status_t: 错误状态
*/
flash_status_t flash_app_get_error(void);

/*!
    \brief      清除Flash错误状态
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void flash_app_clear_error(void);

/*========== 辅助功能函数 ==========*/
/*!
    \brief      打印Flash信息
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void flash_app_print_info(void);

/*!
    \brief      内存数据写入Flash（带边界检查）
    \param[in]  dest_addr: 目标Flash地址
    \param[in]  psrc: 源数据指针
    \param[in]  size: 数据大小
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_memcpy_to_flash(uint32_t dest_addr, const uint8_t *psrc, uint32_t size);

/*!
    \brief      Flash数据复制到内存（带边界检查）
    \param[in]  pdest: 目标内存指针
    \param[in]  src_addr: 源Flash地址
    \param[in]  size: 数据大小
    \param[out] 无
    \retval     flash_status_t: 操作状态
*/
flash_status_t flash_app_memcpy_from_flash(uint8_t *pdest, uint32_t src_addr, uint32_t size);

#endif
