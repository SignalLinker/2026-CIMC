// USART1 RS485通信驱动，轮询收发 + ASCII-hex协议帧解析

// 头文件

#include "usart.h"
#include "handler.h"
#include "protocol.h"

// 全局变量

uint8_t           recv_real_buf[USART_RECV_BUF_SIZE] = { 0 };
volatile uint16_t recv_real_len = 0;

// RS485 DE引脚控制

static void rs485_de_init(void)
{
    rcu_periph_clock_enable(RS485_DE_RCU);
    gpio_mode_set(RS485_DE_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, RS485_DE_PIN);
    gpio_output_options_set(RS485_DE_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, RS485_DE_PIN);
    RS485_RX_MODE();
}

// 轮询发送（含RS485 DE控制）

void usart_send_bytes(uint8_t *buf, uint16_t len)
{
    uint16_t i;
    if (len == 0) return;

    RS485_TX_MODE();

    for (i = 0; i < len; i++) {
        while (RESET == usart_flag_get(USART, USART_FLAG_TBE));
        USART_DATA(USART) = (uint32_t)buf[i];
    }
    while (RESET == usart_flag_get(USART, USART_FLAG_TC));

    RS485_RX_MODE();
}

// printf重定向到USART

int fputc(int ch, FILE *f)
{
    usart_send_bytes((uint8_t *)&ch, 1);
    return ch;
}

// 串口接收 + 帧解析（中断接收 + 主循环解析）

void usart_recv_buf(void)
{
    uint16_t        remaining;
    uint16_t        processed = 0;
    protocol_frame_t frame;

    /* 字节由 USART1_IRQHandler 中断接收，此处仅做帧解析 */

    if (recv_real_len == 0) return;
    if (recv_real_len < 22) return;  /* 最小帧 11字节二进制 * 2 = 22 ASCII字符 */

    remaining = recv_real_len;

    /* 循环解析：一帧中可能包含多个协议帧 */
    while (remaining >= 22) {
        uint16_t consumed;
        uint8_t  ret;

        ret = protocol_frame_parse(&recv_real_buf[processed], remaining, &frame, &consumed);

        if (ret == 0) {
            handler_dispatch(&frame);
            processed += consumed;
            remaining -= consumed;
        } else if (ret == 2) {
            /* 数据不完整，等待更多数据 */
            break;
        } else if (ret == 3) {
            /* CRC校验失败 → 错误应答 (使用本机设备ID) */
            protocol_send_error_reply(g_device_id);
            processed += consumed;
            remaining -= consumed;
        } else if (ret == 4 || ret == PARSE_ERR_LEN) {
            /* 帧尾错误/长度不匹配 → 错误应答 */
            protocol_send_error_reply(g_device_id);
            processed += consumed;
            remaining -= consumed;
        } else {
            /* ret==1: 未找到帧头 / ret==5: hex解码失败 → 跳过无效数据 */
            if (consumed == 0) consumed = 4;
            processed += consumed;
            remaining -= consumed;
        }
    }

    /* 将未处理的数据移到缓冲区头部 (临界区: 关RBNE中断防止ISR并发写入) */
    usart_interrupt_disable(USART, USART_INT_RBNE);
    if (processed > 0) {
        uint16_t tail_len = recv_real_len - processed;
        if (tail_len > 0) {
            memmove(recv_real_buf, &recv_real_buf[processed], tail_len);
        }
        recv_real_len = tail_len;
    }
    usart_interrupt_enable(USART, USART_INT_RBNE);

    /* 缓冲区已满，清空 (临界区) */
    if (recv_real_len >= USART_RECV_BUF_SIZE - 4) {
        usart_interrupt_disable(USART, USART_INT_RBNE);
        memset(recv_real_buf, 0, USART_RECV_BUF_SIZE);
        recv_real_len = 0;
        usart_interrupt_enable(USART, USART_INT_RBNE);
    }
}

// USART1接收中断

void USART1_IRQHandler(void)
{
    if (usart_interrupt_flag_get(USART, USART_INT_FLAG_RBNE) != RESET) {
        uint8_t byte = (uint8_t)usart_data_receive(USART);
        LED2_TOGGLE();
        if (recv_real_len < USART_RECV_BUF_SIZE - 1) {
            recv_real_buf[recv_real_len++] = byte;
        }
    }
}

// USART初始化

void usart_init(void)
{
    /* RS485 DE 引脚初始化 */
    rs485_de_init();

    /* 使能 USART 和 GPIO 时钟 */
    rcu_periph_clock_enable(USART_RCU);
    rcu_periph_clock_enable(USART_PIN_RCU);

    /* 配置 TX/RX 引脚为复用功能 (AF_7 for USART1) */
    gpio_af_set(USART_PORT, GPIO_AF_7, USART_TX_Pin | USART_RX_Pin);

    /* 配置 GPIO 模式 */
    gpio_mode_set(USART_PORT, GPIO_MODE_AF, GPIO_PUPD_NONE, USART_TX_Pin | USART_RX_Pin);

    /* 配置 GPIO 输出选项 */
    gpio_output_options_set(USART_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, USART_TX_Pin | USART_RX_Pin);

    /* 配置 USART 参数 (中断接收模式) */
    usart_deinit(USART);
    usart_baudrate_set(USART, 19200U);
    usart_transmit_config(USART, USART_TRANSMIT_ENABLE);
    usart_receive_config(USART, USART_RECEIVE_ENABLE);
    usart_enable(USART);

    /* 使能接收中断，防止轮询模式下字节丢失 (19200bps ≈ 0.52ms/byte) */
    usart_interrupt_enable(USART, USART_INT_RBNE);
    nvic_irq_enable(USART1_IRQn, 3, 3);
}

// 通用时间解析函数

uint8_t parse_datetime(uint8_t *buf, uint16_t *yy, uint8_t *mm, uint8_t *dd,
                       uint8_t *hh, uint8_t *min, uint8_t *ss)
{
    uint32_t nums[6] = {0};
    uint8_t  idx = 0;
    uint8_t  in_num = 0;
    uint8_t  *p = buf;

    while (*p && idx < 6) {
        if (*p >= '0' && *p <= '9') {
            nums[idx] = nums[idx] * 10 + (*p - '0');
            in_num = 1;
        } else {
            if (in_num) {
                idx++;
                in_num = 0;
            }
        }
        p++;
    }
    if (in_num) idx++;

    if (idx < 6) return 1;

    *yy  = (uint16_t)nums[0];
    *mm  = (uint8_t)nums[1];
    *dd  = (uint8_t)nums[2];
    *hh  = (uint8_t)nums[3];
    *min = (uint8_t)nums[4];
    *ss  = (uint8_t)nums[5];
    return 0;
}
