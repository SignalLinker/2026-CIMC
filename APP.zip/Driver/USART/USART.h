// USART1 RS485通信头文件 — PD5(TX)/PD6(RX), PE8(DE)
#ifndef __USART_H__
#define __USART_H__

// 头文件

#include "HeaderFiles.h"

// 宏定义

/* USART1 on PD5/PD6, RS485 DE on PE8 */
#define USART_PORT          GPIOD
#define USART               USART1
#define USART_TX_Pin        GPIO_PIN_5
#define USART_RX_Pin        GPIO_PIN_6
#define USART_RCU           RCU_USART1
#define USART_PIN_RCU       RCU_GPIOD

/* RS485 方向控制 */
#define RS485_DE_PORT       GPIOE
#define RS485_DE_PIN        GPIO_PIN_8
#define RS485_DE_RCU        RCU_GPIOE
#define RS485_TX_MODE()     gpio_bit_set(RS485_DE_PORT, RS485_DE_PIN)
#define RS485_RX_MODE()     gpio_bit_reset(RS485_DE_PORT, RS485_DE_PIN)

/* 接收缓冲区 */
#define USART_RECV_BUF_SIZE 1024   /* ASCII-hex 帧最大 520 字节 */

// 全局变量

extern uint8_t  recv_real_buf[USART_RECV_BUF_SIZE];
extern volatile uint16_t recv_real_len;

// 函数声明

void usart_init(void);
void usart_recv_buf(void);
void usart_send_bytes(uint8_t *buf, uint16_t len);

/* 通用时间解析：从字符串中提取6个连续数字（跳过任意分隔符） */
uint8_t parse_datetime(uint8_t *buf, uint16_t *yy, uint8_t *mm, uint8_t *dd,
                       uint8_t *hh, uint8_t *min, uint8_t *ss);

#endif
