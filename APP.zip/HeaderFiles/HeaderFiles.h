// 全局头文件汇总

#ifndef __HEADERFILES_H
#define __HEADERFILES_H

#include "gd32f4xx.h"
#include "gd32f4xx_libopt.h"
#include "systick.h"
#include <stdio.h>
#include <stdint.h>
#include "string.h"
#include "Function.h"     // 执行函数
#include "LED.h"           // LED
#include "key.h"           // 按键
#include "USART.h"         // 串口
#include "RTC.h"           // RTC
#include "SPI_FLASH.h"     // SPI Flash
#include "dma.h"
#include "OLED.h"          // OLED
#include "dma.h"
#include "flash_app.h"      // Flash应用层
#include "OLED_Display.h"
#include "ADC.h"
#include "LOWPOWER.h"     // 低功耗
#include "timer.h"          // 定时器
#include "DAC.h"            // DAC
#include "gd30ad3344.h"     // GD30AD3344 外部ADC (PT100)
#include "protocol.h"      // 2026 ASCII-hex 协议帧
#include "handler.h"        // 2026 命令处理器
#include "fmc_iap.h"       // 内部Flash IAP驱动

#endif

