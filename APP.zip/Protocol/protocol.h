// ASCII-hex 协议帧 — 帧头 A5B6 + CRC-16-Modbus

#ifndef __PROTOCOL_H
#define __PROTOCOL_H

#include <stdint.h>

#define FRM_HDR_H     0xA5
#define FRM_HDR_L     0xB6
#define FRM_TAIL_H    0xB6
#define FRM_TAIL_L    0xA5

// 帧类型

#define FT_CMD      0x01
#define FT_RPLY     0x02
#define FT_HART     0x05
#define FT_ERR      0xFF

// 命令字 (big-endian)
// 系统管理 0x01xx
#define CMD_REBOOT             0x0101
#define CMD_Q_VER              0x0104
#define CMD_SET_TIME           0x0105
#define CMD_Q_TIME             0x0106
#define CMD_SET_DID            0x01A1
#define CMD_Q_DID              0x0111
#define CMD_SET_BAUD           0x01A2
#define CMD_Q_BAUD             0x0112

// 数据采集 0x02xx
#define CMD_QUERY_CH0          0x0201
#define CMD_QUERY_CH1          0x0202
#define CMD_QUERY_CH2          0x0221
#define CMD_SET_RATIO_CH0      0x0241
#define CMD_SET_RATIO_CH1      0x0242
#define CMD_SET_IVAL           0x0261

// 控制类 0x03xx
#define CMD_SET_DAC            0x0301
#define CMD_RPT_ON             0x0302
#define CMD_RPT_OFF            0x0303
#define CMD_SLEEP              0x03AA

// 参数配置 0x04xx
#define CMD_RD_THLD            0x0400
#define CMD_THLD_CH0           0x0401
#define CMD_THLD_CH1           0x0402
#define CMD_THLD_Q0            0x0411
#define CMD_THLD_Q1            0x0412

// 系统升级 0x05xx
#define CMD_OTA_REQ            0x0501
#define CMD_OTA_RDY            0x0502
#define CMD_OTA_GO             0x0503

// 告警 0x06xx
#define CMD_SET_ALARM_MODE     0x0601
#define CMD_QUERY_ALARM        0x0602
#define CMD_CLEAR_ALARM        0x0603

// 错误码

#define ERR_OK         0x00
#define ERR_CRC        0x01
#define ERR_LEN        0x02
#define ERR_CMD        0x03

// 帧解析返回值
#define PARSE_ERR_LEN  6     /* 长度不匹配 */

// 特殊 ID

#define DEVID_BC       0xFFFF
#define DEVID_DFL      0x0001

// 波特率编码

#define BAUD_4800      0x01
#define BAUD_9600      0x02
#define BAUD_192       0x13
#define BAUD_384       0x0F
#define BAUD_115       0x05

// 上报间隔编码

#define IVAL_1S        0x01
#define IVAL_2S        0x02
#define IVAL_5S        0x05
#define IVAL_10S       0x0A

// 告警模式

#define ALM_OFF        0x00
#define ALM_CH0        0x01
#define ALM_CH1        0x02

// 帧大小限制

#define FRM_BIN_MIN    11      /* 最小二进制帧 (不含Content) */
#define FRM_DATA_MAX   200     /* Content 最大长度 */
#define FRM_BIN_MAX    (FRM_BIN_MIN + FRM_DATA_MAX)
#define FRM_ASC_MAX    520     /* ASCII-hex 编码后最大字节数 */

// 帧结构体
#pragma pack(1)
typedef struct {
    uint16_t devid;         /* 设备ID */
    uint8_t  type;          /* 帧类型 */
    uint16_t cmd;           /* 命令字 */
    uint8_t  len;           /* Content 长度 */
    uint8_t  ver;           /* 固件版本 */
    uint8_t  content[FRM_DATA_MAX]; /* 数据内容 */
} protocol_frame_t;
#pragma pack()

// CRC16 计算 (Modbus 多项式 0x8005, 初始值 0xFFFF)
uint16_t crc16_calc(uint8_t *buf, uint16_t len);

// ASCII-hex 编解码
uint8_t  hex_to_byte(uint8_t c);
uint8_t  byte_to_hex_high(uint8_t b);
uint8_t  byte_to_hex_low(uint8_t b);
uint16_t hex_decode(uint8_t *asc, uint16_t asc_len, uint8_t *bin, uint16_t bin_max);
void     hex_encode(uint8_t *bin, uint16_t bin_len, uint8_t *asc);

// 帧解析: 从 ASCII-hex 接收缓冲区解析帧
// 返回: 0=成功, 1=未找到帧头, 2=数据不完整, 3=CRC错误, 4=帧尾错误, 5=格式错误
uint8_t protocol_frame_parse(uint8_t *asc_buf, uint16_t asc_len,
                             protocol_frame_t *frame, uint16_t *consumed);

// 帧打包: 构建 ASCII-hex 输出帧到缓冲区, 返回 ASCII 帧长度
uint16_t protocol_frame_build(uint8_t *asc_buf, uint16_t devid, uint8_t type,
                              uint16_t cmd, uint8_t ver, uint8_t *content, uint8_t len);

// 设备状态管理
extern uint16_t g_device_id;
extern uint8_t  g_baudrate_code;
extern uint8_t  g_fw_version;

// 应答帧字段缓存
extern uint16_t g_reply_devid;
extern uint8_t  g_reply_ver;

// 发送辅助函数
void protocol_send_reply(uint16_t cmd, uint8_t *content, uint8_t len);
void protocol_send_error(uint8_t err_code);
void protocol_send_error_reply(uint16_t devid);
void protocol_send_ascii_string(uint8_t *str, uint8_t len);

#endif

