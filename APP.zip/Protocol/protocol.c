﻿// protocol.c — ASCII-hex 协议帧编解码 + CRC-16-Modbus

// 头文件
#include "protocol.h"
#include "usart.h"

// 全局变量

uint16_t g_device_id    = DEVID_DFL;
uint8_t  g_baudrate_code = BAUD_192;
uint8_t  g_fw_version   = 0x02;  

//	应答帧字段缓存: 从下发帧回显 DevID/Ver
uint16_t g_reply_devid = DEVID_DFL;
uint8_t  g_reply_ver   = 0x02;

// CRC16 查表 (Modbus 多项式 0x8005)

static const uint16_t crc16_table[256] = {
    0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,
    0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,
    0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40,
    0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
    0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,
    0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,
    0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641,
    0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,
    0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240,
    0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
    0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41,
    0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,
    0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
    0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,
    0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,
    0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,
    0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240,
    0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,
    0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41,
    0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
    0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41,
    0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
    0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640,
    0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,
    0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,
    0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
    0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40,
    0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,
    0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40,
    0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
    0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,
    0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040
};

// 函数定义

// Modbus CRC16 计算 (多项式 0x8005, 初始值 0xFFFF)

uint16_t crc16_calc(uint8_t *buf, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    uint16_t i;

    while (len--) {
        i = (crc ^ *buf++) & 0xFF;
        crc = (crc >> 8) ^ crc16_table[i];
    }
    return crc;
}

// 单个 hex 字符转半字节值, 无效返回 0xFF

uint8_t hex_to_byte(uint8_t c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return 0xFF;
}

// 字节转 hex 字符 (高/低半字节)

uint8_t byte_to_hex_high(uint8_t b)
{
    uint8_t n = (b >> 4) & 0x0F;
    return (n < 10) ? ('0' + n) : ('A' + n - 10);
}

uint8_t byte_to_hex_low(uint8_t b)
{
    uint8_t n = b & 0x0F;
    return (n < 10) ? ('0' + n) : ('A' + n - 10);
}

// ASCII-hex 字符串解码为二进制字节数组, 返回解码字节数 (0=失败)

uint16_t hex_decode(uint8_t *asc, uint16_t asc_len, uint8_t *bin, uint16_t bin_max)
{
    uint16_t i;
    uint8_t  h, l;

    if (asc_len & 1) return 0;
    if (asc_len / 2 > bin_max) return 0;

    i = 0;
    while (i < asc_len / 2) {
        h = hex_to_byte(asc[i * 2]);
        l = hex_to_byte(asc[i * 2 + 1]);
        if (h > 0x0F || l > 0x0F) return 0;
        bin[i] = (h << 4) | l;
        i++;
    }
    return asc_len / 2;
}

// 二进制字节数组编码为 ASCII-hex 字符串

void hex_encode(uint8_t *bin, uint16_t bin_len, uint8_t *asc)
{
    uint16_t i = 0;
    while (i < bin_len) {
        asc[i * 2]     = byte_to_hex_high(bin[i]);
        asc[i * 2 + 1] = byte_to_hex_low(bin[i]);
        i++;
    }
}

// 从 ASCII-hex 缓冲区解析协议帧, 返回: 0=成功, 1=无帧头, 2=不完整, 3=CRC错, 4=帧尾错, 5=格式错

uint8_t protocol_frame_parse(uint8_t *asc_buf, uint16_t asc_len,
                             protocol_frame_t *frame, uint16_t *consumed)
{
    uint16_t pos, bin_len, asc_needed, calc_crc, recv_crc;
    uint8_t  bin_hdr[FRM_BIN_MIN], bin_full[FRM_BIN_MAX], content_len;

    *consumed = 0;

    pos = 0;
    while (pos + 4 <= asc_len) {
        if (asc_buf[pos] == 'A' && asc_buf[pos + 1] == '5' &&
            asc_buf[pos + 2] == 'B' && asc_buf[pos + 3] == '6') break;
        pos++;
    }

    if (pos + 4 > asc_len) {
        //没有找到帧头
        *consumed = pos;  //跳过无效数据 
        return 1;
    }

    //至少需要解码最小帧 (11字节 = 22 ASCII字符)
    if (asc_len - pos < FRM_BIN_MIN * 2)
		{
        return 2;  //数据不完整，等待更多数据
    }

    //解码最小帧头部，获取 Content 长度
    if (hex_decode(&asc_buf[pos], FRM_BIN_MIN * 2, bin_hdr, FRM_BIN_MIN) == 0) {
        *consumed = pos + 4;  
        return 5;
    }

    
    if (bin_hdr[0] != FRM_HDR_H || bin_hdr[1] != FRM_HDR_L) {
        *consumed = pos + 4;
        return 1;
    }

    content_len = bin_hdr[7];  

    if (content_len > FRM_DATA_MAX) {
        *consumed = pos + 4;
        return 5;
    }

    
    bin_len = FRM_BIN_MIN + content_len + 2;
    asc_needed = bin_len * 2;

    if (asc_len - pos < asc_needed) {
        
        uint16_t avail_asc = asc_len - pos;
        if (avail_asc >= 4 &&
            asc_buf[pos + avail_asc - 4] == 'B' &&
            asc_buf[pos + avail_asc - 3] == '6' &&
            asc_buf[pos + avail_asc - 2] == 'A' &&
            asc_buf[pos + avail_asc - 1] == '5') {
            *consumed = pos + avail_asc;
            return PARSE_ERR_LEN;
        }
        return 2;  
    }

    //码完整帧
    if (hex_decode(&asc_buf[pos], asc_needed, bin_full, FRM_BIN_MAX) == 0) {
        *consumed = pos + 4;
        return 5;
    }

    //提前提取 DevID/Type, 用于 CRC/长度错误时的应答帧
    frame->devid = ((uint16_t)bin_full[2] << 8) | bin_full[3];
    frame->type  = bin_full[4];
    frame->cmd   = ((uint16_t)bin_full[5] << 8) | bin_full[6];
    frame->len   = bin_full[7];
    frame->ver   = bin_full[8];

    //验证帧尾
    if (bin_full[bin_len - 2] != FRM_TAIL_H ||
        bin_full[bin_len - 1] != FRM_TAIL_L) {
        *consumed = pos + asc_needed;
        return 4;
    }

    //CRC 校验 (从 Header 到 Content 末尾 = 字节偏移0到8+content_len)
    calc_crc = crc16_calc(&bin_full[0], 9 + content_len);
    recv_crc = ((uint16_t)bin_full[9 + content_len] << 8) |
                (uint16_t)bin_full[10 + content_len];

    if (calc_crc != recv_crc) {
        *consumed = pos + asc_needed;
        return 3;
    }

    
    if (content_len > 0) {
        memcpy(frame->content, &bin_full[9], content_len);
    }

    *consumed = pos + asc_needed;
    return 0;
}

// 构建 ASCII-hex 协议帧到发送缓冲区, 返回 ASCII 帧长度

uint16_t protocol_frame_build(uint8_t *asc_buf, uint16_t devid, uint8_t type,
                              uint16_t cmd, uint8_t ver, uint8_t *content, uint8_t len)
{
    uint8_t  bin[FRM_BIN_MAX], crc_offset;
    uint16_t bin_len, crc;

    
    bin[0] = FRM_HDR_H;
    bin[1] = FRM_HDR_L;
    bin[2] = (uint8_t)(devid >> 8);
    bin[3] = (uint8_t)(devid & 0xFF);
    bin[4] = type;
    bin[5] = (uint8_t)(cmd >> 8);
    bin[6] = (uint8_t)(cmd & 0xFF);
    bin[7] = len;
    bin[8] = ver;

    if (len > 0 && content != NULL) {
        memcpy(&bin[9], content, len);
    }

    //CRC 覆盖 Header(2) + DevID(2) + Type(1) + Cmd(2) + Len(1) + Ver(1) + Content(N) = 9+N 字节
    crc = crc16_calc(&bin[0], 9 + len);
    crc_offset = 9 + len;
    bin[crc_offset]     = (uint8_t)(crc >> 8);    
    bin[crc_offset + 1] = (uint8_t)(crc & 0xFF);

    bin_len = crc_offset + 2;
    bin[bin_len]     = FRM_TAIL_H;
    bin[bin_len + 1] = FRM_TAIL_L;
    bin_len += 2;

    
    hex_encode(bin, bin_len, asc_buf);
    return bin_len * 2;
}

// 通过 USART DMA 发送数据

static void protocol_send_bin(uint8_t *buf, uint16_t len)
{
    usart_send_bytes(buf, len);
}

// 发送应答帧 (Type=REPLY)

void protocol_send_reply(uint16_t cmd, uint8_t *content, uint8_t len)
{
    uint8_t asc_buf[FRM_ASC_MAX];
    uint16_t asc_len;

    asc_len = protocol_frame_build(asc_buf, g_reply_devid, FT_RPLY,
                                   cmd, g_reply_ver, content, len);
    protocol_send_bin(asc_buf, asc_len);
}

// 发送错误应答帧 (Type=ERROR, Cmd=0xEEEE)

void protocol_send_error(uint8_t err_code)
{
    uint8_t asc_buf[FRM_ASC_MAX];
    uint16_t asc_len;

  //	错误应答帧: A5B6 <devid> FF EEEE 00 <ver> [CRC] B6A5
    asc_len = protocol_frame_build(asc_buf, g_reply_devid, FT_ERR,
                                   0xEEEE, g_reply_ver, NULL, 0);
    protocol_send_bin(asc_buf, asc_len);
}



void protocol_send_error_reply(uint16_t devid)
{
    uint8_t asc_buf[FRM_ASC_MAX];
    uint16_t asc_len;

    asc_len = protocol_frame_build(asc_buf, devid, FT_ERR,
                                   0xEEEE, g_fw_version, NULL, 0);
    protocol_send_bin(asc_buf, asc_len);
}


void protocol_send_ascii_string(uint8_t *str, uint8_t len)
{
    protocol_send_bin(str, len);
}

/****************************End*****************************/
