// 固件信息结构 — 存储在参数区

#ifndef __FIRMWARE_INFO_H
#define __FIRMWARE_INFO_H

#include "gd32f4xx.h"

// Flash 内存布局
#define BOOTLOADER_ADDR       0x08000000
#define BOOTLOADER_SIZE       0x10000      /* 64KB */
#define PARAM_AREA_ADDR       0x08010000
#define PARAM_AREA_SIZE       0x1000       /* 4KB */
#define APP_ADDR              0x08011000
#define APP_SIZE              0x20000      /* 128KB */
#define APP_BACKUP_ADDR       0x08031000
#define APP_BACKUP_SIZE       0x20000      /* 128KB */
#define DOWNLOAD_BUFFER_ADDR  0x08051000
#define DOWNLOAD_BUFFER_SIZE  0x20000      /* 128KB */

#define FIRMWARE_MAGIC  0x43494D43  /* "CIMC" */

#pragma pack(1)
typedef struct {
    uint32_t magic;      /* 魔数 0x43494D43 */
    uint32_t version;    /* 固件版本 (如 0x00010000 = v1.0.0) */
    uint32_t size;       /* APP固件大小（字节） */
    uint32_t crc32;      /* APP区域硬件CRC32 */
} firmware_info_t;
#pragma pack()

#endif

