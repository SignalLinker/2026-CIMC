// 主循环函数声明 + 全局状态变量

#ifndef __FUNCTION_H
#define __FUNCTION_H

#include "HeaderFiles.h"
#include <stdint.h>

#define MODE_IDLE     0
#define MODE_SAMP     1
#define MODE_STOP     2
#define MODE_HIDE     3
#define MODE_ALARM    4

// 全局状态变量

extern volatile int     work_mode;
extern uint32_t         period;
extern float            ratio;
extern float            limit;
extern float            temp;
extern uint16_t         adcx;
extern uint16_t         start_ok;
extern uint16_t         stop_ok;
extern uint16_t         adjust_flag;
extern uint8_t          prev_work_mode;
extern float            g_ratio;
extern uint8_t          g_dac_follow_enable;
extern uint8_t          g_sleep_enable;

// 函数声明
void System_Init(void);
void UsrFunction(void);

// 初始化回调
void Func_Init_Handler(void);
void Func_Idle_Handler(void);
void Func_Task1_Handler(void);
void Func_Task2_Handler(void);
void Func_UART_Parse_Handler(void);

// ADC 采集
void adc_gather(void);
void sampling_toggle(void);

// 配置读写
void flash_config_save(void);
void flash_config_read(void);

// OLED 显示
void display_sampling_info(void);
void display_idle_info(void);

// 系统自检
void system_self_test(void);

// 采样数据日志
void flash_sample_data_save(uint8_t *record, uint16_t len);
void flash_sample_data_print(void);

#endif

