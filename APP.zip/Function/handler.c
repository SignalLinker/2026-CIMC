﻿// 命令处理器 — 查表分发 30+ 命令字

#include "handler.h"
#include "fmc_iap.h"
#include "usart.h"
#include <string.h>
#include <stdio.h>

extern volatile uint32_t tick_count;
extern volatile uint32_t status_timer;
extern volatile uint8_t  send_sampling_flag;
extern volatile int       work_mode;
extern uint32_t           period;
extern float              ratio;
extern float              limit;
extern float              temp;
extern uint16_t           adcx;
extern uint8_t            g_dac_follow_enable;
extern volatile uint8_t   rtc_alarm_wakeup;

// Flash 参数区定义

#define FLASH_PARAM_BASE      0x08010000UL
#define FLASH_PARAM_PAGE_SIZE 0x1000UL     


typedef struct {
    uint32_t magic;             
    float    ch0_ratio;
    float    ch1_ratio;
    float    ch0_threshold;
    float    ch1_threshold;
    uint16_t device_id;
    uint8_t  baud_code;
    uint8_t  alarm_mode;
    uint8_t  report_interval;
    uint8_t  reserved[3];
    uint32_t crc32;
} flash_params_t;

#define FLASH_PARAMS_MAGIC  0x43494D43UL


#define ALARM_MAX_ENTRIES   10

typedef struct {
    uint32_t magic;             
    uint32_t timestamp;         
    uint8_t  channel;
    uint8_t  reserved[3];
    float    threshold;
    float    actual;
} alarm_record_t;

#define ALARM_MAGIC  0x414C524DUL

/************************* 全局变量 *************************/

system_state_t g_sys_state              = SYS_STATE_IDLE;
uint8_t        g_auto_report_active     = 0;
uint32_t       g_auto_report_interval_ms = 1000;
uint32_t       g_auto_report_last_ms    = 0;
uint8_t        g_alarm_mode             = 0x02;  

float    g_ch0_ratio       = 1.0f;
float    g_ch1_ratio       = 1.0f;
float    g_ch0_threshold   = 100.0f;
float    g_ch1_threshold   = 100.0f;
uint8_t  g_report_interval_code = 0x01;  

/************************* 静态变量 *************************/

static alarm_record_t bj[ALARM_MAX_ENTRIES];
static uint8_t        bj_n = 0;
static uint8_t        bj_p = 0;
static uint8_t        bj_ok[2] = {1, 1};  

/************************* 内部辅助函数 *************************/


static uint32_t crc32_calc(const uint8_t *data, uint32_t len)
{
    uint32_t crc = 0xFFFFFFFFUL;
    uint32_t bit;

    while (len--) {
        crc ^= *data++;
        bit = 8;
        while (bit--) {
            crc = (crc & 1) ? ((crc >> 1) ^ 0xEDB88320UL) : (crc >> 1);
        }
    }
    return crc ^ 0xFFFFFFFFUL;
}


static uint8_t bcd2dec(uint8_t bcd)
{
    return ((bcd >> 4) * 10) + (bcd & 0x0F);
}


static uint8_t dec2bcd(uint8_t dec)
{
    return ((dec / 10) << 4) | (dec % 10);
}


static uint32_t rtc_to_utc(rtc_parameter_struct *rtc)
{
    uint8_t  yy = bcd2dec(rtc->year);
    uint8_t  mm = bcd2dec(rtc->month);
    uint8_t  dd = bcd2dec(rtc->date);
    uint8_t  hh = bcd2dec(rtc->hour);
    uint8_t  min = bcd2dec(rtc->minute);
    uint8_t  ss = bcd2dec(rtc->second);

    uint16_t year = 2000 + yy;
    uint32_t dsum = 0;
    uint16_t y;
    static const uint8_t month_days[] = { 31,28,31,30,31,30,31,31,30,31,30,31 };


    y = 2000;
    while (y < year) {
        dsum += ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) ? 366 : 365;
        y++;
    }

    uint8_t isleap = ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) ? 1 : 0;
    uint8_t m = 1;
    while (m < mm) {
        dsum += month_days[m - 1];
        if (m == 2 && isleap) dsum++;
        m++;
    }
    dsum += dd - 1;

    return (uint32_t)dsum * 86400UL + (uint32_t)hh * 3600UL +
           (uint32_t)min * 60UL + ss;
}


static void utc_to_rtc(uint32_t utc, rtc_parameter_struct *rtc)
{
    uint32_t rem      = utc;
    uint32_t sec_day  = rem % 86400UL;
    uint32_t dleft    = rem / 86400UL;

    rtc->second = dec2bcd((uint8_t)(sec_day % 60));
    rtc->minute = dec2bcd((uint8_t)((sec_day / 60) % 60));
    rtc->hour   = dec2bcd((uint8_t)(sec_day / 3600));

    uint16_t year = 2000;
    uint16_t yr_days;
    while (1) {
        yr_days = ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) ? 366 : 365;
        if (dleft < yr_days) break;
        dleft -= yr_days;
        year++;
    }

    rtc->year  = dec2bcd((uint8_t)(year - 2000));
    uint8_t isleap = ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) ? 1 : 0;
    static const uint8_t mdays[] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
    uint8_t month = 0;
    while (++month <= 12) {
        uint8_t md = mdays[month - 1];
        if (month == 2 && isleap) md = 29;
        if (dleft < md) break;
        dleft -= md;
    }
    rtc->month = dec2bcd(month);
    rtc->date  = dec2bcd((uint8_t)(dleft + 1));
    rtc->day_of_week = 0;
}


uint32_t rtc_get_timestamp(void)
{
    rtc_parameter_struct rtc;
    rtc_current_time_get(&rtc);
    return rtc_to_utc(&rtc);
}

/************************* 告警管理 *************************/

void handler_alarm_check(uint8_t ch, float val, float thld)
{
    if (g_alarm_mode == 0x00) return;

    if (val <= thld) {
        if (ch < 2) bj_ok[ch] = 1;
        return;
    }

    if (ch >= 2 || bj_ok[ch]) {
        if (ch < 2) bj_ok[ch] = 0;

        bj[bj_p].magic     = ALARM_MAGIC;
        bj[bj_p].timestamp = rtc_get_timestamp();
        bj[bj_p].channel   = ch;
        bj[bj_p].threshold = thld;
        bj[bj_p].actual    = val;

        bj_p = (bj_p + 1) % ALARM_MAX_ENTRIES;
        if (bj_n < ALARM_MAX_ENTRIES) bj_n++;

        if (g_alarm_mode == 0x01) {
            char buf[64];
            rtc_parameter_struct rtc;
            rtc_current_time_get(&rtc);
            uint8_t yy = bcd2dec(rtc.year);
            uint8_t mm = bcd2dec(rtc.month);
            uint8_t dd = bcd2dec(rtc.date);
            uint8_t hh = bcd2dec(rtc.hour);
            uint8_t min = bcd2dec(rtc.minute);
            uint8_t ss = bcd2dec(rtc.second);

            int len = snprintf(buf, sizeof(buf),
                               "20%02d-%02d-%02d %02d:%02d:%02d | CH%d | %.2f | %.2f\r\n",
                               2000 + yy, mm, dd, hh, min, ss,
                               ch, thld, val);
            protocol_send_ascii_string((uint8_t *)buf, (uint8_t)len);
        }
    }
}

uint8_t handler_alarm_query(uint8_t *out_buf, uint16_t *out_len)
{
    uint8_t  count = bj_n;
    uint16_t offset = 0;
    int8_t   i;

    out_buf[offset++] = count;

    
    i = (int8_t)(bj_p) - 1;
    while (i >= 0 && count > 0) {
        if (bj[i].magic == ALARM_MAGIC) {
            memcpy(&out_buf[offset], &bj[i].timestamp, 4);  offset += 4;
            out_buf[offset++] = bj[i].channel;
            memcpy(&out_buf[offset], &bj[i].threshold, 4);  offset += 4;
            memcpy(&out_buf[offset], &bj[i].actual, 4);     offset += 4;
            count--;
        }
        i--;
    }
    i = ALARM_MAX_ENTRIES - 1;
    while (i >= (int8_t)bj_p && count > 0) {
        if (bj[i].magic == ALARM_MAGIC) {
            memcpy(&out_buf[offset], &bj[i].timestamp, 4);  offset += 4;
            out_buf[offset++] = bj[i].channel;
            memcpy(&out_buf[offset], &bj[i].threshold, 4);  offset += 4;
            memcpy(&out_buf[offset], &bj[i].actual, 4);     offset += 4;
            count--;
        }
        i--;
    }

    *out_len = offset;
    return 0;
}

void handler_alarm_clear(void)
{
    bj_n     = 0;
    bj_p = 0;
    memset(bj, 0, sizeof(bj));
    bj_ok[0] = 0;  
    bj_ok[1] = 0;
}

/************************* 参数持久化 *************************/

static flash_params_t cfg;

static void interval_code_apply(uint8_t code);

void handler_params_load(void)
{
    uint32_t *psrc = (uint32_t *)FLASH_PARAM_BASE;
    uint32_t *pdst = (uint32_t *)&cfg;
    uint32_t i = sizeof(flash_params_t) / 4;
    while (i--) {
        pdst[i] = psrc[i];
    }

    if (cfg.magic == FLASH_PARAMS_MAGIC) {
        uint32_t crc_chk = crc32_calc((uint8_t *)&cfg, sizeof(flash_params_t) - 4);
        if (crc_chk == cfg.crc32) {
            g_ch0_ratio       = cfg.ch0_ratio;
            g_ch1_ratio       = cfg.ch1_ratio;
            g_ch0_threshold   = cfg.ch0_threshold;
            g_ch1_threshold   = cfg.ch1_threshold;
            g_device_id       = cfg.device_id;
            g_baudrate_code   = cfg.baud_code;
            g_alarm_mode      = cfg.alarm_mode;
            g_report_interval_code = cfg.report_interval;
            interval_code_apply(g_report_interval_code);

            
            ratio  = g_ch0_ratio;
            limit  = g_ch0_threshold;
            return;
        }
    }

    
    cfg.magic           = FLASH_PARAMS_MAGIC;
    cfg.ch0_ratio       = 1.0f;
    cfg.ch1_ratio       = 1.0f;
    cfg.ch0_threshold   = 100.0f;
    cfg.ch1_threshold   = 100.0f;
    cfg.device_id       = DEVID_DFL;
    cfg.baud_code       = BAUD_192;
    cfg.alarm_mode      = 0x02;
    cfg.report_interval = 0x01;
}

void handler_params_save(void)
{
    cfg.magic           = FLASH_PARAMS_MAGIC;
    cfg.ch0_ratio       = g_ch0_ratio;
    cfg.ch1_ratio       = g_ch1_ratio;
    cfg.ch0_threshold   = g_ch0_threshold;
    cfg.ch1_threshold   = g_ch1_threshold;
    cfg.device_id       = g_device_id;
    cfg.baud_code       = g_baudrate_code;
    cfg.alarm_mode      = g_alarm_mode;
    cfg.report_interval = g_report_interval_code;
    cfg.crc32 = crc32_calc((uint8_t *)&cfg, sizeof(flash_params_t) - 4);

    fmc_iap_erase(FLASH_PARAM_BASE, FLASH_PARAM_PAGE_SIZE);
    fmc_iap_write(FLASH_PARAM_BASE, (uint8_t *)&cfg, sizeof(flash_params_t));
}

/************************* 各命令字处理函数 *************************/

typedef void (*cmd_handler_fn)(protocol_frame_t *frame);


static void h_reboot(protocol_frame_t *frame)
{
    uint8_t ok = 0xFF;
    protocol_send_reply(CMD_REBOOT, &ok, 1);

    
    while (!usart_flag_get(USART1, USART_FLAG_TC));
    rtc_flag_clear(RTC_FLAG_ALRM0);
    rtc_alarm_disable(RTC_ALARM0);
    rtc_interrupt_disable(RTC_INT_ALARM0);
    exti_interrupt_flag_clear(EXTI_17);

    fmc_iap_software_reset();
}


static void h_query_version(protocol_frame_t *frame)
{
    uint8_t ver[4] = { 0x02, 0x00, 0x01, 0x00 };  
    protocol_send_reply(CMD_Q_VER, ver, 4);
}


static void h_set_time(protocol_frame_t *frame)
{
    if (frame->len < 4) {
        protocol_send_error(ERR_LEN);
        return;
    }

    
    uint32_t utc;
    utc = ((uint32_t)frame->content[0] << 24) |
          ((uint32_t)frame->content[1] << 16) |
          ((uint32_t)frame->content[2] << 8) |
           (uint32_t)frame->content[3];
    utc -= 946684800UL;  

    rtc_parameter_struct rtc;
    utc_to_rtc(utc, &rtc);
    rtc_set_time(rtc.year, rtc.month, rtc.date, rtc.hour, rtc.minute, rtc.second);

    { uint8_t ok = 0xFF; protocol_send_reply(CMD_SET_TIME, &ok, 1); }
}


static void h_query_time(protocol_frame_t *frame)
{
    uint32_t utc = rtc_get_timestamp();
    utc += 946684800UL;  
    uint8_t buf[4];
    buf[0] = (uint8_t)(utc >> 24);
    buf[1] = (uint8_t)(utc >> 16);
    buf[2] = (uint8_t)(utc >> 8);
    buf[3] = (uint8_t)(utc);
    protocol_send_reply(CMD_Q_TIME, buf, 4);
}


static void h_set_device_id(protocol_frame_t *frame)
{
    if (frame->len < 2) {
        protocol_send_error(ERR_LEN);
        return;
    }

    uint16_t new_id = ((uint16_t)frame->content[0] << 8) | frame->content[1];

    
    if (new_id == 0x0000 || new_id == 0xFFFF) {
        protocol_send_error(ERR_LEN);
        return;
    }

    g_device_id   = new_id;
    g_reply_devid = new_id;   
    handler_params_save();

    { uint8_t ok = 0xFF; protocol_send_reply(CMD_SET_DID, &ok, 1); }
}


static void h_query_device_id(protocol_frame_t *frame)
{
    uint8_t buf[2];
    buf[0] = (uint8_t)(g_device_id >> 8);
    buf[1] = (uint8_t)(g_device_id & 0xFF);
    protocol_send_reply(CMD_Q_DID, buf, 2);
}


static uint32_t baudrate_code_to_value(uint8_t code)
{
    switch (code) {
        case 0x14:                 return 115200;
        case BAUD_115: return 115200;
        case BAUD_384:  return 38400;
        case BAUD_192:  return 19200;
        case BAUD_4800:   return 4800;
        case BAUD_9600:   return 9600;
        default:                   return 19200;
    }
}

static void h_set_baudrate(protocol_frame_t *frame)
{
    uint8_t code;

    if (frame->len < 1) {
        protocol_send_error(ERR_LEN);
        return;
    }

    code = frame->content[0];

    g_baudrate_code = code;
    handler_params_save();

    { uint8_t ok = 0xFF; protocol_send_reply(CMD_SET_BAUD, &ok, 1); }

    while (!usart_flag_get(USART1, USART_FLAG_TC));
    rtc_flag_clear(RTC_FLAG_ALRM0);
    rtc_alarm_disable(RTC_ALARM0);
    rtc_interrupt_disable(RTC_INT_ALARM0);
    exti_interrupt_flag_clear(EXTI_17);

    fmc_iap_software_reset();
}


static void h_query_baudrate(protocol_frame_t *frame)
{
    uint8_t buf[1] = { g_baudrate_code };
    protocol_send_reply(CMD_Q_BAUD, buf, 1);
}


static void h_query_ch0(protocol_frame_t *frame)
{
    float val = temp;  
    uint8_t buf[4];
    uint32_t raw;
    memcpy(&raw, &val, 4);
    buf[0] = (uint8_t)(raw >> 24);  
    buf[1] = (uint8_t)(raw >> 16);
    buf[2] = (uint8_t)(raw >> 8);
    buf[3] = (uint8_t)(raw);
    protocol_send_reply(CMD_QUERY_CH0, buf, 4);
}


static void h_query_ch1(protocol_frame_t *frame)
{
    
    adc_software_trigger_enable(ADC0, ADC_INSERTED_CHANNEL);
    while (SET != adc_flag_get(ADC0, ADC_FLAG_EOIC));
    uint16_t raw = adc_inserted_data_read(ADC0, ADC_INSERTED_CHANNEL_0);
    float val = ADC_To_Voltage(raw, g_ch1_ratio);
    uint8_t buf[4];
    uint32_t r;
    memcpy(&r, &val, 4);
    buf[0] = (uint8_t)(r >> 24);
    buf[1] = (uint8_t)(r >> 16);
    buf[2] = (uint8_t)(r >> 8);
    buf[3] = (uint8_t)(r);
    protocol_send_reply(CMD_QUERY_CH1, buf, 4);
}


static void h_query_ch2(protocol_frame_t *frame)
{

    float v_adc = GD30AD3344_AD_Read(GD30AD3344_Channel_0, GD30AD3344_PGA_4V096);
    float deg_c = v_adc * 100.0f;

    uint8_t buf[4];
    uint32_t raw;
    memcpy(&raw, &deg_c, 4);
    buf[0] = (uint8_t)(raw >> 24);  
    buf[1] = (uint8_t)(raw >> 16);
    buf[2] = (uint8_t)(raw >> 8);
    buf[3] = (uint8_t)(raw);
    protocol_send_reply(CMD_QUERY_CH2, buf, 4);
}


static void h_set_ratio_ch0(protocol_frame_t *frame)
{
    if (frame->len < 4) {
        protocol_send_error(ERR_LEN);
        return;
    }

    
    uint32_t raw = ((uint32_t)frame->content[0] << 24) |
                   ((uint32_t)frame->content[1] << 16) |
                   ((uint32_t)frame->content[2] << 8)  |
                   (uint32_t)frame->content[3];
    float val;
    memcpy(&val, &raw, 4);
    g_ch0_ratio = val;
    ratio  = val;

    handler_params_save();

    
    uint8_t buf[4];
    memcpy(&raw, &val, 4);
    buf[0] = (uint8_t)(raw >> 24);
    buf[1] = (uint8_t)(raw >> 16);
    buf[2] = (uint8_t)(raw >> 8);
    buf[3] = (uint8_t)(raw);
    protocol_send_reply(CMD_SET_RATIO_CH0, buf, 4);
}


static void h_set_ratio_ch1(protocol_frame_t *frame)
{
    if (frame->len < 4) {
        protocol_send_error(ERR_LEN);
        return;
    }

    
    uint32_t raw = ((uint32_t)frame->content[0] << 24) |
                   ((uint32_t)frame->content[1] << 16) |
                   ((uint32_t)frame->content[2] << 8)  |
                   (uint32_t)frame->content[3];
    float val;
    memcpy(&val, &raw, 4);
    g_ch1_ratio = val;
    handler_params_save();

    
    uint8_t buf[4];
    memcpy(&raw, &val, 4);
    buf[0] = (uint8_t)(raw >> 24);
    buf[1] = (uint8_t)(raw >> 16);
    buf[2] = (uint8_t)(raw >> 8);
    buf[3] = (uint8_t)(raw);
    protocol_send_reply(CMD_SET_RATIO_CH1, buf, 4);
}


static void interval_code_apply(uint8_t code)
{
    switch (code) {
    case IVAL_10S: g_auto_report_interval_ms = 10000; break;
    case IVAL_2S:  g_auto_report_interval_ms = 2000;  break;
    case IVAL_5S:  g_auto_report_interval_ms = 5000;  break;
    case IVAL_1S:  g_auto_report_interval_ms = 1000;  break;
    default:                g_auto_report_interval_ms = 1000;  break;
    }
}

static void h_set_report_interval(protocol_frame_t *frame)
{
    if (frame->len < 1) {
        protocol_send_error(ERR_LEN);
        return;
    }

    g_report_interval_code = frame->content[0];
    interval_code_apply(g_report_interval_code);

    handler_params_save();

    uint8_t buf[1] = { g_report_interval_code };
    protocol_send_reply(CMD_SET_IVAL, buf, 1);
}


static void h_set_dac(protocol_frame_t *frame)
{
    if (frame->len < 2) {
        protocol_send_error(ERR_LEN);
        return;
    }

    uint16_t value = ((uint16_t)frame->content[0] << 8) | frame->content[1];
    if (value > 4095) value = 4095;

    DAC_SetValue(value);

    { uint8_t ok = 0xFF; protocol_send_reply(CMD_SET_DAC, &ok, 1); }
}


static void h_auto_report_start(protocol_frame_t *frame)
{
    uint8_t  buf[12];
    float    ch1_val;
    uint32_t utc, raw;

    g_auto_report_active    = 1;
    g_auto_report_last_ms   = tick_count;
    g_sys_state             = SYS_STATE_AUTO_SAMPLE;

    LED2_ON();

    g_reply_devid = g_device_id;
    g_reply_ver   = g_fw_version;

    
    utc = rtc_get_timestamp() + 946684800UL;
    buf[0] = (uint8_t)(utc >> 24);
    buf[1] = (uint8_t)(utc >> 16);
    buf[2] = (uint8_t)(utc >> 8);
    buf[3] = (uint8_t)(utc);

    
    memcpy(&raw, &temp, 4);
    buf[4] = (uint8_t)(raw >> 24);
    buf[5] = (uint8_t)(raw >> 16);
    buf[6] = (uint8_t)(raw >> 8);
    buf[7] = (uint8_t)(raw);

    
    {
        uint16_t ch1_raw;
        adc_software_trigger_enable(ADC0, ADC_INSERTED_CHANNEL);
        while (SET != adc_flag_get(ADC0, ADC_FLAG_EOIC));
        ch1_raw = adc_inserted_data_read(ADC0, ADC_INSERTED_CHANNEL_0);
        ch1_val = ADC_To_Voltage(ch1_raw, g_ch1_ratio);
    }
    memcpy(&raw, &ch1_val, 4);
    buf[8]  = (uint8_t)(raw >> 24);
    buf[9]  = (uint8_t)(raw >> 16);
    buf[10] = (uint8_t)(raw >> 8);
    buf[11] = (uint8_t)(raw);

    protocol_send_reply(CMD_RPT_ON, buf, 12);
}


static void h_auto_report_stop(protocol_frame_t *frame)
{
    g_auto_report_active = 0;
    g_sys_state          = SYS_STATE_IDLE;

    LED2_OFF();

    { uint8_t ok = 0xFF; protocol_send_reply(CMD_RPT_OFF, &ok, 1); }
}


static void h_sleep(protocol_frame_t *frame)
{
    { uint8_t ok = 0xFF; protocol_send_reply(CMD_SLEEP, &ok, 1); }

    
    while (!usart_flag_get(USART1, USART_FLAG_TC));

    
    RTC_SetAlarmRelative(10);

    
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
    usart_interrupt_disable(USART1, USART_INT_RBNE);

    
    LOWPOWER_EnterDeepSleep();

    
    
    usart_init();

    
    if (rtc_alarm_wakeup) {
        rtc_alarm_wakeup = 0;
        uint8_t *msg = (uint8_t *)"instrument wakeup";
        protocol_send_ascii_string(msg, 17);
    }
}


static void h_read_threshold(protocol_frame_t *frame)
{
    uint8_t buf[8];
    uint32_t raw;
    memcpy(&raw, &g_ch0_threshold, 4);
    buf[0] = (uint8_t)(raw >> 24);  
    buf[1] = (uint8_t)(raw >> 16);
    buf[2] = (uint8_t)(raw >> 8);
    buf[3] = (uint8_t)(raw);
    memcpy(&raw, &g_ch1_threshold, 4);
    buf[4] = (uint8_t)(raw >> 24);
    buf[5] = (uint8_t)(raw >> 16);
    buf[6] = (uint8_t)(raw >> 8);
    buf[7] = (uint8_t)(raw);
    protocol_send_reply(CMD_RD_THLD, buf, 8);
}


static void h_set_threshold_ch0(protocol_frame_t *frame)
{
    uint8_t buf[4];
    uint32_t raw;

    if (frame->len == 0) {
        
        memcpy(&raw, &g_ch0_threshold, 4);
        buf[0] = (uint8_t)(raw >> 24);
        buf[1] = (uint8_t)(raw >> 16);
        buf[2] = (uint8_t)(raw >> 8);
        buf[3] = (uint8_t)(raw);
        protocol_send_reply(CMD_THLD_CH0, buf, 4);
        return;
    }

    if (frame->len < 4) {
        protocol_send_error(ERR_LEN);
        return;
    }

    
    raw = ((uint32_t)frame->content[0] << 24) |
          ((uint32_t)frame->content[1] << 16) |
          ((uint32_t)frame->content[2] << 8)  |
          (uint32_t)frame->content[3];
    memcpy(&g_ch0_threshold, &raw, 4);
    limit = g_ch0_threshold;
    handler_params_save();

    
    memcpy(&raw, &g_ch0_threshold, 4);
    buf[0] = (uint8_t)(raw >> 24);
    buf[1] = (uint8_t)(raw >> 16);
    buf[2] = (uint8_t)(raw >> 8);
    buf[3] = (uint8_t)(raw);
    protocol_send_reply(CMD_THLD_CH0, buf, 4);
}


static void h_set_threshold_ch1(protocol_frame_t *frame)
{
    uint8_t buf[4];
    uint32_t raw;

    if (frame->len == 0) {
        
        memcpy(&raw, &g_ch1_threshold, 4);
        buf[0] = (uint8_t)(raw >> 24);
        buf[1] = (uint8_t)(raw >> 16);
        buf[2] = (uint8_t)(raw >> 8);
        buf[3] = (uint8_t)(raw);
        protocol_send_reply(CMD_THLD_CH1, buf, 4);
        return;
    }

    if (frame->len < 4) {
        protocol_send_error(ERR_LEN);
        return;
    }

    
    raw = ((uint32_t)frame->content[0] << 24) |
          ((uint32_t)frame->content[1] << 16) |
          ((uint32_t)frame->content[2] << 8)  |
          (uint32_t)frame->content[3];
    memcpy(&g_ch1_threshold, &raw, 4);
    handler_params_save();

    
    memcpy(&raw, &g_ch1_threshold, 4);
    buf[0] = (uint8_t)(raw >> 24);
    buf[1] = (uint8_t)(raw >> 16);
    buf[2] = (uint8_t)(raw >> 8);
    buf[3] = (uint8_t)(raw);
    protocol_send_reply(CMD_THLD_CH1, buf, 4);
}


static void h_query_threshold_ch0(protocol_frame_t *frame)
{
    if (frame->len < 4) {
        protocol_send_error(ERR_LEN);
        return;
    }

    
    uint32_t raw = ((uint32_t)frame->content[0] << 24) |
                   ((uint32_t)frame->content[1] << 16) |
                   ((uint32_t)frame->content[2] << 8)  |
                   (uint32_t)frame->content[3];
    memcpy(&g_ch0_threshold, &raw, 4);
    limit = g_ch0_threshold;
    handler_params_save();

    uint8_t ok = 0xFF;
    protocol_send_reply(CMD_THLD_Q0, &ok, 1);
}


static void h_query_threshold_ch1(protocol_frame_t *frame)
{
    if (frame->len < 4) {
        protocol_send_error(ERR_LEN);
        return;
    }

    
    uint32_t raw = ((uint32_t)frame->content[0] << 24) |
                   ((uint32_t)frame->content[1] << 16) |
                   ((uint32_t)frame->content[2] << 8)  |
                   (uint32_t)frame->content[3];
    memcpy(&g_ch1_threshold, &raw, 4);
    handler_params_save();

    uint8_t ok = 0xFF;
    protocol_send_reply(CMD_THLD_Q1, &ok, 1);
}


static void h_upgrade_request(protocol_frame_t *frame)
{
    
    uint8_t buf[8];
    uint32_t app_size = 0x20000;  
    uint32_t app_crc  = 0;

    memcpy(buf,     &app_size, 4);
    memcpy(buf + 4, &app_crc,  4);
    protocol_send_reply(CMD_OTA_REQ, buf, 8);

    
    uint32_t upgrade_flag = 0x5AA5C33C;
    fmc_iap_erase(FLASH_PARAM_BASE, FLASH_PARAM_PAGE_SIZE);
    fmc_iap_write(FLASH_PARAM_BASE, (uint8_t *)&upgrade_flag, 4);

    while (!usart_flag_get(USART1, USART_FLAG_TC));
    rtc_flag_clear(RTC_FLAG_ALRM0);
    rtc_alarm_disable(RTC_ALARM0);
    rtc_interrupt_disable(RTC_INT_ALARM0);
    exti_interrupt_flag_clear(EXTI_17);

    fmc_iap_software_reset();
}


static void h_upgrade_prepare(protocol_frame_t *frame)
{
    { uint8_t ok = 0xFF; protocol_send_reply(CMD_OTA_RDY, &ok, 1); }
}


static void h_upgrade_execute(protocol_frame_t *frame)
{
    
    uint32_t magic;
    if (frame->len < 4) {
        protocol_send_error(ERR_LEN);
        return;
    }

    memcpy(&magic, frame->content, 4);
    if (magic != 0x5AA5C33C) {
        protocol_send_error(ERR_CMD);
        return;
    }

    { uint8_t ok = 0xFF; protocol_send_reply(CMD_OTA_GO, &ok, 1); }
}


static void h_set_alarm_mode(protocol_frame_t *frame)
{
    if (frame->len < 1) {
        protocol_send_error(ERR_LEN);
        return;
    }

    g_alarm_mode = frame->content[0];
    handler_params_save();

    { uint8_t ok = 0xFF; protocol_send_reply(CMD_SET_ALARM_MODE, &ok, 1); }
}


static void h_query_alarm(protocol_frame_t *frame)
{
    uint8_t  count = bj_n;
    int8_t   i;
    char     buf[1024];
    int      offset = 0;
    uint8_t  printed = 0;

    if (count == 0) {
        uint8_t *msg = (uint8_t *)"empty\r\n";
        protocol_send_ascii_string(msg, 7);
        return;
    }

    
    i = (int8_t)(bj_p) - 1;
    while (i >= 0 && printed < 10) {
        if (bj[i].magic != ALARM_MAGIC) { i--; continue; }
        {
            rtc_parameter_struct rtc;
            utc_to_rtc(bj[i].timestamp, &rtc);
            uint8_t yy = bcd2dec(rtc.year);
            uint8_t mm = bcd2dec(rtc.month);
            uint8_t dd = bcd2dec(rtc.date);
            uint8_t hh = bcd2dec(rtc.hour);
            uint8_t min = bcd2dec(rtc.minute);
            uint8_t ss = bcd2dec(rtc.second);
            offset += snprintf(buf + offset, sizeof(buf) - offset,
                              "20%02d-%02d-%02d %02d:%02d:%02d | CH%d | %.2f | %.2f\r\n",
                              2000 + yy, mm, dd, hh, min, ss,
                              bj[i].channel,
                              bj[i].threshold,
                              bj[i].actual);
        }
        printed++;
        i--;
    }
    i = ALARM_MAX_ENTRIES - 1;
    while (i >= (int8_t)bj_p && printed < 10) {
        if (bj[i].magic != ALARM_MAGIC) { i--; continue; }
        {
            rtc_parameter_struct rtc;
            utc_to_rtc(bj[i].timestamp, &rtc);
            uint8_t yy = bcd2dec(rtc.year);
            uint8_t mm = bcd2dec(rtc.month);
            uint8_t dd = bcd2dec(rtc.date);
            uint8_t hh = bcd2dec(rtc.hour);
            uint8_t min = bcd2dec(rtc.minute);
            uint8_t ss = bcd2dec(rtc.second);
            offset += snprintf(buf + offset, sizeof(buf) - offset,
                              "20%02d-%02d-%02d %02d:%02d:%02d | CH%d | %.2f | %.2f\r\n",
                              2000 + yy, mm, dd, hh, min, ss,
                              bj[i].channel,
                              bj[i].threshold,
                              bj[i].actual);
        }
        printed++;
        i--;
    }

    protocol_send_ascii_string((uint8_t *)buf, (uint8_t)offset);
}


static void h_clear_alarm(protocol_frame_t *frame)
{
    handler_alarm_clear();
    { uint8_t ok = 0xFF; protocol_send_reply(CMD_CLEAR_ALARM, &ok, 1); }
}

/************************* 命令分发表 *************************/

typedef struct {
    uint16_t       cmd;
    cmd_handler_fn handler;
} cmd_entry_t;

static const cmd_entry_t cmd_table[] = {
    { CMD_CLEAR_ALARM,         h_clear_alarm         },
    { CMD_SET_ALARM_MODE,      h_set_alarm_mode      },
    { CMD_QUERY_ALARM,         h_query_alarm         },
    { CMD_QUERY_CH2,           h_query_ch2           },
    { CMD_QUERY_CH1,           h_query_ch1           },
    { CMD_QUERY_CH0,           h_query_ch0           },
    { CMD_RD_THLD,      h_read_threshold      },
    { CMD_THLD_Q0, h_query_threshold_ch0 },
    { CMD_THLD_CH0,   h_set_threshold_ch0   },
    { CMD_THLD_Q1, h_query_threshold_ch1 },
    { CMD_THLD_CH1,   h_set_threshold_ch1   },
    { CMD_SET_RATIO_CH0,       h_set_ratio_ch0       },
    { CMD_SET_RATIO_CH1,       h_set_ratio_ch1       },
    { CMD_SET_DAC,             h_set_dac             },
    { CMD_Q_DID,     h_query_device_id     },
    { CMD_SET_DID,       h_set_device_id       },
    { CMD_Q_VER,       h_query_version       },
    { CMD_SET_TIME,            h_set_time            },
    { CMD_Q_TIME,          h_query_time          },
    { CMD_SET_BAUD,        h_set_baudrate        },
    { CMD_Q_BAUD,      h_query_baudrate      },
    { CMD_SET_IVAL, h_set_report_interval },
    { CMD_OTA_REQ,     h_upgrade_request     },
    { CMD_OTA_RDY,     h_upgrade_prepare     },
    { CMD_OTA_GO,     h_upgrade_execute     },
    { CMD_SLEEP,               h_sleep               },
    { CMD_REBOOT,              h_reboot              },
    { CMD_RPT_OFF,    h_auto_report_stop    },
    { CMD_RPT_ON,   h_auto_report_start   },
};

#define CMD_TABLE_SIZE (sizeof(cmd_table) / sizeof(cmd_table[0]))

/************************* 命令分发入口 *************************/

void handler_dispatch(protocol_frame_t *frame)
{
    uint16_t i;

    g_reply_devid = (frame->devid == DEVID_BC) ? g_device_id : frame->devid;
    g_reply_ver   = frame->ver;

    if (frame->devid != DEVID_BC && frame->devid != g_device_id) {
        return;
    }

    if (frame->type != FT_CMD && frame->type != FT_HART) {
        if (frame->type != FT_RPLY && frame->type != FT_ERR) {
            protocol_send_error(ERR_CMD);
        }
        return;
    }

    if (frame->type == FT_HART) {
        if (frame->devid == 0x8888) {
            protocol_send_reply(0x8888, NULL, 0);
        } else if (frame->devid == DEVID_BC) {
            uint8_t asc_buf[FRM_ASC_MAX];
            uint16_t asc_len;
            asc_len = protocol_frame_build(asc_buf, g_device_id, FT_HART,
                                           0x8888, g_fw_version, NULL, 0);
            usart_send_bytes(asc_buf, asc_len);
        }
        return;
    }

    if (g_auto_report_active && frame->cmd != CMD_RPT_OFF) {
        return;
    }

    i = 0;
    while (i < CMD_TABLE_SIZE) {
        if (cmd_table[i].cmd == frame->cmd) {
            cmd_table[i].handler(frame);
            return;
        }
        i++;
    }

    protocol_send_error(ERR_CMD);
}

/************************* 系统初始化 *************************/

void handler_system_init(void)
{
    uint8_t asc_buf[FRM_ASC_MAX];
    uint16_t asc_len;

    handler_params_load();

    usart_baudrate_set(USART, baudrate_code_to_value(g_baudrate_code));

    
    asc_len = protocol_frame_build(asc_buf, g_device_id, FT_HART,
                                   0x8888, g_fw_version, NULL, 0);
    usart_send_bytes(asc_buf, asc_len);
}

/****************************End*****************************/
