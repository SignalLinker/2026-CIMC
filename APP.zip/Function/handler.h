// 命令处理器头文件 — 查表法分发

#ifndef __HANDLER_H
#define __HANDLER_H

#include "protocol.h"
#include "HeaderFiles.h"

typedef enum {
    SYS_STATE_IDLE = 0,
    SYS_STATE_AUTO_SAMPLE,
} system_state_t;

// 全局状态

extern system_state_t g_sys_state;
extern uint8_t        g_auto_report_active;
extern uint32_t       g_auto_report_interval_ms;
extern uint32_t       g_auto_report_last_ms;
extern uint8_t        g_alarm_mode;

/* 参数配置 */
extern float    g_ch0_ratio;
extern float    g_ch1_ratio;
extern float    g_ch0_threshold;
extern float    g_ch1_threshold;
extern uint8_t  g_report_interval_code;

/************************* 函数声明 ************************/

/* 命令分发入口 — 处理一个已解析的协议帧 */
void handler_dispatch(protocol_frame_t *frame);

// 参数持久化
void handler_params_load(void);
void handler_params_save(void);

// 告警管理
void handler_alarm_check(uint8_t channel, float value, float threshold);
uint8_t handler_alarm_query(uint8_t *out_buf, uint16_t *out_len);
void handler_alarm_clear(void);

// 系统初始化
void handler_system_init(void);

// UTC 时间戳
uint32_t rtc_get_timestamp(void);

#endif

