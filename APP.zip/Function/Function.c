// 主循环 + ADC 采集 + 自动上报 + OLED 显示 + 告警检测

#include "Function.h"
#include "handler.h"

#define CONFIG_FLASH_ADDR   FLASH_PARAM_ADDR

// 全局变量

volatile int     work_mode   = MODE_IDLE;
uint32_t         period      = 5;
float            ratio       = 1.0f;
float            limit       = 100.0f;
float            temp        = 0.0f;
uint16_t         adcx        = 0;
uint16_t         start_ok    = 0;
uint16_t         stop_ok     = 0;
uint16_t         adjust_flag = 0;

float g_ratio = 1.0f;
uint8_t g_dac_follow_enable = 1;
uint8_t g_sleep_enable = 0;
uint8_t prev_work_mode = MODE_IDLE;

static void oled_update_status(void)
{
    oled_clear();

    
    oled_show_string(0, 0, "2026296117", FONT_16X8);

    
    if (g_auto_report_active) {
        oled_show_string(0, 16, "AutoSample", FONT_16X8);
    } else {
        oled_show_string(0, 16, "IDLE", FONT_16X8);
    }

    oled_refresh_gram();
}

void System_Init(void)
{
    systick_config();
    usart_init();

    LED_Init();
    LED1_ON();

    
    fmc_iap_erase(0, 0);  

    ADC_port_init();
    LOWPOWER_EXTIWakeup_DefaultInit();

    RTC_Init();
    KEY_Init();
    my_timer_init();
    DAC_Init();
    GD30AD3344_Hardware_Init();
}
static void auto_report_send(void)
{
    uint8_t  buf[12];
    float    ch0_val, ch1_val;
    uint32_t utc, raw;

    if (!g_auto_report_active) return;

    
    if (tick_count - g_auto_report_last_ms < g_auto_report_interval_ms) return;

    g_auto_report_last_ms = tick_count;

    
    g_reply_devid = g_device_id;
    g_reply_ver   = g_fw_version;

    
    utc = rtc_get_timestamp() + 946684800UL;
    buf[0] = (uint8_t)(utc >> 24);
    buf[1] = (uint8_t)(utc >> 16);
    buf[2] = (uint8_t)(utc >> 8);
    buf[3] = (uint8_t)(utc);

    
    ch0_val = temp;
    memcpy(&raw, &ch0_val, 4);
    buf[4] = (uint8_t)(raw >> 24);
    buf[5] = (uint8_t)(raw >> 16);
    buf[6] = (uint8_t)(raw >> 8);
    buf[7] = (uint8_t)(raw);

    
    {
        uint16_t ch1_raw;
        adc_software_trigger_enable(ADC0, ADC_INSERTED_CHANNEL);
        while (SET != adc_flag_get(ADC0, ADC_FLAG_EOIC));
        ch1_raw = adc_inserted_data_read(ADC0, ADC_INSERTED_CHANNEL_0);
        ch1_val = ADC_To_Voltage(ch1_raw, g_ch1_ratio);
    }
    memcpy(&raw, &ch1_val, 4);
    buf[8]  = (uint8_t)(raw >> 24);
    buf[9]  = (uint8_t)(raw >> 16);
    buf[10] = (uint8_t)(raw >> 8);
    buf[11] = (uint8_t)(raw);

    protocol_send_reply(CMD_RPT_ON, buf, 12);
}

/************************* 主循环 *************************/

void UsrFunction(void)
{
    uint8_t key_id;

    
    OLED_Display_Init();
    oled_update_status();

    
    while (1)
    {
        
        usart_recv_buf();

        
        adc_gather();

        
        if (g_dac_follow_enable) {
            DAC_Follow_ADC(adcx, g_ratio);
        }

        
        
        static uint32_t led1_last = 0;
        if (tick_count - led1_last >= 500) {
            led1_last = tick_count;
            LED1_TOGGLE();
        }
        
        if (g_auto_report_active) {
            LED2_ON();
        } else {
            LED2_OFF();
        }

        
        static uint32_t oled_last = 0;
        if (tick_count - oled_last >= 1000) {
            oled_last = tick_count;
            oled_update_status();
        }

        
        auto_report_send();

        
        if (g_alarm_mode != 0x00) {
            handler_alarm_check(0, temp, g_ch0_threshold);
        }

        
        while (KEY_Event_Get(&key_id)) {
            switch (key_id) {
            case 0:  
                if (g_auto_report_active) {
                    g_auto_report_active = 0;
                    g_sys_state = SYS_STATE_IDLE;
                    LED2_OFF();
                } else {
                    g_auto_report_active = 1;
                    g_auto_report_last_ms = tick_count;
                    g_sys_state = SYS_STATE_AUTO_SAMPLE;
                    LED2_ON();
                }
                oled_update_status();
                break;
            default:
                break;
            }
        }
    }
}
void adc_gather(void)
{
    static uint16_t adc_history[5] = {0};
    static uint8_t  hist_index = 0;
    uint32_t sum;
    uint8_t i;

    uint16_t raw = ADC_Get_Average(20);
    adc_history[hist_index] = raw;
    hist_index = (hist_index + 1) % 5;

    sum = 0;
    for (i = 0; i < 5; i++) {
        sum += adc_history[i];
    }
    adcx = (uint16_t)(sum / 5);

    temp = ADC_To_Voltage(adcx, g_ch0_ratio);
}

void sampling_toggle(void)
{
    if (g_auto_report_active) {
        g_auto_report_active = 0;
        g_sys_state = SYS_STATE_IDLE;
        LED2_OFF();
    } else {
        g_auto_report_active = 1;
        g_auto_report_last_ms = tick_count;
        g_sys_state = SYS_STATE_AUTO_SAMPLE;
        LED2_ON();
    }
}

void Func_Init_Handler(void) {}
void Func_Idle_Handler(void) {}
void Func_Task1_Handler(void) {}
void Func_Task2_Handler(void) {}
void Func_UART_Parse_Handler(void) {}

void flash_config_save(void) { handler_params_save(); }
void flash_config_read(void) { handler_params_load(); }

void display_sampling_info(void) { oled_update_status(); }

void display_idle_info(void)
{
    oled_clear();
    oled_show_string(0, 0, "2026296117", FONT_16X8);
    oled_show_string(0, 16, "IDLE", FONT_16X8);
    oled_refresh_gram();
}

void system_self_test(void) {}

void flash_sample_data_save(uint8_t *record, uint16_t len) {}
void flash_sample_data_print(void) {}

/****************************End*****************************/
